# SMC Mixer Suite Professional 2.4.6 — Rafael Souza

**Tema grafite/verde inspirado na edição visual 3.2** · Windows 10/11 · Projeto experimental assistido por IA

A SMC Mixer Suite Professional é uma aplicação desktop em desenvolvimento para usar o controlador físico **M‑VAVE SMC‑Mixer** como superfície de controle de áudio no Windows. O projeto reúne controle MIDI, volumes do Windows, equalização por meio do Equalizer APO, perfis salvos, ações configuráveis e uma pequena notificação visual das funções acionadas.

> **Estado do projeto: experimental.** Os testes automatizados passam no ambiente em que foram executados, mas a interface Qt, a conexão MIDI física, o controle real de áudio e a compilação final precisam ser validados no computador de destino. Não considere esta versão homologada para uso crítico.

![Ícone da SMC Mixer Suite](static/smc_mixer_suite_icon.png)

## O que esta versão pretende oferecer

- Interface escura grafite com destaque verde, preservando a organização da versão 2.4.6.
- Oito canais visuais com faders verticais para controle de volume.
- Knobs para ajustar bandas de equalização.
- Aprendizado de controles MIDI com perfis e configurações persistentes.
- Ações configuráveis para botões físicos, incluindo mute, seleção, mídia e abertura de programas conforme os mapeamentos.
- Equalização integrada ao Equalizer APO quando instalado e configurado para o dispositivo correto.
- Notificação flutuante opcional para indicar a função acionada.
- Scripts para instalar dependências, executar testes e tentar compilar um executável Windows.

O comportamento disponível depende do hardware, dos mapeamentos, dos dispositivos de áudio e das aplicações instaladas. A documentação não substitui o teste com o SMC‑Mixer físico.

## Importante: evitar conflitos entre botões e faders

O MIDI não identifica fisicamente qual peça enviou uma mensagem se dois controles enviarem a mesma mensagem MIDI. Para um mapeamento confiável, configure os **faders e knobs como CC** e, no software de configuração da M‑VAVE, configure os **botões como Note, com números exclusivos**, quando o dispositivo e o software permitirem. Depois refaça o aprendizado no programa.

Se um botão mover um fader, desative o perfil e corrija o mapeamento antes de continuar. Não existe uma correção puramente visual capaz de distinguir duas mensagens MIDI idênticas.

## Requisitos

- Windows 10 ou Windows 11, 64 bits.
- Python de 64 bits; **Python 3.12 é a opção recomendada** para esta distribuição. O instalador do projeto também procura versões 3.11 e 3.13.
- Acesso à internet durante a instalação para baixar bibliotecas.
- M‑VAVE SMC‑Mixer conectado por USB MIDI ou por uma porta Bluetooth MIDI compatível.
- **Equalizer APO** é opcional e necessário somente para os recursos de equalização que dependem dele.
- Se os botões e faders tiverem mensagens MIDI conflitantes, pode ser necessário o software oficial de configuração da M‑VAVE (MidiSuite) para alterar os tipos/números das mensagens.

## Instalação para uso no Windows

1. Baixe o arquivo ZIP desta distribuição e extraia-o para uma pasta normal, por exemplo `C:\SMC_Mixer_Suite_2_4_6`.
2. Instale o Python 3.12 de 64 bits pela página oficial: <https://www.python.org/downloads/>. Durante a instalação, marque **Add python.exe to PATH**.
3. Abra a pasta extraída e execute `setup_windows.bat`. O script cria o ambiente `.venv` e instala as dependências.
4. Quando a instalação acabar, execute `test_windows.bat`. Continue se os testes terminarem sem falhas.
5. Execute `run_windows.bat` para iniciar a aplicação a partir do código-fonte.
6. Conecte o SMC‑Mixer, selecione a porta MIDI certa, crie/salve um perfil e mapeie primeiro um fader, um knob e um botão. Teste cada um antes de mapear os demais controles.

Os scripts mostram o erro encontrado caso alguma etapa falhe. Não feche a janela de erro antes de copiar a mensagem relevante.

## Criar um executável `.exe`

Quando o aplicativo funcionar no computador de destino:

1. Execute `build_windows.bat`.
2. O script repete os testes e a verificação sintática antes de tentar compilar.
3. Se a compilação tiver êxito, procure `dist\SMC_Mixer_Suite_Professional_2_4_6.exe`.

A existência do executável não garante, sozinha, que todos os recursos de áudio e MIDI funcionem. Teste o `.exe` com o equipamento conectado. Esta distribuição **não inclui um executável já validado**.

## Executar os testes manualmente

Abra um Prompt de Comando na pasta do projeto e execute:

```bat
.venv\Scripts\python.exe -m unittest discover -s tests -v
.venv\Scripts\python.exe verify_syntax.py
```

Na preparação desta publicação, o conjunto de testes automatizados executou **131 testes aprovados** e o verificador de sintaxe analisou **43 arquivos Python**. Isso é diferente de validar a interface Qt e o hardware físico, que ainda exigem testes no Windows com o controlador conectado.

## Onde ficam as configurações?

A aplicação utiliza a pasta local do usuário em `%APPDATA%\SMCMixerSuite`. Faça cópias de segurança dos perfis e das configurações antes de atualizar a aplicação. Não publique arquivos pessoais de configuração, logs ou relatórios de diagnóstico sem conferir seu conteúdo.

## Estrutura do projeto

- `main.py` — inicialização da aplicação.
- `smc_suite/` — lógica de áudio, MIDI, perfis e interface.
- `tests/` — testes automatizados.
- `static/` — ícone e dados auxiliares incluídos no projeto.
- `requirements.txt` — dependências Python.
- `setup_windows.bat` — prepara o ambiente.
- `run_windows.bat` — executa o código-fonte.
- `test_windows.bat` — executa testes e verificação sintática.
- `build_windows.bat` — tenta gerar o executável.
- `AUDITORIA_TECNICA.md` — escopo, riscos e limitações conhecidos.
- `CHANGELOG.md` — histórico de alterações.
- `APRESENTACAO_DO_PROJETO.md` — explicação transparente sobre a criação assistida por IA.
- `docs/GUIA_PUBLICAR_NO_GITHUB.md` — passo a passo para publicar o repositório.

## Declaração de desenvolvimento assistido por IA

Este projeto foi construído de forma iterativa com auxílio do ChatGPT. O idealizador é iniciante em programação: definiu o objetivo, descreveu o comportamento desejado, avaliou versões, relatou problemas e pediu ajustes. O código foi gerado e modificado com assistência de IA. Isso não significa que todas as funções estejam validadas ou que a IA substitua testes reais.

A explicação completa e um texto pronto para apresentar o projeto estão em [`APRESENTACAO_DO_PROJETO.md`](APRESENTACAO_DO_PROJETO.md).

## Marca e afiliação

M‑VAVE e SMC‑Mixer são nomes dos respectivos titulares e são mencionados para indicar compatibilidade pretendida. Este projeto é independente e **não é oficial, não é patrocinado nem endossado pela M‑VAVE**.

## Licença

**A licença de reutilização ainda não foi definida nesta distribuição.** Publicar um repositório como público permite que as pessoas o vejam e o bifurquem de acordo com os termos do GitHub, mas não concede automaticamente uma licença geral para reutilizar, modificar ou redistribuir o código. Antes de aceitar contribuições ou anunciar o projeto como código aberto, escolha uma licença apropriada. Consulte a documentação do GitHub: <https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository>.

## Ajuda e relatos de problemas

Ao relatar um problema, informe sua versão do Windows, a versão do Python, o método de conexão (USB/Bluetooth), o passo que reproduz o erro e a mensagem exibida. Não publique senhas, dados pessoais, perfis privados ou logs sem verificar o conteúdo.
