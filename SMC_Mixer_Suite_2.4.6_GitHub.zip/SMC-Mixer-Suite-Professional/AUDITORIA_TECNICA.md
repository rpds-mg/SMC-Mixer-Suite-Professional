# Auditoria técnica — SMC Mixer Suite Professional 2.4.6

## Base e escopo
Esta versão parte do código da distribuição identificada internamente como 2.4.5 (pasta original 2.4.4). Não foi feita uma reescrita total para preservar o fluxo funcional da versão considerada mais satisfatória.

## Correções introduzidas
- MIDI Learn analógico agora exige múltiplas amostras de movimento antes de registrar fader/knob. Uma borda 0/127 de botão não é aceita como movimento.
- Todos os eventos são consumidos enquanto o MIDI Learn está ativo; mensagens de outros controles não chegam às funções normais durante a captura.
- Note é o modo padrão para novos botões; os modos CC continuam disponíveis para uso deliberado e compatível.
- Eventos de fader/knob em rotas únicas são coalescidos em intervalos de 16 ms, reduzindo a carga de atualização gráfica.
- Configuração persistente da janelinha de função acionada: mostrar/ocultar, posição e duração.
- Mensagens MIDI não mapeadas não acionam mais o OSD repetidamente.
- O estilo foi ajustado de forma conservadora, mantendo a organização existente e evitando uma reformulação conceitual da interface.

## Limite físico do MIDI
Software não consegue separar dois controles físicos que emitam exatamente a mesma porta/tipo/canal/CC. Para isolamento real, configure os botões físicos do SMC-Mixer como Note com números exclusivos no MidiSuite oficial e mantenha faders/knobs em CC. O programa detecta conflitos de mapeamento que existam no perfil e interrompe o despacho de rotas ambíguas.

## Testes
Os testes automatizados devem ser executados com `python -m unittest discover -s tests -q` e `python verify_syntax.py`. Eles cobrem lógica de perfil, roteamento, aprendizado seguro e callbacks. A validação não substitui teste no Windows com o SMC-Mixer físico.

## Ainda não validado neste ambiente
- Renderização Qt real, pois PyQt6 não está instalado no ambiente de preparação.
- Eventos MIDI físicos por USB/Bluetooth, áudio Windows e aplicação efetiva do Equalizer APO.
- Compilação final do executável Windows.
