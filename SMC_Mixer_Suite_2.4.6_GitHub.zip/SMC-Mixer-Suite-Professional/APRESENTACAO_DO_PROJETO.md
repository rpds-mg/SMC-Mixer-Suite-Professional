# Apresentação do projeto — SMC Mixer Suite Professional

## Descrição curta para o campo “About” do GitHub

Projeto experimental assistido por IA para explorar o uso do M‑VAVE SMC‑Mixer como controlador de áudio do Windows, com mapeamento MIDI, perfis e equalização.

## Texto para compartilhar com o link do repositório

Olá, pessoal! Estou compartilhando a **SMC Mixer Suite Professional 2.4.6**, um projeto experimental que estou desenvolvendo com o objetivo de usar o controlador físico M‑VAVE SMC‑Mixer para controlar funções de áudio do Windows.

Quero ser transparente sobre como ele foi criado: **sou leigo em programação**. Não escrevi todo esse código manualmente nem domino Python. Comecei explicando ao ChatGPT o que eu queria que o programa fizesse e fui pedindo alterações, correções e melhorias conforme testava as versões e identificava problemas. A ideia, os requisitos e a direção do projeto vieram das minhas necessidades; a geração e as modificações do código foram feitas com assistência de IA.

Estou publicando o projeto no GitHub para organizá-lo, documentar o que foi tentado, aprender com o processo e, quem sabe, receber sugestões de pessoas que entendem de Python, MIDI, PyQt e áudio no Windows.

A versão inclui o código-fonte, testes automatizados, arquivos de dependências e scripts para instalar, executar, testar e tentar compilar o programa. Para executar o código-fonte é necessário um computador com Windows 10/11 de 64 bits, Python de 64 bits (Python 3.12 é recomendado) e conexão com a internet durante a instalação das bibliotecas. Alguns recursos de equalização dependem do Equalizer APO e a conexão/mapeamento depende do funcionamento correto do SMC‑Mixer e de suas mensagens MIDI.

Os testes automatizados passaram no ambiente de preparação, mas **a interface gráfica, o áudio real do Windows e o controlador físico ainda precisam ser validados no computador de destino**. Portanto, não estou afirmando que seja um programa profissional homologado ou que funcione perfeitamente em todos os computadores. É um projeto em desenvolvimento e quero deixar suas limitações claras.

Se você entende de programação e puder apontar problemas ou sugerir melhorias com respeito, ficarei grato. Eu ainda estou aprendendo e talvez não consiga responder a perguntas técnicas avançadas, mas estou compartilhando o caminho que fiz e o resultado que consegui construir com ajuda do ChatGPT.
