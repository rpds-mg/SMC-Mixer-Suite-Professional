@echo off
setlocal
cd /d "%~dp0"
echo =============================================================
echo   SMC Mixer Suite Professional 2.4.6 - Rafael Souza
echo   Compilacao limpa; executavel com nome exclusivo da versao
echo =============================================================
if not exist ".venv\Scripts\python.exe" (
  echo ERRO: ambiente .venv nao encontrado. Execute setup_windows.bat.
  pause
  exit /b 1
)
echo Executando testes automatizados...
".venv\Scripts\python.exe" -m unittest discover -s tests -v
if errorlevel 1 goto :fail
echo Verificando sintaxe Python...
".venv\Scripts\python.exe" verify_syntax.py
if errorlevel 1 goto :fail
echo Limpando artefatos de compilacoes anteriores desta pasta...
if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"
if exist "SMC_Mixer_Suite_Professional_2_4_6.spec" del /q "SMC_Mixer_Suite_Professional_2_4_6.spec"
echo Compilando a versao 2.4.6...
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --noconsole --name SMC_Mixer_Suite_Professional_2_4_6 --icon "static\smc_mixer_suite.ico" --add-data "static\smc_mixer_suite.ico;static" --add-data "static\smc_mixer_led_map.json;static" --hidden-import=mido.backends.rtmidi --hidden-import=rtmidi --collect-all rtmidi --collect-submodules smc_suite --collect-submodules mido --collect-submodules comtypes --collect-submodules pycaw --collect-all bleak --collect-all screen_brightness_control main.py
if errorlevel 1 goto :fail
echo.
echo COMPILACAO CONCLUIDA:
echo   dist\SMC_Mixer_Suite_Professional_2_4_6.exe
echo Ao iniciar, confirme no titulo: versao 2.4.6 - Rafael Souza.
echo Configuracoes preservadas em %%APPDATA%%\SMCMixerSuite
pause
exit /b 0
:fail
echo.
echo FALHA na compilacao. Copie a mensagem acima para diagnostico.
pause
exit /b 1
