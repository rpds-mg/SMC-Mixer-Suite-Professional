# Comunicação de problemas de segurança

Este é um projeto experimental. Se encontrar um problema que possa expor dados, executar ações sem autorização ou comprometer a máquina, evite publicar detalhes exploráveis imediatamente em uma issue pública. Até haver um canal privado específico para este projeto, entre em contato com o responsável pela conta GitHub que hospeda o repositório, se houver uma forma de contato indicada no perfil.

Não envie senhas, tokens, perfis de configuração pessoais nem dados privados em issues.
