@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
echo =============================================================
echo   SMC Mixer Suite Professional 2.4.6 - Rafael Souza
echo   Preparar ambiente Python
echo =============================================================

if exist ".venv\Scripts\python.exe" (
  echo Ambiente virtual existente encontrado. Reutilizando-o.
  goto :install_packages
)

set "PYTHON_CMD="
rem Detect the common CPython install locations first. This avoids depending only on the Python Launcher.
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" set "PYTHON_CMD="%LocalAppData%\Programs\Python\Python312\python.exe""
if not defined PYTHON_CMD if exist "%LocalAppData%\Programs\Python\Python311\python.exe" set "PYTHON_CMD="%LocalAppData%\Programs\Python\Python311\python.exe""
if not defined PYTHON_CMD if exist "%LocalAppData%\Programs\Python\Python313\python.exe" set "PYTHON_CMD="%LocalAppData%\Programs\Python\Python313\python.exe""

rem If no known path exists, try the launcher in supported versions, not only 3.12.
if not defined PYTHON_CMD (
  py -3.12 --version >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=py -3.12"
)
if not defined PYTHON_CMD (
  py -3.11 --version >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=py -3.11"
)
if not defined PYTHON_CMD (
  py -3.13 --version >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=py -3.13"
)

rem Last fallback: a python.exe already on PATH, but only if it is Python 3.11 or newer.
if not defined PYTHON_CMD (
  python -c "import sys; sys.exit(0 if sys.version_info >= (3,11) and sys.version_info < (3,14) else 1)" >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=python"
)

if not defined PYTHON_CMD (
  echo ERRO: Python 3.11, 3.12 ou 3.13 de 64 bits nao foi encontrado.
  echo Instale Python 3.11.9 x64: https://www.python.org/downloads/release/python-3119/
  echo Durante a instalacao, marque "Add python.exe to PATH".
  pause
  exit /b 1
)

echo Python detectado:
%PYTHON_CMD% --version
if errorlevel 1 goto :python_fail
%PYTHON_CMD% -m venv .venv
if errorlevel 1 goto :python_fail

:install_packages
echo.
echo Instalando dependencias na .venv...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :fail
echo.
echo Ambiente 2.4.6 pronto. Execute run_windows.bat para iniciar.
pause
exit /b 0

:python_fail
echo.
echo Falha ao criar o ambiente virtual com %PYTHON_CMD%.
echo Confira a instalacao do Python e tente novamente.
pause
exit /b 1

:fail
echo.
echo ERRO ao instalar dependencias. Copie a mensagem acima para diagnostico.
pause
exit /b 1
