## Atualização visual — tema da versão 3.2

- Aplicado o tema grafite com destaque verde discreto da SMC Mixer Suite 3.2.
- Mantidos o layout, as abas, os canais, os controles e a lógica operacional da versão 2.4.6.
- Adicionado ajuste visual único para instalações existentes; alterações futuras de tema feitas pelo usuário continuam salvas.
- Migradas apenas as cores de fábrica dos canais para o verde do tema. Cores realmente personalizadas são preservadas.
- Sem novas funções de áudio e sem mudança no mapeamento MIDI nesta edição visual.

# Changelog

## 2.4.6
- Aprimorado o MIDI Learn de faders/knobs: exige assinatura de movimento em várias amostras; uma mensagem isolada de botão não pode registrar imediatamente uma rota analógica.
- Durante qualquer sessão de MIDI Learn, eventos que não atendem ao aprendizado são consumidos e não chegam ao despacho normal de ações.
- Note passa a ser o modo seguro padrão para novos mapeamentos de botões; modos CC permanecem disponíveis explicitamente para configurações compatíveis já verificadas.
- Entradas analógicas únicas são agrupadas para atualização da interface em cerca de 60 Hz, reduzindo carga do thread gráfico sem adicionar atraso perceptível aos botões.
- A janelinha de função ativada agora pode ser habilitada/desabilitada, posicionada em qualquer canto e ter sua duração ajustada em Configurações.
- Entrada MIDI sem mapeamento deixa de abrir a janelinha continuamente; permanece disponível no log/diagnóstico.
- Aparência escura ajustada com bordas e espaçamentos mais discretos.
- Observação: se o botão físico e o fader emitirem a mesma mensagem MIDI, o hardware não transmite informação de origem. Configure os botões no MidiSuite da M-VAVE como Note com notas exclusivas e mantenha faders/knobs em CC.

## 2.4.5
- Versão base preservada: controle de áudio do Windows, equalizador global, bancos, LEDs, macros e remoção da integração OBS.
