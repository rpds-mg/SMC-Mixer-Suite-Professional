@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Ambiente Python nao encontrado. Execute setup_windows.bat primeiro.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m unittest discover -s tests -v
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" verify_syntax.py
if errorlevel 1 goto :fail
echo.
echo Testes e sintaxe aprovados.
pause
exit /b 0
:fail
echo.
echo Teste falhou. Copie o resultado acima para diagnostico.
pause
exit /b 1
