# Guia simples: publicar este projeto no GitHub usando GitHub Desktop

Este é o método recomendado para quem não quer usar comandos ou terminal.

## O que é necessário baixar?

1. **O ZIP do projeto** que foi entregue com esta publicação.
2. **GitHub Desktop**, para enviar a pasta ao GitHub: <https://desktop.github.com/>.
3. Uma conta no GitHub: <https://github.com/>.

Você não precisa instalar o Git separadamente para seguir este fluxo no GitHub Desktop. O Python só é necessário para instalar, testar e executar a aplicação; publicar o código por si só não exige Python.

## Parte A — preparar a pasta

1. Baixe `SMC_Mixer_Suite_2.4.6_GitHub.zip`.
2. Clique com o botão direito no ZIP e escolha **Extrair Tudo**.
3. Guarde a pasta extraída em um local fácil, por exemplo `Documentos\Projetos\SMC_Mixer_Suite_GitHub`.
4. Abra a pasta e confira se vê `README.md`, `main.py`, `requirements.txt`, `smc_suite`, `tests` e os arquivos `.bat`.
5. Não adicione arquivos pessoais de configuração, logs, senhas ou a pasta `.venv`.

## Parte B — instalar e entrar no GitHub Desktop

1. Abra <https://desktop.github.com/> e baixe o GitHub Desktop para Windows.
2. Instale e abra o programa.
3. Entre com sua conta do GitHub. Se ainda não tiver uma conta, crie-a em <https://github.com/> e depois volte ao Desktop.

## Parte C — criar o repositório local

1. No GitHub Desktop, abra o menu **File** e escolha **New repository**.
2. Em **Name**, escreva `SMC-Mixer-Suite-Professional`.
3. Em **Local path**, escolha a pasta onde deseja guardar seus projetos, por exemplo `Documentos\GitHub`. O Desktop criará ali a pasta do repositório.
4. Como o ZIP já contém README e `.gitignore`, pode deixar desmarcados os itens para criar README, Git ignore e licença.
5. Clique em **Create repository**.

## Parte D — copiar os arquivos preparados

1. Abra a pasta criada pelo GitHub Desktop. Se não souber onde está, no Desktop use **Repository > Show in Explorer**.
2. Em outra janela do Explorador de Arquivos, abra a pasta extraída do ZIP.
3. Copie **o conteúdo** dessa pasta — todos os arquivos e pastas, inclusive os que começam com ponto, como `.gitignore` — para dentro da pasta do repositório criada pelo Desktop.
4. Se o Windows perguntar sobre substituir arquivos, confirme apenas quando for o README ou `.gitignore` de inicialização criado pelo Desktop. Não apague a pasta oculta `.git` que pertence ao GitHub Desktop.
5. Volte ao GitHub Desktop. Os arquivos copiados devem aparecer como alterações.

## Parte E — gravar e publicar

1. No canto inferior esquerdo do GitHub Desktop, em **Summary**, escreva `Primeira publicação da SMC Mixer Suite Professional 2.4.6`.
2. Clique em **Commit to main**.
3. Clique em **Publish repository** na parte superior.
4. No campo de nome, confirme `SMC-Mixer-Suite-Professional`.
5. Em descrição, você pode usar: `Projeto experimental assistido por IA para controle de áudio do Windows com M-VAVE SMC-Mixer.`
6. Se você quer que qualquer pessoa possa ver o código, desmarque **Keep this code private**. Se preferir revisar primeiro, deixe marcado e publique como privado.
7. Clique em **Publish repository** e aguarde.
8. Quando terminar, use **Repository > View on GitHub** para abrir a página publicada.

## Parte F — confira a página pública

Confira se o README aparece na página inicial e se as pastas `smc_suite` e `tests` estão visíveis. Confira também se o texto sobre o uso de IA e as limitações está claro. Se você publicou como privado, somente pessoas com acesso poderão ver o repositório.

## Para atualizar depois

Quando fizer alterações aos arquivos, abra o GitHub Desktop. Revise a lista de alterações, escreva uma descrição curta em **Summary**, clique em **Commit to main** e depois em **Push origin** (ou no botão equivalente que aparecer). Assim, as mudanças locais serão enviadas para o GitHub.

## Dicas importantes antes de publicar

- O arquivo `settings.example.json` é um modelo de configuração. Não envie sua configuração real com seus perfis pessoais.
- Não envie a pasta `.venv`, os arquivos gerados em `build`/`dist`, logs ou relatórios com informações pessoais.
- O `.gitignore` já exclui vários desses arquivos, mas sempre revise a lista de alterações antes de publicar.
- O repositório desta versão não inclui um `.exe` validado. Se futuramente publicar um executável, deixe claro como ele foi criado e teste-o antes.
- A licença de reutilização não está definida. Antes de anunciar o projeto como código aberto, escolha uma licença. A documentação do GitHub explica por que isso é importante: <https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository>.

## Ajuda oficial

- GitHub Desktop: <https://desktop.github.com/>
- Documentação oficial de publicar um projeto existente: <https://docs.github.com/en/desktop/adding-and-cloning-repositories/adding-an-existing-project-to-github-using-github-desktop>
