"""Pure LED-frame generation for all four physical button rows of the SMC-Mixer."""
from __future__ import annotations

import math
from typing import Any

from smc_suite.led_mapping import SMC_MIXER_LED_MAP

# Physical rows in order: Mute, second row, Rec/action, Select/status.
ROW_KEYS = ("mute_notes", "meter_notes", "status_notes", "select_notes")
LED_TEST_DURATION = 4.8
LED_TEST_STEP_SECONDS = LED_TEST_DURATION / 32.0


def _bounded(value: object, minimum: float = 0.0, maximum: float = 1.0) -> float:
    try:
        return max(minimum, min(maximum, float(value)))
    except (TypeError, ValueError):
        return minimum


def build_led_frame(t: float, snapshot: dict[str, Any]) -> dict[tuple[str, int], int]:
    """Generate the full CC + all 32 button-LED values.

    EQ mode drives all four physical rows according to the configured volume
    values, so low Windows volume does not leave rows 2–4 dark. The dedicated
    Level/Meter Fill modes provide a thresholded four-segment bar. Animated
    effects animate every row, not only note IDs 8..15.
    Static mode keeps semantic Mute/REC/Select indicators. Levels are Windows
    volume scalars; they are not acoustic peak measurements.
    """
    mode = str(snapshot.get("mode", "equalizer"))
    test_until = float(snapshot.get("test_until", 0.0))
    test_active = float(t) < test_until
    if test_active:
        mode = "test_sequence"
    speed = _bounded(snapshot.get("speed", 1.0), 0.25, 4.0)
    brightness = _bounded(snapshot.get("brightness", 0.8), 0.05, 1.0)

    def values(key: str, default: bool = False) -> list[Any]:
        raw = list(snapshot.get(key, []))[:8]
        raw += [default] * (8 - len(raw))
        return raw

    levels = [_bounded(v) for v in values("levels", False)]
    knobs = [_bounded(v) for v in values("knobs", 0.5)]
    muted = [bool(v) for v in values("muted", False)]
    selected = [bool(v) for v in values("selected", False)]
    record_armed = [bool(v) for v in values("record_armed", False)]
    transport = snapshot.get("transport", {}) or {}
    phase = float(t) * speed

    def scale(value: float) -> int:
        return max(0, min(127, round(_bounded(value) * 127 * brightness)))

    frame: dict[tuple[str, int], int] = {}
    for i, cc in enumerate(SMC_MIXER_LED_MAP["fader_cc"]):
        frame[("cc", cc)] = scale(levels[i]) if mode != "off" else 0
    for i, cc in enumerate(SMC_MIXER_LED_MAP["knob_cc"]):
        frame[("cc", cc)] = scale(knobs[i]) if mode != "off" else 0

    rows = {key: SMC_MIXER_LED_MAP[key] for key in ROW_KEYS}
    led_values: dict[str, list[float]] = {key: [0.0] * 8 for key in ROW_KEYS}

    if mode == "off":
        pass
    elif mode == "static":
        led_values["mute_notes"] = [1.0 if v else 0.0 for v in muted]
        led_values["meter_notes"] = [0.22 if v > 0.01 else 0.0 for v in levels]
        led_values["status_notes"] = [1.0 if v else 0.0 for v in record_armed]
        led_values["select_notes"] = [1.0 if v else 0.0 for v in selected]
    elif mode == "equalizer":
        # Keep all four physical rows visible even at lower Windows volume.
        # Windows session volume is a control value, not an acoustic VU signal.
        # Slight row attenuation creates visual separation without darkening rows.
        row_factors = (1.0, 0.88, 0.76, 0.64)
        for row_index, row_key in enumerate(ROW_KEYS):
            for channel, level in enumerate(levels):
                active = 0.0 if level <= 0.01 else max(0.22, level)
                led_values[row_key][channel] = active * row_factors[row_index]
    elif mode in ("level", "meter_fill"):
        # Dedicated level modes use the four rows as thresholded bar segments.
        for row_index, row_key in enumerate(ROW_KEYS):
            threshold = row_index * 0.25
            for channel, level in enumerate(levels):
                segment = max(0.0, min(1.0, (level - threshold) / 0.25))
                if mode == "meter_fill":
                    segment = 1.0 if level >= (row_index + 1) * 0.25 else 0.0
                led_values[row_key][channel] = segment
    elif mode == "test_sequence":
        # Deterministic 32-LED hardware diagnostic: light every physical button
        # LED individually at full intensity, in row order, so output mapping can
        # be distinguished from the normal level meter's threshold behavior.
        elapsed = max(0.0, min(LED_TEST_DURATION, LED_TEST_DURATION - (test_until - float(t))))
        position = max(0, min(31, int(elapsed / LED_TEST_STEP_SECONDS)))
        row_key = ROW_KEYS[position // 8]
        led_values[row_key][position % 8] = 1.0
    elif mode == "knight_rider":
        for row_index, row_key in enumerate(ROW_KEYS):
            pos = int((phase * 4.0 + row_index * 2.0) % 14)
            index = pos if pos < 8 else 13 - pos
            led_values[row_key][index] = 1.0
            tail = (index - 1) % 8
            led_values[row_key][tail] = max(led_values[row_key][tail], 0.32)
    elif mode == "chase":
        for row_index, row_key in enumerate(ROW_KEYS):
            head = int((phase * 3.0 + row_index * 2.0) % 8)
            led_values[row_key][head] = 1.0
            led_values[row_key][(head - 1) % 8] = 0.55
            led_values[row_key][(head - 2) % 8] = 0.22
    elif mode == "wave":
        for row_index, row_key in enumerate(ROW_KEYS):
            for channel in range(8):
                led_values[row_key][channel] = (math.sin(phase * 2.3 - channel * 0.78 + row_index * 0.82) + 1.0) / 2.0
    elif mode == "breathe":
        breathe = (math.sin(phase * 2.0) + 1.0) / 2.0
        for row_index, row_key in enumerate(ROW_KEYS):
            factor = (0.45, 0.65, 0.55, 0.8)[row_index]
            led_values[row_key] = [breathe * factor for _ in range(8)]
    elif mode == "pulse":
        pulse = 1.0 if math.sin(phase * 4.0) > 0 else 0.12
        for row_index, row_key in enumerate(ROW_KEYS):
            factor = (0.65, 1.0, 0.75, 0.5)[row_index]
            led_values[row_key] = [pulse * max(levels[i], factor * 0.45) for i in range(8)]
    elif mode == "channel_scan":
        for row_index, row_key in enumerate(ROW_KEYS):
            index = int((phase * 2.0 + row_index * 2.0) % 8)
            led_values[row_key][index] = 1.0
            led_values[row_key][(index - 1) % 8] = 0.18
    else:
        # Safe fallback: use all four rows as a level display.
        for row_index, row_key in enumerate(ROW_KEYS):
            for channel, level in enumerate(levels):
                led_values[row_key][channel] = 1.0 if level >= (row_index + 1) / 4 else 0.0

    # Preserve meaningful button states as a brighter overlay when animation is
    # active, except Stealth mode which deliberately turns every LED off.
    if mode not in ("off", "static", "test_sequence"):
        for i in range(8):
            if muted[i]:
                led_values["mute_notes"][i] = max(led_values["mute_notes"][i], 1.0)
            if record_armed[i]:
                led_values["status_notes"][i] = max(led_values["status_notes"][i], 1.0)
            if selected[i]:
                led_values["select_notes"][i] = max(led_values["select_notes"][i], 1.0)

    for row_key, notes in rows.items():
        for i, note in enumerate(notes):
            if mode == "test_sequence":
                frame[("note", int(note))] = 127 if led_values[row_key][i] > 0.0 else 0
            else:
                frame[("note", int(note))] = scale(led_values[row_key][i])
    for key, note in SMC_MIXER_LED_MAP["transport_notes"].items():
        frame[("note", int(note))] = scale(1.0 if bool(transport.get(key, False)) and mode not in ("off", "test_sequence") else 0.0)
    return frame
