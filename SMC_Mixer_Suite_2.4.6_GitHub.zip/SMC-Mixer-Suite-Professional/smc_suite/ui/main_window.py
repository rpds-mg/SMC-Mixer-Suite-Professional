from __future__ import annotations

import copy
import ctypes
import json
import logging
import math
import os
import platform
import sys
import time
from pathlib import Path
from typing import Any

from PyQt6.QtCore import Qt, QTimer, QPoint, QSize, QUrl, QObject, QRunnable, QThreadPool, pyqtSignal
from PyQt6.QtGui import QAction, QColor, QIcon, QPixmap, QPainter, QPen, QDesktopServices
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QColorDialog, QDialog, QFileDialog, QFormLayout, QFrame,
    QHBoxLayout, QGridLayout, QHeaderView, QInputDialog, QLabel, QLineEdit, QMainWindow,
    QMessageBox, QPushButton, QProgressBar, QSlider, QSpinBox, QDoubleSpinBox,
    QSystemTrayIcon, QTabWidget, QTableWidget, QTableWidgetItem, QVBoxLayout,
    QWidget, QMenu, QStyle, QGroupBox, QAbstractItemView, QToolButton, QSizePolicy, QScrollArea,
)

from smc_suite.actions import execute_action, parse_macro_sequence
from smc_suite.audio_engine import AudioEngine
from smc_suite.config_store import APP_DIR, ConfigStore, _normalize_profile
from smc_suite.eqapo import include_line, write_config
from smc_suite.eqapo_setup import (ELEVATED_POWERSHELL_SCRIPT, configure_include_file, find_equalizer_apo_config, include_exists)
from smc_suite.knob_input import (KNOB_MODES, absolute_cc_to_gain, apply_relative_gain_step, decode_relative_delta, infer_knob_mode, normalize_knob_mode)
from smc_suite.eq_model import (DEFAULT_FREQUENCIES, BAND_LABELS, FACTORY_PRESETS, REFERENCE_FREQUENCIES,
                                frequency_label, preset_gains_for_frequencies, gains_to_reference,
                                normalize_mode, sanitize_frequencies, clamp_gain)
from smc_suite.led_engine import LedAnimationEngine, LED_MODES
from smc_suite.hardware import BUTTON_SPECS, BUTTON_SPEC_BY_ID, BUTTON_IDS, CHANNEL_DEFAULT_COLORS
from smc_suite.midi_engine import MidiEngine
from smc_suite.button_input import MidiButtonPressGate
from smc_suite.midi_mapping import analog_route_owners, midi_route_owners
from smc_suite.analog_learn import AnalogLearnSampler, AnalogCCMotionGuard
from smc_suite.ui.hardware_widgets import ChannelStrip, HudOverlay, RotaryKnob
from smc_suite.themes import THEMES, DEFAULT_THEME, resolve_palette, build_stylesheet
from smc_suite.diagnostics import build_diagnostics_archive
from smc_suite.battery_monitor import probe_smc_battery
from smc_suite import __version__
from smc_suite.layout_policy import choose_eq_grid_columns, effective_compact_mode, recommended_channel_strip_width

ACTION_CHOICES = [
    ("Sem ação", "none"),
    ("Atalho de teclado global", "shortcut"),
    ("Sequência de teclas", "key_sequence"),
    ("Digitar texto", "text"),
    ("Abrir aplicativo / arquivo / URL", "launch"),
    ("Controle de mídia", "media"),
    ("Clique do mouse (x,y)", "mouse_click"),
    ("Mute do master", "mute_master"),
    ("Mute do microfone padrão", "mute_microphone"),
    ("Mute de aplicativo (executável)", "mute_app"),
    ("Ação rápida do Windows", "system"),
    ("Executar macro (1–8)", "macro"),
    ("Sequência de ações (macro)", "macro_sequence"),
    ("Mute deste canal", "channel_mute"),
    ("Solo deste canal", "channel_solo"),
    ("Selecionar este canal", "channel_select"),
    ("Banco anterior", "bank_prev"),
    ("Próximo banco", "bank_next"),
    ("Alternar modo dos knobs (EQ/Ganho)", "shift_toggle"),
]

ACTION_HINTS = {
    "none": "",
    "shortcut": "Ex.: ctrl+shift+m",
    "key_sequence": "Ex.: ctrl+s, enter, tab",
    "text": "Texto para colar na janela ativa",
    "launch": "Caminho de EXE/arquivo ou URL",
    "media": "Play / Pause | Próxima faixa | Faixa anterior | Parar mídia",
    "mouse_click": "Coordenadas: x,y ou x,y,right/double",
    "mute_app": "Executável: chrome.exe, spotify.exe etc.",
    "system": "show_desktop | explorer | task_manager | open_settings | open_sound_settings | open_display_settings | open_network_settings | lock_workstation | volume_up | volume_down | volume_mute | open_search | open_clipboard | open_notifications | minimize_active | maximize_active | snap_left | snap_right | restore_active",
    "macro": "Número da macro: 1 a 8.",
    "macro_sequence": "Ex.: launch|notepad.exe;wait|1.5;shortcut|ctrl+s. Máximo de 20 etapas; wait entre 0 e 10 s.",
}

# Beginner-friendly choices for the quick physical-button mapper. The older,
# fully configurable table remains available under "Avançado".
SIMPLE_BUTTON_ACTION_OPTIONS = [
    ("Função padrão deste botão", "__default__"),
    ("Nenhuma ação", "none"),
    ("Mídia: Play / Pause", "media_play_pause"),
    ("Mídia: próxima faixa", "media_next"),
    ("Mídia: faixa anterior", "media_previous"),
    ("Mídia: parar", "media_stop"),
    ("Windows: mute do volume geral", "mute_master"),
    ("Windows: mute do microfone", "mute_microphone"),
    ("Windows: abrir Explorador", "win_explorer"),
    ("Windows: mostrar área de trabalho", "win_desktop"),
    ("Windows: Gerenciador de Tarefas", "win_task_manager"),
    ("Windows: Configurações", "win_settings"),
    ("Windows: configurações de som", "win_sound"),
    ("Windows: configurações de tela", "win_display"),
    ("Windows: aumentar volume", "win_volume_up"),
    ("Windows: diminuir volume", "win_volume_down"),
    ("Windows: alternar mute do sistema", "win_volume_mute"),
    ("Windows: bloquear sessão", "win_lock"),
    ("Canal: mute deste canal", "channel_mute"),
    ("Canal: solo deste canal", "channel_solo"),
    ("Canal: selecionar este canal", "channel_select"),
    ("Bancos: anterior", "bank_prev"),
    ("Bancos: próximo", "bank_next"),
    ("Alternar modo dos knobs", "shift_toggle"),
    ("Abrir aplicativo / arquivo / site…", "custom_launch"),
    ("Atalho de teclado…", "custom_shortcut"),
    ("Digitar texto…", "custom_text"),
    ("Silenciar aplicativo…", "custom_mute_app"),
    ("Manter ação avançada atual", "__keep__"),
]

# key -> (action key, fixed argument); None means the argument is supplied by
# the user in the one-line field. The __default__ and __keep__ entries are
# handled separately and never overwrite a custom action accidentally.
SIMPLE_BUTTON_ACTION_CONFIG = {
    "none": ("none", ""),
    "media_play_pause": ("media", "Play / Pause"),
    "media_next": ("media", "Próxima faixa"),
    "media_previous": ("media", "Faixa anterior"),
    "media_stop": ("media", "Parar mídia"),
    "mute_master": ("mute_master", ""),
    "mute_microphone": ("mute_microphone", ""),
    "win_explorer": ("system", "explorer"),
    "win_desktop": ("system", "show_desktop"),
    "win_task_manager": ("system", "task_manager"),
    "win_settings": ("system", "open_settings"),
    "win_sound": ("system", "open_sound_settings"),
    "win_display": ("system", "open_display_settings"),
    "win_volume_up": ("system", "volume_up"),
    "win_volume_down": ("system", "volume_down"),
    "win_volume_mute": ("system", "volume_mute"),
    "win_lock": ("system", "lock_workstation"),
    "channel_mute": ("channel_mute", ""),
    "channel_solo": ("channel_solo", ""),
    "channel_select": ("channel_select", ""),
    "bank_prev": ("bank_prev", ""),
    "bank_next": ("bank_next", ""),
    "shift_toggle": ("shift_toggle", ""),
    "custom_launch": ("launch", None),
    "custom_shortcut": ("shortcut", None),
    "custom_text": ("text", None),
    "custom_mute_app": ("mute_app", None),
}

SIMPLE_BUTTON_ARGUMENT_HINTS = {
    "custom_launch": "Caminho do programa / arquivo ou endereço do site",
    "custom_shortcut": "Ex.: ctrl+shift+m (ou clique em Capturar no modo avançado)",
    "custom_text": "Texto que será digitado na janela ativa",
    "custom_mute_app": "Nome do executável, por exemplo chrome.exe",
}


DARK_STYLE = """
QWidget { background:#171a20; color:#e7edf5; font-size:13px; }
QMainWindow, QDialog { background:#171a20; }
QLabel { color:#e7edf5; }
QLabel#muted { color:#96a2b2; }
QLabel#title { font-size:20px; font-weight:800; color:#f6f8fb; }
QLabel#subtitle { color:#98a6b8; font-size:12px; }
QLabel#section { font-size:15px; font-weight:750; color:#f4f7fb; }
QLabel#eyebrow { font-size:9px; font-weight:800; color:#8293a7; letter-spacing:1px; }
QFrame[frameShape="4"], QFrame[frameShape="5"] { color:#303946; }
QFrame#panel { background:#1d222a; border:1px solid #333c49; border-radius:6px; }
QTabWidget::pane { border:1px solid #303844; border-top:1px solid #303844; border-bottom-left-radius:9px; border-bottom-right-radius:9px; top:-1px; background:#1a1e25; }
QTabWidget::tab-bar { alignment:left; left:5px; }
QTabBar { qproperty-drawBase:false; border:0px; background:transparent; }
QTabBar::tab { background:#222731; padding:6px 9px; margin-right:3px; margin-bottom:0px; min-height:27px; border:1px solid #303844; border-top-left-radius:7px; border-top-right-radius:7px; color:#9eacbd; font-weight:650; }
QTabBar::tab:selected { background:#1a1e25; color:#ffffff; border:1px solid #303844; border-top:2px solid #48a9f8; border-bottom:1px solid #1a1e25; margin-bottom:-1px; }
QTabBar::tab:hover:!selected { background:#29313d; color:#e7edf5; }
QComboBox, QLineEdit, QSpinBox, QDoubleSpinBox { background:#202630; border:1px solid #394453; border-radius:4px; padding:6px 8px; min-height:23px; selection-background-color:#287ec2; }
QComboBox QAbstractItemView { background:#202630; selection-background-color:#287ec2; border:1px solid #394453; }
QPushButton { background:#2a323e; border:1px solid #424e5f; padding:7px 10px; min-height:24px; border-radius:4px; font-weight:600; }
QPushButton:hover { background:#354354; border-color:#5b738c; }
QPushButton:pressed { background:#202733; }
QPushButton#primary { background:#147ac0; border-color:#268dd1; color:white; font-weight:750; }
QPushButton#danger { color:#ffabab; }
QToolButton#hardwareGlobal { min-height:47px; min-width:48px; padding:2px 3px; font-size:10px; background:#252c36; border:1px solid #3e4a59; border-radius:6px; font-weight:800; }
QToolButton#hardwareGlobal:hover { border-color:#58a6ff; background:#303d4d; }
QToolButton#hardwareGlobal:pressed { background:#174d74; }
QToolButton#hardwareGlobal:checked { border:2px solid #58a6ff; }
QPushButton#channelColor { padding:1px; font-weight:900; }
QPushButton#mapButton { min-height:24px; padding:4px 9px; }
QProgressBar { border:1px solid #374352; border-radius:4px; text-align:center; background:#202630; min-height:14px; max-height:14px; }
QProgressBar::chunk { background:#30bd8a; border-radius:3px; }
QSlider::groove:vertical { background:#303945; width:8px; border-radius:4px; }
QSlider::handle:vertical { background:#d8e4ef; border:1px solid #f7fafc; height:21px; margin:0 -8px; border-radius:4px; }
QCheckBox { spacing:8px; }
QTableWidget { background:#1d222a; alternate-background-color:#232a34; gridline-color:#323c49; border:1px solid #333c49; border-radius:6px; selection-background-color:#1b5b8a; }
QHeaderView::section { background:#252d38; padding:8px; border:none; border-bottom:1px solid #3a4655; font-weight:700; color:#becbd9; }
QStatusBar { background:#12151a; color:#aab8c8; }
QToolButton { background:#252d38; border:1px solid #3c4858; border-radius:4px; padding:4px; }
"""




class _MacroSequenceSignals(QObject):
    finished = pyqtSignal(str, str, bool, str)  # token, name, success, message


class _MacroSequenceWorker(QRunnable):
    """Run a validated action sequence without freezing the Qt interface."""
    def __init__(self, token: str, name: str, steps: list[tuple[str, str]], audio_engine: AudioEngine) -> None:
        super().__init__()
        self.token = token
        self.name = name
        self.steps = list(steps)
        self.audio_engine = audio_engine
        self.signals = _MacroSequenceSignals()

    def run(self) -> None:
        com_module = None
        initialized = False
        try:
            if os.name == "nt":
                import comtypes
                com_module = comtypes
                com_module.CoInitialize()
                initialized = True
            for number, (action, argument) in enumerate(self.steps, start=1):
                if action == "wait":
                    time.sleep(max(0.0, min(10.0, float(argument))))
                    continue
                ok, message = execute_action(action, argument, self.audio_engine)
                if not ok:
                    self.signals.finished.emit(self.token, self.name, False, f"Etapa {number}/{len(self.steps)} falhou: {message}")
                    return
            self.signals.finished.emit(self.token, self.name, True, f"Macro concluída ({len(self.steps)} etapas).")
        except Exception as exc:
            logging.getLogger("smc_mixer_suite").exception("Macro sequence failed: %s", self.name)
            self.signals.finished.emit(self.token, self.name, False, f"Falha na macro: {exc}")
        finally:
            if initialized and com_module is not None:
                try:
                    com_module.CoUninitialize()
                except Exception:
                    logging.getLogger("smc_mixer_suite").exception("Macro worker COM cleanup failed")


class _MicrophoneWriteSignals(QObject):
    finished = pyqtSignal(bool, float)


class _MicrophoneWriteWorker(QRunnable):
    """Set capture volume away from the GUI thread, with a COM apartment per worker."""
    def __init__(self, audio_engine: AudioEngine, scalar: float) -> None:
        super().__init__()
        self.audio_engine = audio_engine
        self.scalar = float(scalar)
        self.signals = _MicrophoneWriteSignals()

    def run(self) -> None:
        com_module = None
        initialized = False
        try:
            if os.name == "nt":
                import comtypes
                com_module = comtypes
                com_module.CoInitialize()
                initialized = True
            ok = self.audio_engine.set_microphone_volume(self.scalar)
        except Exception:
            logging.getLogger("smc_mixer_suite").exception("Microphone volume worker failed")
            ok = False
        finally:
            if initialized and com_module is not None:
                try:
                    com_module.CoUninitialize()
                except Exception:
                    logging.getLogger("smc_mixer_suite").exception("Microphone worker COM cleanup failed")
        self.signals.finished.emit(ok, self.scalar)


class _AudioPollSignals(QObject):
    finished = pyqtSignal(object)


class _AudioPollWorker(QRunnable):
    """Runs COM/pycaw polling outside the GUI thread and returns a single snapshot."""
    def __init__(self, audio_engine: AudioEngine, targets: list[str]) -> None:
        super().__init__()
        self.audio_engine = audio_engine
        self.targets = list(targets)
        self.signals = _AudioPollSignals()

    def run(self) -> None:
        com_module = None
        initialized = False
        try:
            if os.name == "nt":
                import comtypes
                com_module = comtypes
                com_module.CoInitialize()
                initialized = True
            snapshot = self.audio_engine.get_audio_snapshot(self.targets)
        except Exception as exc:
            logging.getLogger("smc_mixer_suite").exception("Audio poll worker failed")
            snapshot = {"processes": [], "volumes": {}, "mutes": {}, "error": f"Não foi possível consultar o áudio em segundo plano: {exc}"}
        finally:
            if initialized and com_module is not None:
                try:
                    com_module.CoUninitialize()
                except Exception:
                    logging.getLogger("smc_mixer_suite").exception("COM worker cleanup failed")
        self.signals.finished.emit(snapshot)



class ShortcutCaptureDialog(QDialog):
    """Capture a real keyboard chord and format it for PyAutoGUI (ctrl+shift+f9)."""
    _SPECIAL_KEYS = {
        int(Qt.Key.Key_Space): "space", int(Qt.Key.Key_Return): "enter", int(Qt.Key.Key_Enter): "enter",
        int(Qt.Key.Key_Tab): "tab", int(Qt.Key.Key_Backspace): "backspace", int(Qt.Key.Key_Delete): "delete",
        int(Qt.Key.Key_Escape): "esc", int(Qt.Key.Key_Insert): "insert", int(Qt.Key.Key_Home): "home",
        int(Qt.Key.Key_End): "end", int(Qt.Key.Key_PageUp): "pageup", int(Qt.Key.Key_PageDown): "pagedown",
        int(Qt.Key.Key_Left): "left", int(Qt.Key.Key_Right): "right", int(Qt.Key.Key_Up): "up", int(Qt.Key.Key_Down): "down",
        int(Qt.Key.Key_Print): "printscreen", int(Qt.Key.Key_Pause): "pause", int(Qt.Key.Key_CapsLock): "capslock",
        int(Qt.Key.Key_ScrollLock): "scrolllock", int(Qt.Key.Key_NumLock): "numlock",
        int(Qt.Key.Key_Minus): "-", int(Qt.Key.Key_Equal): "=", int(Qt.Key.Key_Comma): ",",
        int(Qt.Key.Key_Period): ".", int(Qt.Key.Key_Slash): "/", int(Qt.Key.Key_Backslash): "\\",
        int(Qt.Key.Key_Semicolon): ";", int(Qt.Key.Key_Apostrophe): "'", int(Qt.Key.Key_BracketLeft): "[",
        int(Qt.Key.Key_BracketRight): "]", int(Qt.Key.Key_QuoteLeft): "`",
    }
    _MODIFIER_KEYS = {int(Qt.Key.Key_Control), int(Qt.Key.Key_Shift), int(Qt.Key.Key_Alt), int(Qt.Key.Key_Meta)}

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Capturar combinação de teclado")
        self.setModal(True)
        self.setMinimumWidth(390)
        self.shortcut = ""
        layout = QVBoxLayout(self)
        title = QLabel("Pressione a combinação que deseja capturar")
        title.setObjectName("section")
        layout.addWidget(title)
        self.instruction = QLabel("Exemplo: Ctrl + Shift + M\nA captura termina quando você pressionar a tecla principal.")
        self.instruction.setWordWrap(True)
        self.instruction.setObjectName("muted")
        layout.addWidget(self.instruction)
        self.preview = QLabel("Aguardando teclado…")
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumHeight(54)
        self.preview.setStyleSheet("font-size:18px;font-weight:800;border:1px solid #435064;border-radius:8px;padding:10px;")
        layout.addWidget(self.preview)
        row = QHBoxLayout()
        cancel = QPushButton("Cancelar")
        cancel.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        cancel.clicked.connect(self.reject)
        row.addStretch(1)
        row.addWidget(cancel)
        layout.addLayout(row)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setFocus()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self.activateWindow()
        self.setFocus()

    @classmethod
    def _key_name(cls, event) -> str | None:
        key = event.key()
        for function_number in range(1, 36):
            if key == int(getattr(Qt.Key, f"Key_F{function_number}")):
                return f"f{function_number}"
        if key in cls._SPECIAL_KEYS:
            return cls._SPECIAL_KEYS[key]
        text = (event.text() or "").strip().lower()
        if len(text) == 1 and (text.isalnum() or text in "-=[]\\;',./`\\"):
            return text
        return None

    def keyPressEvent(self, event) -> None:
        mods = event.modifiers()
        modifiers = []
        if mods & Qt.KeyboardModifier.ControlModifier: modifiers.append("ctrl")
        if mods & Qt.KeyboardModifier.AltModifier: modifiers.append("alt")
        if mods & Qt.KeyboardModifier.ShiftModifier: modifiers.append("shift")
        if mods & Qt.KeyboardModifier.MetaModifier: modifiers.append("win")
        key_name = self._key_name(event)
        if key_name is None:
            if int(event.key()) in self._MODIFIER_KEYS:
                self.preview.setText(" + ".join(modifiers) if modifiers else "Segure a combinação…")
                event.accept()
                return
            self.preview.setText("Tecla não suportada; tente outra combinação.")
            event.accept()
            return
        parts = modifiers + [key_name]
        self.shortcut = "+".join(parts)
        self.preview.setText(self.shortcut.upper())
        self.accept()
        event.accept()


class _BatteryProbeSignals(QObject):
    finished = pyqtSignal(object)


class _BatteryProbeWorker(QRunnable):
    """Runs BLE GATT battery discovery away from the GUI thread."""
    def __init__(self) -> None:
        super().__init__()
        self.signals = _BatteryProbeSignals()

    def run(self) -> None:
        try:
            result = probe_smc_battery(timeout=7.0)
        except Exception as exc:
            result = {"level": None, "charging": None, "device": None, "error": str(exc)}
        self.signals.finished.emit(result)


class _BrightnessWriteSignals(QObject):
    finished = pyqtSignal(object)


class _BrightnessWriteWorker(QRunnable):
    """Apply display brightness writes off the GUI thread."""
    def __init__(self, audio_engine: AudioEngine, updates: dict[str, float]) -> None:
        super().__init__()
        self.audio_engine = audio_engine
        self.updates = dict(updates)
        self.signals = _BrightnessWriteSignals()

    def run(self) -> None:
        com_module = None
        initialized = False
        try:
            # WMI-based brightness backends may use COM. Initialize it inside
            # this worker thread instead of relying on the GUI thread's COM apartment.
            if os.name == "nt":
                import comtypes
                com_module = comtypes
                com_module.CoInitialize()
                initialized = True
            result = self.audio_engine.set_volumes(self.updates)
        except Exception as exc:
            result = {target: False for target in self.updates}
            logging.getLogger("smc_mixer_suite").exception("Brightness write failed: %s", exc)
        finally:
            if initialized and com_module is not None:
                try:
                    com_module.CoUninitialize()
                except Exception:
                    logging.getLogger("smc_mixer_suite").exception("Brightness worker COM cleanup failed")
        self.signals.finished.emit(result)


def midi_key(msg_type: str, channel: int, number: int) -> str:
    if msg_type in ("note_on", "note_off"):
        return f"note:{channel}:{number}"
    if msg_type == "cc":
        return f"cc:{channel}:{number}"
    if msg_type == "pitch":
        return f"pitch:{channel}:{number}"
    return f"{msg_type}:{channel}:{number}"


def midi_key_label(key: str | None) -> str:
    if not key:
        return "Não mapeado"
    try:
        kind, channel, number = key.split(":")
        channel_n = int(channel) + 1
        if kind == "cc":
            return f"CC {number} · canal {channel_n}"
        if kind == "note":
            return f"Nota {number} · canal {channel_n}"
        if kind == "pitch":
            return f"Pitch · canal {channel_n}"
    except Exception:
        pass
    return key


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"SMC Mixer Suite Professional {__version__} · Rafael Souza")
        # Adapt initial geometry to the usable desktop instead of forcing a window
        # larger than common 1366×768 / 1920×1080 displays.
        screen = QApplication.primaryScreen()
        available = screen.availableGeometry() if screen is not None else None
        if available is not None:
            self.setMinimumSize(min(1024, available.width()), min(600, available.height()))
            self.resize(min(1540, available.width()), min(960, available.height()))
        else:
            self.resize(1360, 820)
            self.setMinimumSize(900, 560)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setStyleSheet(DARK_STYLE)

        self.store = ConfigStore()
        self._comtypes = None
        self._com_initialized = False
        if os.name == "nt":
            try:
                import comtypes
                self._comtypes = comtypes
                comtypes.CoInitialize()
                self._com_initialized = True
            except Exception:
                logging.getLogger("smc_mixer_suite").exception("Não foi possível inicializar COM na thread de interface")
        self.audio = AudioEngine()
        self._audio_poll_pool = QThreadPool(self)
        self._audio_poll_pool.setMaxThreadCount(1)
        self._audio_poll_pending = False
        self._audio_poll_worker = None
        self._last_volumes: dict[str, float | None] = {}
        self._last_mutes: dict[str, bool | None] = {}
        self._last_audio_error = ""
        self._last_levels_db: dict[str, float | None] = {}
        self._last_levels_are_peak: dict[str, bool] = {}
        self._pending_volume_updates: dict[str, float] = {}
        self._volume_apply_timer = QTimer(self)
        self._volume_apply_timer.setSingleShot(True)
        self._volume_apply_timer.setInterval(18)  # coalesce rapid MIDI/fader samples to ~55 Hz
        self._volume_apply_timer.timeout.connect(self._apply_pending_volume_updates)
        self._brightness_write_pool = QThreadPool(self)
        self._brightness_write_pool.setMaxThreadCount(1)
        self._pending_brightness_updates: dict[str, float] = {}
        self._brightness_worker_active = False
        self._brightness_write_worker = None
        self._microphone_write_pool = QThreadPool(self)
        self._microphone_write_pool.setMaxThreadCount(1)
        self._microphone_write_pending: float | None = None
        self._microphone_write_active = False
        self._microphone_write_worker = None
        self._microphone_write_timer = QTimer(self)
        self._microphone_write_timer.setSingleShot(True)
        self._microphone_write_timer.setInterval(35)
        self._microphone_write_timer.timeout.connect(self._dispatch_microphone_write)
        self._battery_pool = QThreadPool(self)
        self._battery_pool.setMaxThreadCount(1)
        self._battery_probe_pending = False
        self._battery_previous_sample: tuple[int, float] | None = None
        self._battery_previous_charging: bool | None = None
        self._battery_rate_pct_per_min: float | None = None
        self._battery_last_result: dict[str, Any] | None = None
        self.learning_target: tuple[str, Any] | None = None
        self._learn_timer = QTimer(self)
        self._learn_timer.setSingleShot(True)
        self._learn_timer.setInterval(15000)
        self._learn_timer.timeout.connect(self._cancel_midi_learn_timeout)
        self._loading = False
        self._allow_exit = False
        self._midi_values: dict[str, int] = {}
        self._learn_conflict_notice: dict[str, float] = {}
        self._button_press_gate = MidiButtonPressGate(min_interval=0.045, repeat_cc_interval=0.075)
        self._analog_learn_sampler = AnalogLearnSampler()
        self._fader_motion_guard = AnalogCCMotionGuard()
        self._analog_learn_last_hint = 0.0
        self._pending_analog_midi: dict[str, tuple[str, int, int, int]] = {}
        self._processing_coalesced_midi = False
        self._last_fader_applied: dict[str, int] = {}
        self._knob_probe_samples: dict[str, list[int]] = {}
        self._detected_knob_modes: dict[str, str] = {}
        self._last_session_refresh = 0.0
        self._process_cache: list[dict[str, Any]] = []
        self._selected_channel = 0
        self._connected_port_name = ""
        self._eq_ab_active_slot: str | None = None
        self._solo_snapshot: dict[str, bool] | None = None
        self._solo_channel: int | None = None
        self._bank_names = ["Banco 1", "Banco 2", "Banco 3", "Banco 4"]
        self._shift_active = False
        self.global_buttons: dict[str, QToolButton] = {}
        self._action_pool = QThreadPool.globalInstance()
        self._active_macro_workers: dict[str, _MacroSequenceWorker] = {}
        self._midi_event_log: list[str] = []

        self._eq_save_timer = QTimer(self)
        self._eq_save_timer.setSingleShot(True)
        self._eq_save_timer.setInterval(90)
        self._eq_save_timer.timeout.connect(self._write_eq_file)
        self._eq_link_verify_timer = QTimer(self)
        self._eq_link_verify_timer.setSingleShot(True)
        self._eq_link_verify_timer.setInterval(3500)
        self._eq_link_verify_timer.timeout.connect(self._write_eq_file)
        self._profile_save_timer = QTimer(self)
        self._profile_save_timer.setSingleShot(True)
        self._profile_save_timer.setInterval(220)
        self._profile_save_timer.timeout.connect(self._save_profile)
        # Coalesce continuous analog input to ~60 Hz. This keeps faders responsive
        # while preventing a burst of MIDI CC packets from flooding the GUI thread.
        self._analog_midi_timer = QTimer(self)
        self._analog_midi_timer.setSingleShot(True)
        self._analog_midi_timer.setInterval(16)
        self._analog_midi_timer.timeout.connect(self._flush_pending_analog_midi)

        # Debounce resize-driven relayout. Starting a single persistent timer is
        # safer than queueing a new singleShot for every mouse-move resize event.
        self._responsive_layout_timer = QTimer(self)
        self._responsive_layout_timer.setSingleShot(True)
        self._responsive_layout_timer.setInterval(45)
        self._responsive_layout_timer.timeout.connect(self._apply_responsive_layout)

        self._create_ui()
        self.hud = HudOverlay()
        self.hud.set_options(
            enabled=bool(self.store.data.get("show_action_hud", True)),
            position=str(self.store.data.get("hud_position", "bottom_right")),
            duration_ms=int(self.store.data.get("hud_duration_ms", 1180)),
        )
        self._create_tray()
        self._battery_poll_timer = QTimer(self)
        self._battery_poll_timer.setInterval(300000)
        self._battery_poll_timer.timeout.connect(self._request_battery_probe)
        self._load_profile_to_ui()
        self._apply_theme(save=False)

        self.midi = MidiEngine(self.store.data.get("midi_port", "AUTO"), self)
        self.midi.message_received.connect(self._on_midi_message)
        self.midi.status_changed.connect(self._on_midi_status)
        self.midi.ports_changed.connect(self._on_midi_ports)
        self.midi.start()

        self.led_engine = LedAnimationEngine(self)
        self.led_engine.status_changed.connect(self._on_led_engine_status)
        self.led_engine.start()
        self._sync_led_engine_settings()

        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(550)
        self._refresh_timer.timeout.connect(self._refresh_audio_ui)
        self._refresh_timer.start()
        self._refresh_audio_ui()
        self.statusBar().showMessage(f"SMC Mixer Suite Professional {__version__} · Desenvolvido por Rafael Souza · Configuração local: {APP_DIR}")
        if getattr(self.store, "mapping_repair_warnings", None):
            QTimer.singleShot(900, self._show_mapping_repair_warning)

    @property
    def profile(self) -> dict[str, Any]:
        return self.store.profile

    @property
    def active_bank(self) -> dict[str, Any]:
        return self.store.active_bank(self.profile)

    def _current_target(self, index: int) -> str:
        targets = self.active_bank.get("fader_targets", [])
        return str(targets[index] if index < len(targets) else "")

    def _current_channel_name(self, index: int) -> str:
        names = self.active_bank.get("channel_names", [])
        return str(names[index] if index < len(names) else f"Canal {index + 1}")

    def _create_ui(self) -> None:
        central = QWidget(self)
        root = QVBoxLayout(central)
        root.setContentsMargins(9, 7, 9, 6)
        root.setSpacing(5)

        header = QHBoxLayout()
        title_col = QVBoxLayout()
        title_col.setSpacing(1)
        title = QLabel("SMC MIXER SUITE PROFESSIONAL")
        title.setObjectName("title")
        subtitle = QLabel("Superfície de controle · Áudio do Windows · Automação · Equalizador global")
        subtitle.setObjectName("subtitle")
        title_col.addWidget(title)
        title_col.addWidget(subtitle)
        header.addLayout(title_col, 1)

        header.addWidget(QLabel("PERFIL"))
        self.profile_combo = QComboBox()
        self.profile_combo.setMinimumWidth(110)
        self.profile_combo.currentTextChanged.connect(self._on_profile_selected)
        header.addWidget(self.profile_combo)
        for label, callback in (("Novo", self._new_profile), ("Duplicar", self._clone_profile)):
            button = QPushButton(label)
            button.clicked.connect(callback)
            header.addWidget(button)
        self.delete_profile_btn = QPushButton("Excluir")
        self.delete_profile_btn.setObjectName("danger")
        self.delete_profile_btn.clicked.connect(self._delete_profile)
        header.addWidget(self.delete_profile_btn)
        root.addLayout(header)

        status_row = QHBoxLayout()
        self.connection_dot = QLabel("●")
        self.connection_dot.setStyleSheet("color:#d6a84e; font-size:16px;")
        status_row.addWidget(self.connection_dot)
        self.connection_label = QLabel("MIDI: inicializando…")
        self.connection_label.setObjectName("muted")
        status_row.addWidget(self.connection_label, 1)
        self.bank_label = QLabel("BANCO 1 / 4")
        self.bank_label.setStyleSheet("padding:5px 10px; background:#202630; border:1px solid #394453; border-radius:5px; color:#c4d4e5; font-weight:800;")
        status_row.addWidget(self.bank_label)
        self.bt_label = QLabel("Transporte: aguardando porta MIDI")
        self.bt_label.setObjectName("muted")
        status_row.addWidget(self.bt_label)
        root.addLayout(status_row)

        device_row = QHBoxLayout()
        device_row.setSpacing(12)
        self.transport_label = QLabel("Conexão física: aguardando")
        self.transport_label.setStyleSheet("padding:4px 8px;background:#202630;border:1px solid #394453;border-radius:5px;font-weight:750;")
        device_row.addWidget(self.transport_label, 1)
        battery_panel = QFrame()
        battery_panel.setObjectName("panel")
        battery_layout = QVBoxLayout(battery_panel)
        battery_layout.setContentsMargins(8, 3, 8, 3)
        battery_layout.setSpacing(1)
        self.battery_label = QLabel("Bateria SMC: N/D")
        self.battery_label.setStyleSheet("font-weight:800;")
        self.charge_label = QLabel("Carga: não informada pelo dispositivo")
        self.charge_label.setObjectName("muted")
        self.battery_eta_label = QLabel("Tempo até carga completa: indisponível")
        self.battery_eta_label.setObjectName("muted")
        battery_layout.addWidget(self.battery_label)
        battery_layout.addWidget(self.charge_label)
        battery_layout.addWidget(self.battery_eta_label)
        device_row.addWidget(battery_panel, 2)
        self.battery_probe_btn = QPushButton("Ler bateria BLE")
        self.battery_probe_btn.setToolTip("Consulta a característica padrão Bluetooth Battery Service, se o firmware a disponibilizar. Em Bluetooth MIDI, leia sob demanda; uma conexão GATT extra pode disputar a conexão BLE do driver.")
        self.battery_probe_btn.clicked.connect(self._request_battery_probe)
        device_row.addWidget(self.battery_probe_btn)
        root.addLayout(device_row)

        self.tabs = QTabWidget()
        self.tabs.setUsesScrollButtons(False)
        self.tabs.setDocumentMode(True)
        self.tabs.setObjectName("mainTabs")
        self.tabs.setMovable(False)
        self.tabs.tabBar().setObjectName("mainTabBar")
        self.tabs.tabBar().setExpanding(False)
        self.tabs.tabBar().setElideMode(Qt.TextElideMode.ElideNone)
        self.tabs.tabBar().setDrawBase(False)
        # Keep actual page references. Navigation must use indexOf(page), not
        # hard-coded tab numbers (the previous code sent MIDI Learn to Windows).
        self._windows_page = self._build_windows_tab()
        self._buttons_page = self._build_buttons_tab()
        tab_definitions = [
            (self._build_hardware_tab(), "Console", "Console físico · oito faders, oito knobs e controles de transporte"),
            (self._windows_page, "Windows", "Windows · áudio, monitores, ações rápidas e configuração simples dos botões"),
            (self._buttons_page, "Botões / MIDI", "Assistente simples para ações e aprendizado MIDI; tabela avançada opcional"),
            (self._build_eq_tab(), "Equalizador", "Equalizador global com knobs circulares"),
            (self._build_led_tab(), "LEDs", "LEDs físicos, animações e feedback"),
            (self._build_settings_tab(), "Ajustes", "Configurações, conexão, temas e diagnóstico"),
        ]
        for widget, caption, tooltip in tab_definitions:
            index = self.tabs.addTab(widget, caption)
            self.tabs.setTabToolTip(index, tooltip)
        root.addWidget(self.tabs, 1)
        brand_footer = QLabel(f"Desenvolvido por Rafael Souza  ·  SMC Mixer Suite Professional {__version__}")
        brand_footer.setObjectName("muted")
        brand_footer.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        brand_footer.setMinimumHeight(21)
        root.addWidget(brand_footer)
        self.setCentralWidget(central)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        # Restart one timer while resizing so a drag queues at most one layout
        # pass after the user pauses, avoiding repeated card rebuilds and jitter.
        timer = getattr(self, "_responsive_layout_timer", None)
        if timer is not None and hasattr(self, "eq_controls"):
            timer.start()

    def _apply_responsive_layout(self) -> None:
        """Keep the surface and EQ readable across common laptop/monitor sizes."""
        if not hasattr(self, "store"):
            return
        compact = effective_compact_mode(
            bool(self.store.data.get("compact_ui", False)), self.width(), self.height()
        )
        previous = getattr(self, "_effective_compact", None)
        if previous is None or compact != previous:
            self._effective_compact = compact
            self._apply_theme(save=False)
        if hasattr(self, "channel_strips"):
            available_width = self.tabs.width() if hasattr(self, "tabs") else self.width()
            strip_width = recommended_channel_strip_width(available_width)
            for strip in self.channel_strips:
                strip.set_adaptive_width(compact or strip_width < 116, strip_width)
        if hasattr(self, "eq_bands_widget"):
            self._relayout_eq_bands_for_width()
            self._fit_eq_knobs_to_cards()

    def _build_hardware_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(5, 5, 5, 4)
        layout.setSpacing(4)

        board_title_row = QHBoxLayout()
        title = QLabel("M-VAVE SMC-MIXER · CONSOLE")
        title.setObjectName("section")
        board_title_row.addWidget(title, 1)
        board_title_row.addWidget(QLabel("8 knobs · 8 faders · 4 botões/canal"))
        self.knob_target_combo = QComboBox()
        self.knob_target_combo.addItem("Knobs → EQ global", "eq")
        self.knob_target_combo.addItem("Knobs → ganho do app", "app_gain")
        self.knob_target_combo.currentIndexChanged.connect(self._on_knob_target_mode_changed)
        self.knob_target_combo.setMinimumWidth(170)
        board_title_row.addWidget(self.knob_target_combo)
        layout.addLayout(board_title_row)

        board = QFrame()
        board.setObjectName("panel")
        board_layout = QVBoxLayout(board)
        board_layout.setContentsMargins(5, 4, 5, 4)
        board_layout.setSpacing(3)
        board_header = QHBoxLayout()
        board_header.addWidget(QLabel("M-VAVE SMC-MIXER"))
        board_header.addStretch(1)
        board_header.addWidget(QLabel("Knobs circulares · volumes em faders verticais"))
        board_layout.addLayout(board_header)

        self.channel_strips: list[ChannelStrip] = []
        strip_container = QWidget()
        strip_layout = QHBoxLayout(strip_container)
        strip_layout.setContentsMargins(1, 0, 1, 0)
        strip_layout.setSpacing(4)
        for index in range(8):
            strip = ChannelStrip(index)
            strip.faderChanged.connect(self._on_ui_fader_changed)
            strip.knobChanged.connect(self._on_ui_knob_changed)
            strip.knobResetRequested.connect(self._on_hardware_knob_double_click)
            strip.targetChanged.connect(self._on_fader_target_changed)
            strip.nameCommitted.connect(self._on_channel_name_changed)
            strip.colorChangeRequested.connect(self._choose_channel_color)
            strip.learnRequested.connect(self._start_learn)
            strip.buttonActivated.connect(self._on_virtual_button_pressed)
            strip.buttonContextRequested.connect(self._show_button_context_menu)
            self.channel_strips.append(strip)
            strip_layout.addWidget(strip, 1)
        strip_container.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        board_layout.addWidget(strip_container, 1)
        layout.addWidget(board, 1)

        # Compact transport/navigation row: reserves the majority of the tab height
        # for the eight vertical volume faders instead of oversized button panels.
        globals_row = QHBoxLayout()
        globals_row.setContentsMargins(1, 0, 1, 0)
        globals_row.setSpacing(5)
        for control_id in ("transport_rewind", "transport_play_pause", "transport_rec", "transport_ff",
                           "bank_left", "bank_right", "nav_up", "nav_down", "nav_left", "nav_right", "shift"):
            globals_row.addWidget(self._make_global_button(control_id), 1)
        layout.addLayout(globals_row)

        foot = QLabel("M / S / R / □: clique para executar · botão direito para configurar. Faders = volume; knobs = EQ/ganho.")
        foot.setObjectName("muted")
        foot.setWordWrap(False)
        foot.setMinimumHeight(18)
        foot.setMaximumHeight(21)
        layout.addWidget(foot)
        return tab

    def _global_button_caption(self, control_id: str) -> str:
        captions = {
            "transport_rewind": "REW", "transport_play_pause": "PLAY / PAUSE",
            "transport_rec": "REC", "transport_ff": "FF",
            "bank_left": "BANK −", "bank_right": "BANK +",
            "nav_up": "CIMA", "nav_down": "BAIXO", "nav_left": "ESQ.", "nav_right": "DIR.",
            "shift": "SHIFT",
        }
        return captions.get(control_id, BUTTON_SPEC_BY_ID[control_id].label)

    def _global_button_icon(self, control_id: str) -> QIcon:
        style = QApplication.style()
        mapping = {
            "transport_rewind": QStyle.StandardPixmap.SP_MediaSeekBackward,
            "transport_play_pause": QStyle.StandardPixmap.SP_MediaPlay,
            "transport_ff": QStyle.StandardPixmap.SP_MediaSeekForward,
            "bank_left": QStyle.StandardPixmap.SP_ArrowLeft,
            "bank_right": QStyle.StandardPixmap.SP_ArrowRight,
            "nav_up": QStyle.StandardPixmap.SP_ArrowUp,
            "nav_down": QStyle.StandardPixmap.SP_ArrowDown,
            "nav_left": QStyle.StandardPixmap.SP_ArrowLeft,
            "nav_right": QStyle.StandardPixmap.SP_ArrowRight,
            "shift": QStyle.StandardPixmap.SP_BrowserReload,
        }
        if control_id == "transport_rec":
            pixmap = QPixmap(36, 36)
            pixmap.fill(Qt.GlobalColor.transparent)
            painter = QPainter(pixmap)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            painter.setPen(QPen(QColor("#ff5b64"), 2))
            painter.setBrush(QColor("#ff3448"))
            painter.drawEllipse(7, 7, 22, 22)
            painter.end()
            return QIcon(pixmap)
        standard = mapping.get(control_id)
        return style.standardIcon(standard) if standard is not None else QIcon()

    def _make_global_button(self, control_id: str) -> QToolButton:
        spec = BUTTON_SPEC_BY_ID[control_id]
        button = QToolButton()
        button.setObjectName("hardwareGlobal")
        button.setText(self._global_button_caption(control_id))
        button.setIcon(self._global_button_icon(control_id))
        button.setIconSize(QSize(20, 20))
        button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        button.setMinimumSize(48, 46)
        button.setMaximumHeight(50)
        button.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        button.setToolTip(f"{spec.help_text}. Clique para executar; botão direito abre o assistente simples de ação/MIDI.")
        button.clicked.connect(lambda _checked=False, cid=control_id: self._on_virtual_button_pressed(cid))
        button.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        button.customContextMenuRequested.connect(lambda pos, cid=control_id, b=button: self._show_button_context_menu(cid, b.mapToGlobal(pos)))
        self.global_buttons[control_id] = button
        return button

    def _build_buttons_tab(self) -> QWidget:
        """Simple first-run workflow, with the legacy table kept under Advanced."""
        tab = QWidget()
        self._buttons_page = tab
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(10, 9, 10, 8)
        layout.setSpacing(8)

        title = QLabel("Configurar botões físicos")
        title.setObjectName("section")
        layout.addWidget(title)
        intro = QLabel(
            "O jeito mais fácil: clique com o botão direito no botão da superfície que deseja configurar "
            "(M, S, R, selecionar ou transporte) e escolha ‘Configurar ação / MIDI’. Também pode escolher "
            "o controle abaixo. Depois selecione a ação e clique em ‘Salvar e associar botão físico’; "
            "quando o programa pedir, pressione uma vez o botão correspondente no M-VAVE."
        )
        intro.setWordWrap(True)
        intro.setObjectName("muted")
        layout.addWidget(intro)

        quick_box = QGroupBox("Assistente rápido · 3 passos")
        quick_box.setObjectName("panel")
        quick_layout = QGridLayout(quick_box)
        quick_layout.setContentsMargins(12, 12, 12, 12)
        quick_layout.setHorizontalSpacing(10)
        quick_layout.setVerticalSpacing(9)

        target_label = QLabel("1. Controle que você quer configurar")
        self.simple_button_target_combo = QComboBox()
        self.simple_button_target_combo.setMinimumWidth(240)
        self.simple_button_target_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._fill_button_target_combo(self.simple_button_target_combo, "transport_play_pause")
        self.simple_button_target_combo.currentIndexChanged.connect(self._load_simple_button_editor)
        quick_layout.addWidget(target_label, 0, 0)
        quick_layout.addWidget(self.simple_button_target_combo, 0, 1, 1, 2)

        action_label = QLabel("2. O que esse botão deve fazer?")
        self.simple_button_action_combo = QComboBox()
        self.simple_button_action_combo.setMinimumWidth(240)
        self.simple_button_action_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        previous_group = None
        for label, key in SIMPLE_BUTTON_ACTION_OPTIONS:
            if key in {"__default__", "none"}:
                group = "default"
            elif key.startswith("media_"):
                group = "media"
            elif key in {"mute_master", "mute_microphone"} or key.startswith("win_"):
                group = "windows"
            elif key.startswith("channel_"):
                group = "channel"
            elif key.startswith("bank_") or key == "shift_toggle":
                group = "navigation"
            elif key.startswith("custom_"):
                group = "custom"
            else:
                group = "other"
            if previous_group is not None and group != previous_group:
                self.simple_button_action_combo.insertSeparator(self.simple_button_action_combo.count())
            self.simple_button_action_combo.addItem(label, key)
            previous_group = group
        self.simple_button_action_combo.currentIndexChanged.connect(self._update_simple_button_argument_ui)
        quick_layout.addWidget(action_label, 1, 0)
        quick_layout.addWidget(self.simple_button_action_combo, 1, 1, 1, 2)

        self.simple_button_argument_label = QLabel("Detalhe")
        self.simple_button_argument_edit = QLineEdit()
        self.simple_button_argument_edit.setClearButtonEnabled(True)
        self.simple_button_argument_edit.setPlaceholderText("Só será necessário para algumas ações")
        self.simple_button_argument_label.setVisible(False)
        self.simple_button_argument_edit.setVisible(False)
        self.simple_button_argument_row = QWidget()
        argument_row_layout = QHBoxLayout(self.simple_button_argument_row)
        argument_row_layout.setContentsMargins(0, 0, 0, 0)
        argument_row_layout.setSpacing(6)
        argument_row_layout.addWidget(self.simple_button_argument_edit, 1)
        self.simple_button_capture_shortcut_btn = QPushButton("Capturar atalho")
        self.simple_button_capture_shortcut_btn.setToolTip("Pressione a combinação no teclado; não precisa digitar ctrl+shift+m manualmente.")
        self.simple_button_capture_shortcut_btn.clicked.connect(self._capture_simple_button_shortcut)
        self.simple_button_capture_shortcut_btn.setVisible(False)
        argument_row_layout.addWidget(self.simple_button_capture_shortcut_btn)
        self.simple_button_argument_row.setVisible(False)
        quick_layout.addWidget(self.simple_button_argument_label, 2, 0)
        quick_layout.addWidget(self.simple_button_argument_row, 2, 1, 1, 2)

        action_buttons = QGridLayout()
        action_buttons.setHorizontalSpacing(8)
        action_buttons.setVerticalSpacing(7)
        self.simple_button_learn_btn = QPushButton("1 · Salvar e associar botão físico")
        self.simple_button_learn_btn.setObjectName("primary")
        self.simple_button_learn_btn.setMinimumHeight(36)
        self.simple_button_learn_btn.setToolTip("Salva a ação escolhida e aguarda um clique no botão físico do M-VAVE.")
        self.simple_button_learn_btn.clicked.connect(lambda: self._save_simple_button_action(start_learn=True))
        action_buttons.addWidget(self.simple_button_learn_btn, 0, 0)
        self.simple_button_test_btn = QPushButton("Testar ação")
        self.simple_button_test_btn.setMinimumHeight(36)
        self.simple_button_test_btn.setToolTip("Testa a ação sem precisar pressionar o M-VAVE.")
        self.simple_button_test_btn.clicked.connect(self._test_simple_button_action)
        action_buttons.addWidget(self.simple_button_test_btn, 0, 1)
        self.simple_button_save_btn = QPushButton("Salvar ação sem mapear agora")
        self.simple_button_save_btn.clicked.connect(lambda: self._save_simple_button_action(start_learn=False))
        action_buttons.addWidget(self.simple_button_save_btn, 1, 0)
        self.simple_button_unmap_btn = QPushButton("Remover associação física")
        self.simple_button_unmap_btn.clicked.connect(self._unmap_simple_button_midi)
        action_buttons.addWidget(self.simple_button_unmap_btn, 1, 1)
        action_buttons.setColumnStretch(0, 3)
        action_buttons.setColumnStretch(1, 2)
        quick_layout.addLayout(action_buttons, 3, 0, 1, 3)

        self.simple_button_status_label = QLabel("Selecione um controle para ver sua configuração.")
        self.simple_button_status_label.setObjectName("muted")
        self.simple_button_status_label.setWordWrap(True)
        quick_layout.addWidget(self.simple_button_status_label, 4, 0, 1, 3)

        self.simple_button_signal_toggle = QToolButton()
        self.simple_button_signal_toggle.setText("Se o botão não responder: ajustar tipo de sinal (opcional)")
        self.simple_button_signal_toggle.setCheckable(True)
        self.simple_button_signal_toggle.setChecked(False)
        self.simple_button_signal_toggle.setArrowType(Qt.ArrowType.RightArrow)
        self.simple_button_signal_toggle.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        quick_layout.addWidget(self.simple_button_signal_toggle, 5, 0, 1, 3)
        self.simple_button_signal_panel = QWidget()
        signal_layout = QVBoxLayout(self.simple_button_signal_panel)
        signal_layout.setContentsMargins(8, 3, 8, 5)
        signal_row = QHBoxLayout()
        signal_row.addWidget(QLabel("Como o botão está configurado no programa da M-VAVE?"))
        self.simple_button_trigger_combo = QComboBox()
        self.simple_button_trigger_combo.addItem("Mensagem Note (recomendado / seguro)", "note")
        self.simple_button_trigger_combo.addItem("Automático (compatibilidade)", "auto")
        self.simple_button_trigger_combo.addItem("Um evento por clique (CC Single / Toggle)", "cc_single_toggle")
        self.simple_button_trigger_combo.addItem("Pressionar e soltar (CC Push)", "cc_push")
        self.simple_button_trigger_combo.setMinimumWidth(260)
        signal_row.addWidget(self.simple_button_trigger_combo, 1)
        signal_layout.addLayout(signal_row)
        signal_help = QLabel(
            "Use Mensagem Note para botões do SMC-Mixer; isso evita confundir botões com faders/knobs CC. "
            "Use modos CC somente quando tiver confirmado a configuração no MidiSuite da M-VAVE. "
            "CC Single/Toggle alterna eventos; CC Push envia valor ao apertar e zero ao soltar. "
            "Salve a ação antes de testar."
        )
        signal_help.setWordWrap(True)
        signal_help.setObjectName("muted")
        signal_layout.addWidget(signal_help)
        self.simple_button_signal_panel.setVisible(False)
        quick_layout.addWidget(self.simple_button_signal_panel, 6, 0, 1, 3)
        self.simple_button_signal_toggle.toggled.connect(self._set_simple_signal_panel_visible)

        layout.addWidget(quick_box)
        usage_hint = QLabel(
            "Dica: mapear é só associar um sinal físico a uma função. Para volume, use ‘Aprender fader’ "
            "no console; para encoder, use ‘Aprender knob’. Esta página é para botões e ações do Windows."
        )
        usage_hint.setWordWrap(True)
        usage_hint.setObjectName("muted")
        layout.addWidget(usage_hint)

        self.button_advanced_toggle = QToolButton()
        self.button_advanced_toggle.setText("Mostrar tabela avançada (opcional)")
        self.button_advanced_toggle.setCheckable(True)
        self.button_advanced_toggle.setChecked(False)
        self.button_advanced_toggle.setArrowType(Qt.ArrowType.RightArrow)
        self.button_advanced_toggle.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.button_advanced_toggle.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        layout.addWidget(self.button_advanced_toggle)

        self.button_advanced_panel = QWidget()
        advanced_layout = QVBoxLayout(self.button_advanced_panel)
        advanced_layout.setContentsMargins(0, 0, 0, 0)
        advanced_layout.setSpacing(5)
        self.button_advanced_panel.setVisible(False)
        self.button_advanced_toggle.toggled.connect(self._set_button_advanced_visible)

        info = QLabel(
            "Modo avançado: edição individual de argumentos, captura de atalhos e pesquisa dos 43 controles. "
            "Use o assistente acima para as tarefas comuns."
        )
        info.setWordWrap(True)
        info.setObjectName("muted")
        advanced_layout.addWidget(info)

        search_row = QHBoxLayout()
        self.button_search_edit = QLineEdit()
        self.button_search_edit.setPlaceholderText("Pesquisar controle, ação ou entrada MIDI…")
        self.button_search_edit.setClearButtonEnabled(True)
        self.button_search_edit.textChanged.connect(self._filter_button_table)
        search_row.addWidget(self.button_search_edit, 1)
        self.button_search_count = QLabel(f"{len(BUTTON_SPECS)} controles")
        self.button_search_count.setObjectName("muted")
        search_row.addWidget(self.button_search_count)
        advanced_layout.addLayout(search_row)

        pager = QHBoxLayout()
        self.button_prev_page_btn = QPushButton("‹ Anterior")
        self.button_prev_page_btn.clicked.connect(lambda: self._change_button_page(-1))
        pager.addWidget(self.button_prev_page_btn)
        self.button_page_label = QLabel("Página 1/1")
        self.button_page_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.button_page_label.setObjectName("muted")
        pager.addWidget(self.button_page_label, 1)
        self.button_next_page_btn = QPushButton("Próxima ›")
        self.button_next_page_btn.clicked.connect(lambda: self._change_button_page(1))
        pager.addWidget(self.button_next_page_btn)
        advanced_layout.addLayout(pager)

        self._button_page_size = 7
        self._button_page = 0
        self._button_filtered_specs = list(BUTTON_SPECS)
        self._button_page_specs = []
        self.button_table = QTableWidget(0, 6)
        self.button_table.setHorizontalHeaderLabels(["Controle", "Entrada MIDI", "Ação", "Argumento", "Capturar tecla", "Mapear"])
        self.button_table.verticalHeader().setVisible(False)
        self.button_table.setAlternatingRowColors(True)
        self.button_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.button_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.button_table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.button_table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.button_table.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerItem)
        self.button_table.verticalHeader().setDefaultSectionSize(29)
        for column in (0, 1, 2, 4, 5):
            self.button_table.horizontalHeader().setSectionResizeMode(column, QHeaderView.ResizeMode.Fixed)
        self.button_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        for column, width in ((0, 132), (1, 132), (2, 160), (4, 105), (5, 85)):
            self.button_table.setColumnWidth(column, width)
        self.button_table.setToolTip("Modo avançado: edite ações e argumentos por controle.")
        self.button_table.setMinimumHeight(7 * 29 + 30)
        self.button_table.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        advanced_layout.addWidget(self.button_table, 1)

        footer = QHBoxLayout()
        footer.addWidget(QLabel("Configuração salva localmente no perfil atual."), 1)
        self.unmap_selected_btn = QPushButton("Desmapear selecionado")
        self.unmap_selected_btn.clicked.connect(self._unmap_selected_button)
        footer.addWidget(self.unmap_selected_btn)
        self.reset_button_map_btn = QPushButton("Restaurar padrões")
        self.reset_button_map_btn.clicked.connect(self._reset_button_actions)
        footer.addWidget(self.reset_button_map_btn)
        advanced_layout.addLayout(footer)

        layout.addWidget(self.button_advanced_panel, 1)
        self._load_simple_button_editor()
        return tab

    def _button_choice_label(self, spec) -> str:
        """Human-readable button names; never expose internal control IDs."""
        if spec.channel is not None:
            channel_name = self._current_channel_name(spec.channel)
            action_labels = {
                "M": "Mute",
                "S": "Solo",
                "R": "Gravação / ação",
                "SELECT": "Selecionar canal",
            }
            physical_name = action_labels.get(spec.key or "", spec.help_text or spec.label)
            return f"Canal {spec.channel + 1} ({channel_name}) — {spec.label} · {physical_name}"
        global_labels = {
            "PLAY / PAUSE": "Play / Pause",
            "REC": "Gravação / ação",
            "REW": "Faixa anterior",
            "FF": "Próxima faixa",
            "BANK LEFT": "Banco anterior",
            "BANK RIGHT": "Próximo banco",
            "UP": "Navegação para cima",
            "DOWN": "Navegação para baixo",
            "LEFT": "Navegação para esquerda",
            "RIGHT": "Navegação para direita",
            "SHIFT": "Alternar modo dos knobs",
        }
        group_labels = {
            "Transporte": "Transporte",
            "Banco e navegação": "Navegação",
        }
        group = group_labels.get(spec.group, spec.group)
        label = global_labels.get(spec.key or "", spec.help_text or spec.label)
        return f"{group} — {label}"

    def _fill_button_target_combo(self, combo: QComboBox, preferred: str | None = None) -> None:
        old = str(combo.currentData() or "") if combo.count() else ""
        selected = preferred or old or "transport_play_pause"
        combo.blockSignals(True)
        combo.clear()
        previous_group = None
        for spec in BUTTON_SPECS:
            if previous_group is not None and spec.group != previous_group:
                combo.insertSeparator(combo.count())
            combo.addItem(self._button_choice_label(spec), spec.control_id)
            previous_group = spec.group
        found = combo.findData(selected)
        combo.setCurrentIndex(found if found >= 0 else 0)
        combo.blockSignals(False)

    def _refresh_button_target_combos(self) -> None:
        for attr in ("simple_button_target_combo", "windows_button_target_combo"):
            combo = getattr(self, attr, None)
            if combo is not None:
                self._fill_button_target_combo(combo, str(combo.currentData() or "transport_play_pause"))
        self._load_simple_button_editor()

    def _simple_preset_for_row(self, control_id: str, row: dict[str, Any]) -> str:
        spec = BUTTON_SPEC_BY_ID[control_id]
        action = str(row.get("action", spec.default_action))
        argument = str(row.get("argument", spec.default_argument))
        if action == spec.default_action and argument == spec.default_argument:
            return "__default__"
        # Exact presets first, so Play/Pause is not confused with the editable media action.
        for _label, key in SIMPLE_BUTTON_ACTION_OPTIONS:
            config = SIMPLE_BUTTON_ACTION_CONFIG.get(key)
            if config is None:
                continue
            preset_action, preset_argument = config
            if action == preset_action and preset_argument is not None and argument == preset_argument:
                return key
        # Actions with a user-supplied value get a dedicated one-line editor.
        custom_key_by_action = {"launch": "custom_launch", "shortcut": "custom_shortcut", "text": "custom_text", "mute_app": "custom_mute_app"}
        if action in custom_key_by_action:
            return custom_key_by_action[action]
        if action == "none":
            return "none"
        return "__keep__"

    def _load_simple_button_editor(self, *_args) -> None:
        if not hasattr(self, "simple_button_target_combo") or not hasattr(self, "simple_button_action_combo"):
            return
        control_id = str(self.simple_button_target_combo.currentData() or "transport_play_pause")
        if control_id not in BUTTON_SPEC_BY_ID:
            return
        row = self.profile.get("button_actions", {}).get(control_id, {})
        spec = BUTTON_SPEC_BY_ID[control_id]
        row_action = str(row.get("action", spec.default_action))
        row_argument = str(row.get("argument", spec.default_argument))
        key = self._simple_preset_for_row(control_id, row or {"action": row_action, "argument": row_argument})
        self._simple_button_editor_loading = True
        try:
            index = self.simple_button_action_combo.findData(key)
            self.simple_button_action_combo.setCurrentIndex(index if index >= 0 else self.simple_button_action_combo.findData("__keep__"))
            self.simple_button_argument_edit.setText(row_argument)
            if hasattr(self, "simple_button_trigger_combo"):
                trigger_index = self.simple_button_trigger_combo.findData(str(row.get("trigger_mode", "note")))
                self.simple_button_trigger_combo.setCurrentIndex(trigger_index if trigger_index >= 0 else 0)
        finally:
            self._simple_button_editor_loading = False
        self._update_simple_button_argument_ui()
        self._refresh_windows_mapping_target()
        self._refresh_simple_button_mapping_status()

    def _capture_simple_button_shortcut(self) -> None:
        dialog = ShortcutCaptureDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted or not dialog.shortcut:
            return
        index = self.simple_button_action_combo.findData("custom_shortcut")
        if index >= 0:
            self.simple_button_action_combo.setCurrentIndex(index)
        self.simple_button_argument_edit.setText(dialog.shortcut)
        self.statusBar().showMessage(f"Atalho capturado: {dialog.shortcut.upper()} · clique em ‘Salvar ação’ para aplicar.", 4000)

    def _set_simple_signal_panel_visible(self, visible: bool) -> None:
        self.simple_button_signal_panel.setVisible(bool(visible))
        self.simple_button_signal_toggle.setArrowType(Qt.ArrowType.DownArrow if visible else Qt.ArrowType.RightArrow)
        self.simple_button_signal_toggle.setText(
            "Ocultar tipo de sinal" if visible else "Se o botão não responder: ajustar tipo de sinal (opcional)"
        )

    def _update_simple_button_argument_ui(self, *_args) -> None:
        if not hasattr(self, "simple_button_action_combo"):
            return
        key = str(self.simple_button_action_combo.currentData() or "__default__")
        visible = key in SIMPLE_BUTTON_ARGUMENT_HINTS
        self.simple_button_argument_label.setVisible(visible)
        self.simple_button_argument_row.setVisible(visible)
        self.simple_button_argument_edit.setVisible(visible)
        if hasattr(self, "simple_button_capture_shortcut_btn"):
            self.simple_button_capture_shortcut_btn.setVisible(visible and key == "custom_shortcut")
        if visible:
            labels = {
                "custom_launch": "Programa / site",
                "custom_shortcut": "Atalho de teclado",
                "custom_text": "Texto",
                "custom_mute_app": "Aplicativo",
            }
            self.simple_button_argument_label.setText(labels.get(key, "Detalhe necessário"))
            self.simple_button_argument_edit.setPlaceholderText(SIMPLE_BUTTON_ARGUMENT_HINTS[key])

    def _refresh_simple_button_mapping_status(self) -> None:
        if not hasattr(self, "simple_button_status_label") or not hasattr(self, "simple_button_target_combo"):
            return
        control_id = str(self.simple_button_target_combo.currentData() or "")
        if not control_id or control_id not in BUTTON_SPEC_BY_ID:
            return
        row = self.profile.get("button_actions", {}).get(control_id, {})
        if getattr(self, "learning_target", None) == ("button", control_id):
            text = "Aguardando entrada: pressione uma vez o botão físico no M-VAVE."
        elif row.get("midi"):
            trigger_mode = str(row.get("trigger_mode", "note"))
            mode_labels = {"auto": "Automático", "cc_single_toggle": "CC Single/Toggle", "cc_push": "CC Push", "note": "Note"}
            text = f"Entrada física: {midi_key_label(row.get('midi'))} · acionamento: {mode_labels.get(trigger_mode, 'Automático')} · ação salva no perfil atual."
        else:
            text = "Entrada física: ainda não associada. Use ‘Salvar + aprender botão físico’ e pressione o botão no M-VAVE."
        self.simple_button_status_label.setText(text)
        if hasattr(self, "simple_button_unmap_btn"):
            self.simple_button_unmap_btn.setEnabled(bool(row.get("midi")))

    def _save_simple_button_action(self, start_learn: bool = False) -> bool:
        control_id = str(self.simple_button_target_combo.currentData() or "")
        key = str(self.simple_button_action_combo.currentData() or "__default__")
        if control_id not in BUTTON_SPEC_BY_ID:
            return False
        spec = BUTTON_SPEC_BY_ID[control_id]
        trigger_mode = str(self.simple_button_trigger_combo.currentData() or "note") if hasattr(self, "simple_button_trigger_combo") else "note"
        if key == "__keep__":
            row = self.profile.setdefault("button_actions", {}).setdefault(control_id, {"midi": None, "action": spec.default_action, "argument": spec.default_argument})
            row["trigger_mode"] = trigger_mode
            self._save_profile()
            self._refresh_midi_mapping_labels()
            self.statusBar().showMessage("A ação avançada foi preservada; tipo de sinal salvo.", 3500)
            if start_learn:
                self._start_button_learn(control_id)
            return True

        if key == "__default__":
            action, argument = spec.default_action, spec.default_argument
        else:
            config = SIMPLE_BUTTON_ACTION_CONFIG.get(key)
            if config is None:
                return False
            action, fixed_argument = config
            argument = str(self.simple_button_argument_edit.text()).strip() if fixed_argument is None else fixed_argument
            if fixed_argument is None and not argument:
                QMessageBox.warning(self, "Detalhe necessário", "Preencha o campo de detalhe antes de salvar esta ação.")
                self.simple_button_argument_edit.setFocus()
                return False

        if action in {"channel_mute", "channel_solo", "channel_select"} and spec.channel is None:
            QMessageBox.warning(
                self, "Ação incompatível",
                "Mute, Solo e Selecionar canal precisam ser associados a um controle de canal. "
                "Escolha um dos botões M, S ou □ de um canal."
            )
            return False

        row = self.profile.setdefault("button_actions", {}).setdefault(control_id, {"midi": None, "action": "none", "argument": ""})
        row["action"] = str(action)
        row["argument"] = str(argument)
        row["trigger_mode"] = trigger_mode
        self._save_profile()
        self._populate_button_table()
        self._refresh_midi_mapping_labels()
        self._refresh_simple_button_mapping_status()
        self.statusBar().showMessage(f"Ação salva: {self._control_display_name(control_id)}", 3500)
        if start_learn:
            self._start_button_learn(control_id)
        return True

    def _test_simple_button_action(self) -> None:
        control_id = str(self.simple_button_target_combo.currentData() or "")
        if control_id not in BUTTON_SPEC_BY_ID:
            return
        # Keep test behavior honest: unsaved choices are first applied.
        if not self._save_simple_button_action(start_learn=False):
            return
        self._on_virtual_button_pressed(control_id)

    def _unmap_simple_button_midi(self) -> None:
        control_id = str(self.simple_button_target_combo.currentData() or "")
        if control_id not in BUTTON_SPEC_BY_ID:
            return
        row = self.profile.setdefault("button_actions", {}).setdefault(control_id, {"midi": None, "action": "none", "argument": ""})
        row["midi"] = None
        self._save_profile()
        self._populate_button_table()
        self._refresh_midi_mapping_labels()
        self._refresh_simple_button_mapping_status()
        self.statusBar().showMessage(f"Associação MIDI removida de {self._control_display_name(control_id)}", 3000)

    def _set_button_advanced_visible(self, visible: bool) -> None:
        self.button_advanced_panel.setVisible(bool(visible))
        self.button_advanced_toggle.setArrowType(Qt.ArrowType.DownArrow if visible else Qt.ArrowType.RightArrow)
        self.button_advanced_toggle.setText("Ocultar configurações avançadas" if visible else "Mostrar tabela avançada (opcional)")

    def _open_simple_button_mapping_from_windows(self) -> None:
        control_id = str(self.windows_button_target_combo.currentData() or "transport_play_pause")
        self._select_simple_button_target(control_id, navigate=True)

    def _select_simple_button_target(self, control_id: str, navigate: bool = True) -> None:
        combo = getattr(self, "simple_button_target_combo", None)
        if combo is not None:
            index = combo.findData(control_id)
            if index >= 0:
                combo.setCurrentIndex(index)
            self._load_simple_button_editor()
        if navigate and hasattr(self, "tabs") and hasattr(self, "_buttons_page"):
            page_index = self.tabs.indexOf(self._buttons_page)
            if page_index >= 0:
                self.tabs.setCurrentIndex(page_index)

    def _navigate_to_buttons_tab(self) -> None:
        """Navigate to the real button-mapping page, independent of tab order."""
        tabs = getattr(self, "tabs", None)
        page = getattr(self, "_buttons_page", None)
        if tabs is not None and page is not None:
            index = tabs.indexOf(page)
            if index >= 0:
                tabs.setCurrentIndex(index)

    def _refresh_windows_mapping_target(self) -> None:
        if not hasattr(self, "windows_button_target_combo") or not hasattr(self, "simple_button_target_combo"):
            return
        target = self.simple_button_target_combo.currentData()
        if target is not None:
            index = self.windows_button_target_combo.findData(target)
            if index >= 0:
                self.windows_button_target_combo.blockSignals(True)
                self.windows_button_target_combo.setCurrentIndex(index)
                self.windows_button_target_combo.blockSignals(False)

    def _build_eq_tab(self) -> QWidget:
        tab = QWidget()
        outer_layout = QVBoxLayout(tab)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.setSpacing(0)

        # The whole page may scroll vertically on short displays, but never
        # horizontally. Band cards themselves always resize to the viewport.
        page_scroll = QScrollArea(tab)
        page_scroll.setObjectName("eqPageScroll")
        page_scroll.setWidgetResizable(True)
        page_scroll.setFrameShape(QFrame.Shape.NoFrame)
        page_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        page_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        page = QWidget()
        page.setObjectName("eqPage")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(8, 7, 8, 7)
        layout.setSpacing(5)

        header = QHBoxLayout()
        self.eq_title = QLabel("Equalizador · 8 bandas")
        self.eq_title.setMinimumWidth(0)
        self.eq_title.setObjectName("section")
        header.addWidget(self.eq_title, 1)
        self.eq_band_mode_combo = QComboBox()
        self.eq_band_mode_combo.addItem("3 bandas · Graves / Médios / Agudos", 3)
        self.eq_band_mode_combo.addItem("5 bandas · Intermediário", 5)
        self.eq_band_mode_combo.addItem("8 bandas · Avançado", 8)
        self.eq_band_mode_combo.setMinimumWidth(132)
        self.eq_band_mode_combo.setMaximumWidth(188)
        self.eq_band_mode_combo.setToolTip("Escolha a quantidade de bandas do equalizador")
        self.eq_band_mode_combo.currentIndexChanged.connect(self._on_eq_mode_changed)
        header.addWidget(self.eq_band_mode_combo)
        self.eq_bypass_btn = QPushButton("BYPASS OFF")
        self.eq_bypass_btn.setCheckable(True)
        self.eq_bypass_btn.toggled.connect(self._on_eq_bypass)
        self.eq_bypass_btn.setToolTip("Liga/desliga o bypass do equalizador global")
        self.eq_bypass_btn.setMaximumWidth(108)
        header.addWidget(self.eq_bypass_btn)
        self.eq_flat_btn = QPushButton("FLAT · 0 dB")
        self.eq_flat_btn.setObjectName("primary")
        self.eq_flat_btn.setMaximumWidth(102)
        self.eq_flat_btn.setToolTip("RESTAURAR EQ: zera todas as bandas nos modos 3/5/8, desliga Low/High Cut e remove o bypass. Não apaga presets pessoais. Grava os filtros imediatamente.")
        self.eq_flat_btn.clicked.connect(self._restore_eq_flat)
        header.addWidget(self.eq_flat_btn)
        layout.addLayout(header)

        description = QLabel(
            "Ajuste cada banda pelo knob circular ou pelo campo de ganho em dB. Duplo clique no knob restaura 0,0 dB. "
            "O equalizador global é aplicado pelo Equalizer APO quando instalado e vinculado ao dispositivo de saída."
        )
        description.setWordWrap(True)
        description.setObjectName("muted")
        layout.addWidget(description)

        preset_panel = QFrame()
        preset_panel.setObjectName("panel")
        preset_layout = QVBoxLayout(preset_panel)
        preset_layout.setContentsMargins(8, 5, 8, 5)
        preset_layout.setSpacing(4)
        preset_row = QHBoxLayout()
        preset_row.setContentsMargins(0, 0, 0, 0)
        preset_row.setSpacing(5)
        preset_row.addWidget(QLabel("PRESET"))
        self.eq_preset_combo = QComboBox()
        self.eq_preset_combo.setMinimumWidth(130)
        self.eq_preset_combo.setMaximumWidth(330)
        self.eq_preset_combo.setMinimumContentsLength(15)
        self.eq_preset_combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.eq_preset_combo.currentIndexChanged.connect(self._on_eq_preset_selection_changed)
        preset_row.addWidget(self.eq_preset_combo, 1)
        self.eq_apply_preset_btn = QPushButton("Aplicar")
        self.eq_apply_preset_btn.setObjectName("primary")
        self.eq_apply_preset_btn.clicked.connect(self._apply_selected_eq_preset)
        preset_row.addWidget(self.eq_apply_preset_btn)
        self.eq_save_preset_btn = QPushButton("Salvar novo")
        self.eq_save_preset_btn.clicked.connect(self._save_eq_preset_as)
        preset_row.addWidget(self.eq_save_preset_btn)
        self.eq_update_preset_btn = QPushButton("Atualizar")
        self.eq_update_preset_btn.clicked.connect(self._update_selected_eq_preset)
        preset_row.addWidget(self.eq_update_preset_btn)
        self.eq_delete_preset_btn = QPushButton("Excluir")
        self.eq_delete_preset_btn.setObjectName("danger")
        self.eq_delete_preset_btn.clicked.connect(self._delete_selected_eq_preset)
        preset_row.addWidget(self.eq_delete_preset_btn)
        preset_layout.addLayout(preset_row)

        ab_row = QHBoxLayout()
        ab_row.setContentsMargins(0, 0, 0, 0)
        ab_row.setSpacing(5)
        ab_row.addWidget(QLabel("COMPARAÇÃO"))
        self.eq_ab_save_a_btn = QPushButton("Salvar A")
        self.eq_ab_save_a_btn.setToolTip("Captura a configuração atual na memória A para comparação.")
        self.eq_ab_save_a_btn.clicked.connect(lambda: self._capture_eq_ab_slot("A"))
        ab_row.addWidget(self.eq_ab_save_a_btn)
        self.eq_ab_save_b_btn = QPushButton("Salvar B")
        self.eq_ab_save_b_btn.setToolTip("Captura a configuração atual na memória B para comparação.")
        self.eq_ab_save_b_btn.clicked.connect(lambda: self._capture_eq_ab_slot("B"))
        ab_row.addWidget(self.eq_ab_save_b_btn)
        self.eq_ab_toggle_btn = QPushButton("Comparar A/B")
        self.eq_ab_toggle_btn.setObjectName("primary")
        self.eq_ab_toggle_btn.setToolTip("Alterna entre as duas curvas salvas, incluindo frequências, modo e bypass.")
        self.eq_ab_toggle_btn.clicked.connect(self._toggle_eq_ab)
        ab_row.addWidget(self.eq_ab_toggle_btn)
        ab_row.addStretch(1)
        ab_hint = QLabel("A/B preserva os ajustes e o bypass")
        ab_hint.setObjectName("muted")
        ab_row.addWidget(ab_hint)
        preset_layout.addLayout(ab_row)
        self.eq_save_preset_btn.setToolTip("Salva a curva atual como preset novo. Para duplicar um preset, aplique-o primeiro e salve com outro nome.")
        layout.addWidget(preset_panel)

        frequency_row = QHBoxLayout()
        self.eq_fixed_freq_checkbox = QCheckBox("Manter frequências recomendadas (fixas)")
        self.eq_fixed_freq_checkbox.setChecked(True)
        self.eq_fixed_freq_checkbox.toggled.connect(self._on_eq_fixed_frequency_toggled)
        frequency_row.addWidget(self.eq_fixed_freq_checkbox)
        frequency_hint = QLabel("Desmarque para editar os centros.")
        frequency_hint.setObjectName("muted")
        frequency_row.addWidget(frequency_hint)
        frequency_row.addStretch(1)
        self.eq_suggest_freq_btn = QPushButton("Frequências padrão")
        self.eq_suggest_freq_btn.setToolTip("Restaura somente os centros de frequência recomendados. Para zerar os ganhos, use FLAT · 0 dB.")
        self.eq_suggest_freq_btn.clicked.connect(self._restore_suggested_frequencies)
        frequency_row.addWidget(self.eq_suggest_freq_btn)
        layout.addLayout(frequency_row)

        cut_panel = QFrame()
        cut_panel.setObjectName("panel")
        cut_row = QHBoxLayout(cut_panel)
        cut_row.setContentsMargins(8, 4, 8, 4)
        cut_row.setSpacing(8)
        self.eq_low_cut_enabled = QCheckBox("Low Cut · passa-altas")
        self.eq_low_cut_enabled.setToolTip("Remove conteúdo abaixo da frequência escolhida.")
        self.eq_low_cut_spin = QSpinBox()
        self.eq_low_cut_spin.setRange(20, 200)
        self.eq_low_cut_spin.setSingleStep(5)
        self.eq_low_cut_spin.setSuffix(" Hz")
        self.eq_low_cut_spin.setMaximumWidth(105)
        self.eq_high_cut_enabled = QCheckBox("High Cut · passa-baixas")
        self.eq_high_cut_enabled.setToolTip("Atenua conteúdo acima da frequência escolhida.")
        self.eq_high_cut_spin = QSpinBox()
        self.eq_high_cut_spin.setRange(5000, 20000)
        self.eq_high_cut_spin.setSingleStep(250)
        self.eq_high_cut_spin.setSuffix(" Hz")
        self.eq_high_cut_spin.setMaximumWidth(115)
        cut_row.addWidget(self.eq_low_cut_enabled)
        cut_row.addWidget(self.eq_low_cut_spin)
        cut_row.addSpacing(12)
        cut_row.addWidget(self.eq_high_cut_enabled)
        cut_row.addWidget(self.eq_high_cut_spin)
        cut_row.addStretch(1)
        cut_note = QLabel("Cortes aplicados via Equalizer APO")
        cut_note.setObjectName("muted")
        cut_row.addWidget(cut_note)
        self.eq_low_cut_enabled.toggled.connect(self._on_eq_cutoff_changed)
        self.eq_low_cut_spin.valueChanged.connect(self._on_eq_cutoff_changed)
        self.eq_high_cut_enabled.toggled.connect(self._on_eq_cutoff_changed)
        self.eq_high_cut_spin.valueChanged.connect(self._on_eq_cutoff_changed)
        layout.addWidget(cut_panel)

        # Gain controls are rotary-only: never create a slider for an EQ band.
        # The responsive grid keeps one row when it fits; on narrower screens it
        # reflows to 4/3/2 columns instead of clipping cards or adding horizontal scroll.
        self.eq_bands_widget = QWidget()
        self.eq_bands_widget.setObjectName("eqBandsSurface")
        self.eq_bands_widget.setMinimumWidth(0)
        self.eq_bands_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.eq_bands_layout = QGridLayout(self.eq_bands_widget)
        self.eq_bands_layout.setContentsMargins(2, 3, 2, 3)
        self.eq_bands_layout.setHorizontalSpacing(5)
        self.eq_bands_layout.setVerticalSpacing(6)
        layout.addWidget(self.eq_bands_widget, 1)
        self.eq_controls: list[dict[str, Any]] = []
        self.band_freqs = [frequency_label(v) for v in DEFAULT_FREQUENCIES["8"]]

        options = QHBoxLayout()
        options.addWidget(QLabel("Codificação do encoder:"))
        self.knob_mode_combo = QComboBox()
        for mode_key, mode_label in KNOB_MODES.items():
            self.knob_mode_combo.addItem(mode_label, mode_key)
        self.knob_mode_combo.currentIndexChanged.connect(self._on_knob_mode_changed)
        options.addWidget(self.knob_mode_combo)
        options.addSpacing(8)
        options.addWidget(QLabel("Passo relativo:"))
        self.knob_step_spin = QSpinBox()
        self.knob_step_spin.setRange(1, 30)
        self.knob_step_spin.setValue(5)
        self.knob_step_spin.setSuffix(" × 0,1 dB")
        self.knob_step_spin.setToolTip("Sensibilidade do encoder relativo: 5 = 0,5 dB por passo. Aumente para respostas mais rápidas.")
        self.knob_step_spin.valueChanged.connect(self._on_knob_step_changed)
        options.addWidget(self.knob_step_spin)
        self.knob_invert_check = QCheckBox("Inverter giro")
        self.knob_invert_check.setToolTip("Inverte o sentido dos encoders se girar para a direita e o ganho diminuir (ou vice-versa).")
        self.knob_invert_check.toggled.connect(self._on_knob_invert_changed)
        options.addWidget(self.knob_invert_check)
        options.addSpacing(8)
        options.addWidget(QLabel("Histerese do fader:"))
        self.hysteresis_spin = QSpinBox()
        self.hysteresis_spin.setRange(0, 4)
        self.hysteresis_spin.setValue(1)
        self.hysteresis_spin.setSuffix(" passos MIDI")
        self.hysteresis_spin.valueChanged.connect(self._on_hysteresis_changed)
        options.addWidget(self.hysteresis_spin)
        options.addStretch(1)
        layout.addLayout(options)
        self.knob_mode_help = QLabel("Encoder relativo: cada clique altera o ganho em pequenos passos. Se o giro ficar invertido ou saltar, teste o formato sinal/magnitude.")
        self.knob_mode_help.setObjectName("muted")
        self.knob_mode_help.setWordWrap(True)
        layout.addWidget(self.knob_mode_help)
        self.knob_input_status = QLabel("Entrada MIDI: gire um encoder físico após mapeá-lo para identificar seu formato.")
        self.knob_input_status.setObjectName("muted")
        self.knob_input_status.setWordWrap(True)
        layout.addWidget(self.knob_input_status)

        eq_status_row = QHBoxLayout()
        self.eq_file_status = QLabel("EQ: ainda não gerado nem vinculado ao Equalizer APO.")
        self.eq_file_status.setObjectName("muted")
        self.eq_file_status.setWordWrap(True)
        eq_status_row.addWidget(self.eq_file_status, 1)
        self.eqapo_quick_link_btn = QPushButton("Vincular ao APO")
        self.eqapo_quick_link_btn.setObjectName("primary")
        self.eqapo_quick_link_btn.setToolTip("Gera os filtros e adiciona com backup a linha Include no config.txt do Equalizer APO.")
        self.eqapo_quick_link_btn.clicked.connect(self._configure_equalizer_apo)
        eq_status_row.addWidget(self.eqapo_quick_link_btn)
        layout.addLayout(eq_status_row)
        self._rebuild_eq_band_controls()
        self._refresh_eq_preset_combo()
        page_scroll.setWidget(page)
        outer_layout.addWidget(page_scroll, 1)
        return tab

    def _build_led_tab(self) -> QWidget:
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(8, 7, 8, 7)
        layout.setSpacing(6)
        title = QLabel("Feedback físico · LEDs do SMC-Mixer")
        title.setObjectName("section")
        layout.addWidget(title)
        explainer = QLabel(
            "O motor envia feedback MIDI pela porta de saída do controlador. O mapeamento padrão segue o arquivo público de dispositivo "
            "smc_mixer.yaml do projeto smc_mixer_control (CC dos faders/knobs e notas das linhas de botões). "
            "Deixamos a saída desativada inicialmente para você testar com segurança; habilite após conferir a porta MIDI de saída."
        )
        explainer.setWordWrap(True)
        explainer.setObjectName("muted")
        layout.addWidget(explainer)

        box = QFrame()
        box.setObjectName("panel")
        form = QFormLayout(box)
        form.setContentsMargins(14, 12, 14, 12)
        self.led_enabled_checkbox = QCheckBox("Ativar animações e feedback na unidade física")
        self.led_enabled_checkbox.toggled.connect(self._on_led_settings_changed)
        form.addRow(self.led_enabled_checkbox)

        self.led_mode_combo = QComboBox()
        for key, label in LED_MODES.items():
            self.led_mode_combo.addItem(label, key)
        self.led_mode_combo.currentIndexChanged.connect(self._on_led_settings_changed)
        form.addRow("Efeito visual:", self.led_mode_combo)

        out_row = QHBoxLayout()
        self.led_output_combo = QComboBox()
        self.led_output_combo.addItem("Automático (SMC-Mixer)", "AUTO")
        self.led_output_combo.setMinimumWidth(260)
        self.led_output_combo.currentIndexChanged.connect(self._on_led_settings_changed)
        out_row.addWidget(self.led_output_combo, 1)
        self.led_rescan_btn = QPushButton("Atualizar saídas MIDI")
        self.led_rescan_btn.clicked.connect(self._rescan_led_outputs)
        out_row.addWidget(self.led_rescan_btn)
        self.led_test_btn = QPushButton("Teste rápido de LEDs")
        self.led_test_btn.clicked.connect(self._test_led_output)
        out_row.addWidget(self.led_test_btn)
        form.addRow("Porta de saída:", out_row)

        self.led_speed_slider = QSlider(Qt.Orientation.Horizontal)
        self.led_speed_slider.setRange(25, 400)
        self.led_speed_slider.setValue(100)
        self.led_speed_slider.valueChanged.connect(self._on_led_settings_changed)
        self.led_speed_label = QLabel("1,00×")
        speed_row = QHBoxLayout()
        speed_row.addWidget(self.led_speed_slider, 1)
        speed_row.addWidget(self.led_speed_label)
        form.addRow("Velocidade:", speed_row)

        self.led_brightness_slider = QSlider(Qt.Orientation.Horizontal)
        self.led_brightness_slider.setRange(5, 100)
        self.led_brightness_slider.setValue(80)
        self.led_brightness_slider.valueChanged.connect(self._on_led_settings_changed)
        self.led_brightness_label = QLabel("80%")
        brightness_row = QHBoxLayout()
        brightness_row.addWidget(self.led_brightness_slider, 1)
        brightness_row.addWidget(self.led_brightness_label)
        form.addRow("Intensidade:", brightness_row)
        layout.addWidget(box)

        preview_box = QFrame()
        preview_box.setObjectName("panel")
        preview_layout = QVBoxLayout(preview_box)
        preview_layout.setContentsMargins(14, 10, 14, 10)
        preview_layout.addWidget(QLabel("PRÉVIA DE NÍVEL DOS OITO CANAIS"))
        bars_row = QHBoxLayout()
        self.led_preview_bars: list[QProgressBar] = []
        for i in range(8):
            column = QVBoxLayout()
            column.addWidget(QLabel(f"CH {i + 1}"), alignment=Qt.AlignmentFlag.AlignHCenter)
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setValue(0)
            bar.setFormat("%p%")
            column.addWidget(bar)
            bars_row.addLayout(column, 1)
            self.led_preview_bars.append(bar)
        preview_layout.addLayout(bars_row)
        layout.addWidget(preview_box)

        self.led_status_label = QLabel("LED feedback desativado. Ative a saída após selecionar a porta correta.")
        self.led_status_label.setObjectName("muted")
        self.led_status_label.setWordWrap(True)
        layout.addWidget(self.led_status_label)
        hardware_note = QLabel(
            "Observação: o modo 'Nível de volume' representa o volume configurado por canal, não o pico acústico real de cada processo. "
            "Uma leitura de pico por aplicativo exige captura/loopback de áudio independente. Os efeitos são calculados em thread separada."
        )
        hardware_note.setObjectName("muted")
        hardware_note.setWordWrap(True)
        layout.addWidget(hardware_note)
        layout.addStretch(1)
        self._rescan_led_outputs()
        return tab

    def _rebuild_eq_band_controls(self) -> None:
        if not hasattr(self, "eq_bands_layout"):
            return
        while self.eq_bands_layout.count():
            item = self.eq_bands_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        mode = str(self.profile.get("eq_mode", 8)) if hasattr(self, "store") else "8"
        mode = normalize_mode(mode)
        freqs_by_mode = self.profile.get("eq_custom_frequencies", {}) if hasattr(self, "store") else {}
        freqs = sanitize_frequencies(freqs_by_mode.get(mode, DEFAULT_FREQUENCIES[mode]), mode)
        if hasattr(self, "band_freqs"):
            self.band_freqs = [frequency_label(v) for v in freqs]
        self.eq_controls = []
        self._eq_grid_columns = None
        count = int(mode)
        viewport_width = max(0, self.eq_bands_widget.width() if hasattr(self, "eq_bands_widget") else self.width() - 80)
        column_budget = max(88, int((viewport_width - max(0, count - 1) * 5 - 12) / count))
        knob_diameter = max(44, min(76, column_budget - 20))
        field_width = max(72, min(100, column_budget - 10))
        button_width = max(56, min(92, column_budget - 6))
        for index in range(count):
            col_widget = QFrame()
            col_widget.setObjectName("panel")
            col_widget.setMinimumWidth(0)
            col_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
            col = QVBoxLayout(col_widget)
            col.setContentsMargins(4, 5, 4, 5)
            col.setSpacing(4)

            band = QLabel(BAND_LABELS[mode][index])
            band.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            band.setObjectName("eyebrow")
            band.setMinimumWidth(0)
            band.setMinimumHeight(18)
            band.setToolTip(f"Banda {index + 1}: {BAND_LABELS[mode][index]}")

            freq_spin = QDoubleSpinBox()
            freq_spin.setRange(20.0, 20000.0)
            freq_spin.setDecimals(0)
            freq_spin.setSingleStep(10.0 if freqs[index] < 1000 else 100.0)
            freq_spin.setSuffix(" Hz")
            freq_spin.setMaximumWidth(field_width)
            freq_spin.setMinimumWidth(0)
            freq_spin.setAlignment(Qt.AlignmentFlag.AlignCenter)
            freq_spin.setStyleSheet("font-size:11px; padding:2px 1px;")
            freq_spin.setValue(freqs[index])
            freq_spin.setEnabled(not bool(self.profile.get("eq_fixed_frequencies", True)) if hasattr(self, "store") else False)

            knob = RotaryKnob(-120, 120, round(float(self.profile["eq_gains"][index]) * 10) if hasattr(self, "store") else 0)
            knob.setObjectName("eqGainKnob")
            knob.setCursor(Qt.CursorShape.PointingHandCursor)
            knob.set_diameter(knob_diameter)
            knob.setToolTip("Knob circular do EQ · −12 a +12 dB. Arraste para cima/baixo para ajuste fino; duplo clique restaura 0,0 dB.")
            knob.set_theme_colors(
                getattr(self, "_active_palette", {}).get("accent", "#53b3ff"),
                getattr(self, "_active_palette", {}).get("track", "#3b424d"),
            )

            gain_spin = QDoubleSpinBox()
            gain_spin.setRange(-12.0, 12.0)
            gain_spin.setDecimals(1)
            gain_spin.setSingleStep(0.1)
            gain_spin.setSuffix(" dB")
            gain_spin.setAlignment(Qt.AlignmentFlag.AlignCenter)
            gain_spin.setMaximumWidth(field_width)
            gain_spin.setMinimumWidth(0)
            gain_spin.setStyleSheet("font-size:11px; padding:2px 1px; font-weight:700;")
            gain_spin.setValue(float(self.profile["eq_gains"][index]) if hasattr(self, "store") else 0.0)
            knob.setValue(round(float(self.profile["eq_gains"][index]) * 10) if hasattr(self, "store") else 0)

            map_btn = QPushButton("MAPEAR")
            map_btn.setObjectName("mapButton")
            map_btn.setMinimumWidth(0)
            map_btn.setMaximumWidth(button_width)
            map_btn.setToolTip(f"Mapear o encoder físico para a banda {index + 1} ({BAND_LABELS[mode][index]}).")
            map_btn.clicked.connect(lambda _checked=False, n=index: self._start_learn("knob", n))
            mapping = QLabel(midi_key_label(self.profile["knob_midi"][index]) if hasattr(self, "store") else "Não mapeado")
            mapping.setObjectName("muted")
            mapping.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            mapping.setWordWrap(True)
            mapping.setMaximumHeight(32)
            mapping.setMinimumWidth(0)

            knob.valueChanged.connect(lambda value, n=index: self._on_eq_knob_value(n, value))
            knob.doubleClicked.connect(lambda n=index: self._reset_eq_band(n))
            gain_spin.valueChanged.connect(lambda value, n=index: self._on_eq_gain_spin(n, value))
            freq_spin.valueChanged.connect(lambda value, n=index: self._on_eq_frequency_changed(n, value))

            col.addWidget(band)
            col.addWidget(freq_spin, 0, Qt.AlignmentFlag.AlignHCenter)
            knob_row = QHBoxLayout()
            knob_row.setContentsMargins(0, 0, 0, 0)
            knob_row.setSpacing(0)
            knob_row.addStretch(1)
            knob_row.addWidget(knob, 0, Qt.AlignmentFlag.AlignCenter)
            knob_row.addStretch(1)
            col.addLayout(knob_row, 1)
            col.addWidget(gain_spin, 0, Qt.AlignmentFlag.AlignHCenter)
            col.addWidget(map_btn)
            col.addWidget(mapping)
            self.eq_controls.append({"knob": knob, "gain": gain_spin, "freq": freq_spin, "map": map_btn, "mapping": mapping, "band": band, "card": col_widget})

        if hasattr(self, "eq_title"):
            names = {"3": "3 bandas · Graves / Médios / Agudos", "5": "5 bandas · Intermediário", "8": "8 bandas · Avançado"}
            self.eq_title.setText(f"Equalizador · {names[mode]}")
        QTimer.singleShot(0, self._relayout_eq_bands_for_width)
        QTimer.singleShot(0, self._fit_eq_knobs_to_cards)

    def _relayout_eq_bands_for_width(self) -> None:
        """Pack EQ cards into the available width without horizontal scrolling."""
        if not hasattr(self, "eq_bands_layout") or not getattr(self, "eq_controls", None):
            return
        count = len(self.eq_controls)
        width = max(1, self.eq_bands_widget.contentsRect().width())
        columns = choose_eq_grid_columns(width, count, min_card_width=104, spacing=5)
        if getattr(self, "_eq_grid_columns", None) == columns:
            return
        self._eq_grid_columns = columns
        for index in range(8):
            self.eq_bands_layout.setColumnStretch(index, 0)
            self.eq_bands_layout.setRowStretch(index, 0)
        while self.eq_bands_layout.count():
            item = self.eq_bands_layout.takeAt(0)
            # Keep the card widget alive; only detach the layout item.
            del item
        for position, control in enumerate(self.eq_controls):
            card = control.get("card")
            if card is None:
                continue
            row, column = divmod(position, columns)
            card.setMinimumWidth(0)
            card.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
            self.eq_bands_layout.addWidget(card, row, column)
        for column in range(columns):
            self.eq_bands_layout.setColumnStretch(column, 1)
        rows = (count + columns - 1) // columns
        for row in range(rows):
            self.eq_bands_layout.setRowStretch(row, 1)
        self.eq_bands_widget.updateGeometry()

    def _fit_eq_knobs_to_cards(self) -> None:
        """Resize round EQ knobs to each card's actual width, without overflow."""
        self._relayout_eq_bands_for_width()
        for control in getattr(self, "eq_controls", []):
            knob = control.get("knob")
            card = control.get("card")
            if not isinstance(knob, RotaryKnob) or card is None:
                continue
            available = max(44, card.contentsRect().width() - 18)
            diameter = max(44, min(76, available))
            if knob.width() != diameter or knob.height() != diameter:
                knob.set_diameter(diameter)

    def _refresh_eq_preset_combo(self) -> None:
        if not hasattr(self, "eq_preset_combo"):
            return
        selected = str(self.profile.get("eq_selected_preset", "Flat / Neutro"))
        names = list(FACTORY_PRESETS) + list(self.profile.get("eq_user_presets", {}).keys())
        if selected == "__current__":
            names.append("__current__")
        self.eq_preset_combo.blockSignals(True)
        self.eq_preset_combo.clear()
        for name in names:
            if name == "__current__":
                display = "Personalizado (curva atual)"
            else:
                marker = "  ·  PERSONALIZADO" if name in self.profile.get("eq_user_presets", {}) else ""
                display = name + marker
            self.eq_preset_combo.addItem(display, name)
        pos = self.eq_preset_combo.findData(selected)
        self.eq_preset_combo.setCurrentIndex(pos if pos >= 0 else 0)
        self.eq_preset_combo.blockSignals(False)
        is_user = selected in self.profile.get("eq_user_presets", {})
        self.eq_update_preset_btn.setEnabled(is_user)
        self.eq_delete_preset_btn.setEnabled(is_user)

    def _build_windows_tab(self) -> QWidget:
        """Windows audio, display, quick actions and editable user macros."""
        page = QWidget()
        outer = QVBoxLayout(page)
        outer.setContentsMargins(8, 8, 8, 8)
        outer.setSpacing(6)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        body = QWidget()
        layout = QVBoxLayout(body)
        layout.setContentsMargins(2, 2, 8, 8)
        layout.setSpacing(10)

        intro = QLabel("Central de controle do Windows. Os faders do console continuam controlando os destinos atribuídos; aqui você encontra ações rápidas, volume master, brilho de monitores compatíveis e macros editáveis.")
        intro.setWordWrap(True)
        intro.setObjectName("muted")
        layout.addWidget(intro)

        # The Windows tab now points users to the same guided button mapper,
        # instead of asking them to understand raw MIDI values or action IDs.
        mapping_box = QGroupBox("BOTÕES FÍSICOS DO M-VAVE")
        mapping_layout = QHBoxLayout(mapping_box)
        mapping_layout.setContentsMargins(10, 8, 10, 8)
        mapping_layout.addWidget(QLabel("Botão que quero configurar:"))
        self.windows_button_target_combo = QComboBox()
        self.windows_button_target_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._fill_button_target_combo(self.windows_button_target_combo, "transport_play_pause")
        mapping_layout.addWidget(self.windows_button_target_combo, 1)
        self.windows_configure_button = QPushButton("Configurar este botão…")
        self.windows_configure_button.setObjectName("primary")
        self.windows_configure_button.clicked.connect(self._open_simple_button_mapping_from_windows)
        mapping_layout.addWidget(self.windows_configure_button)
        layout.addWidget(mapping_box)
        mapping_help = QLabel(
            "Para associar: escolha o botão acima, abra o assistente e use ‘Salvar e associar botão físico’. "
            "Depois pressione uma vez o botão correspondente no M-VAVE. Os botões de ações rápidas abaixo "
            "executam comandos no computador quando clicados na tela; eles não fazem o mapeamento físico."
        )
        mapping_help.setWordWrap(True)
        mapping_help.setObjectName("muted")
        layout.addWidget(mapping_help)

        audio_box = QGroupBox("ÁUDIO DO WINDOWS")
        audio_layout = QVBoxLayout(audio_box)
        master_row = QHBoxLayout()
        master_row.addWidget(QLabel("Volume master"))
        self.master_volume_slider = QSlider(Qt.Orientation.Horizontal)
        self.master_volume_slider.setRange(0, 100)
        self.master_volume_slider.setValue(50)
        self.master_volume_slider.setTracking(True)
        self.master_volume_slider.valueChanged.connect(self._on_master_panel_volume_changed)
        master_row.addWidget(self.master_volume_slider, 1)
        self.master_volume_label = QLabel("—")
        self.master_volume_label.setMinimumWidth(55)
        master_row.addWidget(self.master_volume_label)
        self.master_mute_btn = QPushButton("Alternar mute master")
        self.master_mute_btn.clicked.connect(self._toggle_master_from_panel)
        master_row.addWidget(self.master_mute_btn)
        self.microphone_mute_btn = QPushButton("Alternar mute do microfone")
        self.microphone_mute_btn.clicked.connect(self._toggle_microphone_from_panel)
        master_row.addWidget(self.microphone_mute_btn)
        audio_layout.addLayout(master_row)
        microphone_row = QHBoxLayout()
        microphone_row.addWidget(QLabel("Ganho de captura do microfone"))
        self.microphone_volume_slider = QSlider(Qt.Orientation.Horizontal)
        self.microphone_volume_slider.setRange(0, 100)
        self.microphone_volume_slider.setValue(50)
        self.microphone_volume_slider.valueChanged.connect(self._on_microphone_panel_volume_changed)
        microphone_row.addWidget(self.microphone_volume_slider, 1)
        self.microphone_volume_label = QLabel("—")
        self.microphone_volume_label.setMinimumWidth(55)
        microphone_row.addWidget(self.microphone_volume_label)
        audio_layout.addLayout(microphone_row)
        audio_help = QLabel("O volume master usa o endpoint padrão do Windows. Os faders do console também podem controlar sessões individuais, como navegador e players, quando o aplicativo tem uma sessão de áudio ativa.")
        audio_help.setWordWrap(True)
        audio_help.setObjectName("muted")
        audio_layout.addWidget(audio_help)
        layout.addWidget(audio_box)

        display_box = QGroupBox("MONITORES E BRILHO")
        display_panel_layout = QVBoxLayout(display_box)
        display_panel_layout.setContentsMargins(10, 10, 10, 10)
        display_layout = QHBoxLayout()
        self.display_target_combo = QComboBox()
        for label, target in self.audio.list_brightness_targets():
            self.display_target_combo.addItem(label, target)
        self.display_target_combo.currentIndexChanged.connect(self._on_display_target_changed)
        display_layout.addWidget(self.display_target_combo, 2)
        self.display_brightness_slider = QSlider(Qt.Orientation.Horizontal)
        self.display_brightness_slider.setRange(0, 100)
        self.display_brightness_slider.setValue(50)
        self.display_brightness_slider.valueChanged.connect(self._on_display_brightness_changed)
        display_layout.addWidget(self.display_brightness_slider, 2)
        self.display_brightness_label = QLabel("50%")
        self.display_brightness_label.setMinimumWidth(48)
        display_layout.addWidget(self.display_brightness_label)
        display_help = QLabel("A lista tenta detectar vários monitores. O suporte real depende do painel/driver e de DDC/CI; se o monitor não aceitar brilho por software, o app informará a falha em vez de afirmar que funcionou.")
        display_help.setWordWrap(True)
        display_help.setObjectName("muted")
        display_panel_layout.addLayout(display_layout)
        display_panel_layout.addWidget(display_help)
        layout.addWidget(display_box)

        quick_box = QGroupBox("AÇÕES DIRETAS DO WINDOWS · CLIQUE PARA EXECUTAR")
        quick_layout = QVBoxLayout(quick_box)
        quick_specs = [
            ("Área de trabalho", "show_desktop"), ("Explorador", "explorer"),
            ("Gerenciador de tarefas", "task_manager"), ("Configurações", "open_settings"),
            ("Som", "open_sound_settings"), ("Tela", "open_display_settings"),
            ("Rede", "open_network_settings"), ("Pesquisa", "open_search"),
            ("Área de transferência", "open_clipboard"), ("Notificações", "open_notifications"),
            ("Volume +", "volume_up"), ("Volume −", "volume_down"),
            ("Mute sistema", "volume_mute"), ("Minimizar janela", "minimize_active"),
            ("Bloquear sessão", "lock_workstation"), ("Maximizar janela", "maximize_active"),
            ("Encaixar à esquerda", "snap_left"), ("Encaixar à direita", "snap_right"),
            ("Restaurar janela", "restore_active"),
        ]
        quick_grid = QHBoxLayout()
        col = QVBoxLayout()
        for i, (label, command) in enumerate(quick_specs):
            btn = QPushButton(label)
            btn.setToolTip(f"Executa a ação Windows: {command}")
            btn.clicked.connect(lambda _checked=False, cmd=command: self._run_windows_action(cmd))
            col.addWidget(btn)
            if (i + 1) % 5 == 0:
                quick_grid.addLayout(col, 1)
                col = QVBoxLayout()
        if col.count():
            quick_grid.addLayout(col, 1)
        quick_layout.addLayout(quick_grid)
        launch_row = QHBoxLayout()
        self.quick_launch_edit = QLineEdit()
        self.quick_launch_edit.setPlaceholderText("Caminho de aplicativo/arquivo ou URL (ex.: spotify.exe ou https://…)")
        launch_row.addWidget(self.quick_launch_edit, 1)
        launch_btn = QPushButton("Abrir")
        launch_btn.setObjectName("primary")
        launch_btn.clicked.connect(self._launch_quick_target)
        launch_row.addWidget(launch_btn)
        quick_layout.addLayout(launch_row)
        layout.addWidget(quick_box)

        macro_box = QGroupBox("MACROS PERSONALIZADAS · 8 ATALHOS CONFIGURÁVEIS")
        macro_layout = QVBoxLayout(macro_box)
        macro_help = QLabel("Defina nome, ação e argumento. Para encadear ações, selecione ‘Sequência de ações (macro)’ e use ação|argumento separadas por ponto e vírgula, por exemplo launch|notepad.exe;wait|1.5;shortcut|ctrl+s. Uma macro pode ser vinculada a qualquer botão físico por ‘Executar macro (1–8)’. As ações são validadas; não há execução de código arbitrário.")
        macro_help.setWordWrap(True)
        macro_help.setObjectName("muted")
        macro_layout.addWidget(macro_help)
        self.macro_rows: list[dict[str, Any]] = []
        macro_action_keys = {"none", "shortcut", "key_sequence", "text", "launch", "media", "system", "mute_master", "mute_microphone", "mute_app", "macro_sequence"}
        macro_choices = [(label, key) for label, key in ACTION_CHOICES if key in macro_action_keys]
        for index in range(8):
            saved = self.profile.get("macros", [])[index] if index < len(self.profile.get("macros", [])) else {}
            row = QHBoxLayout()
            name_edit = QLineEdit(str(saved.get("name", f"Macro {index + 1}")))
            name_edit.setPlaceholderText(f"Nome da macro {index + 1}")
            name_edit.setMinimumWidth(105)
            action_combo = QComboBox()
            for label, key in macro_choices:
                action_combo.addItem(label, key)
            action_index = action_combo.findData(str(saved.get("action", "shortcut")))
            action_combo.setCurrentIndex(action_index if action_index >= 0 else 0)
            argument_edit = QLineEdit(str(saved.get("argument", "")))
            argument_edit.setPlaceholderText("Argumento da ação")
            argument_edit.setToolTip("Para sequência: launch|notepad.exe;wait|1.5;shortcut|ctrl+s")
            action_combo.currentIndexChanged.connect(lambda _index, combo=action_combo, field=argument_edit: self._update_macro_argument_hint(combo, field))
            run_btn = QPushButton("Executar")
            run_btn.setMinimumWidth(84)
            run_btn.clicked.connect(lambda _checked=False, macro_index=index: self._run_macro(macro_index))
            row.addWidget(QLabel(f"{index + 1}."))
            row.addWidget(name_edit, 1)
            row.addWidget(action_combo, 2)
            row.addWidget(argument_edit, 2)
            row.addWidget(run_btn)
            macro_layout.addLayout(row)
            for widget, signal in ((name_edit, name_edit.textChanged), (action_combo, action_combo.currentIndexChanged), (argument_edit, argument_edit.textChanged)):
                signal.connect(self._schedule_macro_save)
            self.macro_rows.append({"name": name_edit, "action": action_combo, "argument": argument_edit})
        self._macro_save_timer = QTimer(self)
        self._macro_save_timer.setSingleShot(True)
        self._macro_save_timer.setInterval(300)
        self._macro_save_timer.timeout.connect(self._persist_macros_from_ui)
        macro_toggle = QToolButton()
        macro_toggle.setText("Macros avançadas (opcional) — clique para abrir")
        macro_toggle.setCheckable(True)
        macro_toggle.setChecked(False)
        macro_toggle.setArrowType(Qt.ArrowType.RightArrow)
        macro_toggle.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        macro_toggle.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        macro_box.setVisible(False)
        def _toggle_macro_panel(visible: bool) -> None:
            macro_box.setVisible(bool(visible))
            macro_toggle.setArrowType(Qt.ArrowType.DownArrow if visible else Qt.ArrowType.RightArrow)
            macro_toggle.setText("Ocultar macros avançadas" if visible else "Macros avançadas (opcional) — clique para abrir")
        macro_toggle.toggled.connect(_toggle_macro_panel)
        layout.addWidget(macro_toggle)
        layout.addWidget(macro_box)

        layout.addStretch(1)
        scroll.setWidget(body)
        outer.addWidget(scroll)
        return page

    def _run_macro(self, index: int) -> tuple[bool, str]:
        macros = self.profile.get("macros", [])
        if not 0 <= int(index) < len(macros):
            return False, "Número de macro inválido; use 1 a 8."
        row = macros[int(index)]
        action = str(row.get("action", "none"))
        argument = str(row.get("argument", ""))
        name = str(row.get("name") or f"Macro {index + 1}")
        if action == "macro_sequence":
            return self._run_macro_sequence(argument, name)
        ok, message = execute_action(action, argument, self.audio)
        self.statusBar().showMessage(("✓ " if ok else "⚠ ") + f"{name}: {message}", 4500)
        return ok, message

    def _update_macro_argument_hint(self, combo: QComboBox, field: QLineEdit) -> None:
        action = str(combo.currentData() or "none")
        if action == "macro_sequence":
            field.setPlaceholderText("launch|notepad.exe;wait|1.5;shortcut|ctrl+s")
            field.setToolTip(ACTION_HINTS.get(action, ""))
        else:
            field.setPlaceholderText(ACTION_HINTS.get(action, "Argumento da ação") or "Argumento da ação")
            field.setToolTip(ACTION_HINTS.get(action, ""))

    def _run_macro_sequence(self, raw: str, name: str = "Macro") -> tuple[bool, str]:
        try:
            steps = parse_macro_sequence(raw)
        except ValueError as exc:
            self.statusBar().showMessage(str(exc), 5000)
            return False, str(exc)
        token = f"macro-sequence-{time.monotonic_ns()}"
        worker = _MacroSequenceWorker(token, name, steps, self.audio)
        worker.signals.finished.connect(self._on_macro_sequence_finished)
        self._active_macro_workers[token] = worker
        self._action_pool.start(worker)
        message = f"Macro ‘{name}’ iniciada em segundo plano ({len(steps)} etapas)."
        self.statusBar().showMessage(message, 3500)
        return True, message

    def _on_macro_sequence_finished(self, token: str, name: str, success: bool, message: str) -> None:
        self._active_macro_workers.pop(token, None)
        self.statusBar().showMessage(("✓ " if success else "⚠ ") + f"{name}: {message}", 5000)
        self.hud.show_event(name, "CONCLUÍDA" if success else "FALHA", 100 if success else 0, "MACRO")

    def _build_settings_tab(self) -> QWidget:
        """Settings are split into sub-tabs; long Windows/automation controls have their own scroll area."""
        pages = QTabWidget()
        pages.setDocumentMode(True)

        # Appearance and backup page
        appearance = QWidget()
        appearance_layout = QVBoxLayout(appearance)
        appearance_layout.setContentsMargins(9, 8, 9, 8)
        appearance_layout.setSpacing(7)
        appearance_box = QFrame(); appearance_box.setObjectName("panel")
        form = QFormLayout(appearance_box); form.setContentsMargins(13, 10, 13, 10)
        title = QLabel("Aparência e acessibilidade"); title.setObjectName("section"); form.addRow(title)
        theme_row = QHBoxLayout()
        self.theme_combo = QComboBox(); self.theme_combo.addItems(list(THEMES.keys()))
        self.theme_combo.setCurrentText(str(self.store.data.get("theme", DEFAULT_THEME)))
        self.theme_combo.currentTextChanged.connect(self._on_theme_changed); theme_row.addWidget(self.theme_combo, 1)
        self.accent_color_btn = QPushButton("Cor de destaque"); self.accent_color_btn.clicked.connect(self._choose_accent_color); theme_row.addWidget(self.accent_color_btn)
        form.addRow("Tema:", theme_row)
        self.compact_ui_checkbox = QCheckBox("Interface compacta")
        self.compact_ui_checkbox.setChecked(bool(self.store.data.get("compact_ui", False)))
        self.compact_ui_checkbox.toggled.connect(self._on_compact_ui_changed)
        form.addRow("Densidade:", self.compact_ui_checkbox)
        self.hud_enabled_checkbox = QCheckBox("Mostrar a janelinha quando uma função for acionada")
        self.hud_enabled_checkbox.setChecked(bool(self.store.data.get("show_action_hud", True)))
        self.hud_enabled_checkbox.toggled.connect(self._on_hud_options_changed)
        form.addRow("Notificações flutuantes:", self.hud_enabled_checkbox)
        hud_options_row = QHBoxLayout()
        self.hud_position_combo = QComboBox()
        self.hud_position_combo.addItem("Canto inferior direito", "bottom_right")
        self.hud_position_combo.addItem("Canto inferior esquerdo", "bottom_left")
        self.hud_position_combo.addItem("Canto superior direito", "top_right")
        self.hud_position_combo.addItem("Canto superior esquerdo", "top_left")
        position_index = self.hud_position_combo.findData(str(self.store.data.get("hud_position", "bottom_right")))
        self.hud_position_combo.setCurrentIndex(max(0, position_index))
        self.hud_position_combo.currentIndexChanged.connect(self._on_hud_options_changed)
        hud_options_row.addWidget(self.hud_position_combo, 1)
        self.hud_duration_spin = QSpinBox()
        self.hud_duration_spin.setRange(700, 5000)
        self.hud_duration_spin.setSingleStep(250)
        self.hud_duration_spin.setSuffix(" ms")
        self.hud_duration_spin.setValue(int(self.store.data.get("hud_duration_ms", 1180)))
        self.hud_duration_spin.valueChanged.connect(self._on_hud_options_changed)
        hud_options_row.addWidget(self.hud_duration_spin)
        form.addRow("Posição / duração:", hud_options_row)
        transfer_row = QHBoxLayout()
        self.export_profile_btn = QPushButton("Exportar perfil…"); self.export_profile_btn.clicked.connect(self._export_profile); transfer_row.addWidget(self.export_profile_btn)
        self.import_profile_btn = QPushButton("Importar perfil…"); self.import_profile_btn.clicked.connect(self._import_profile); transfer_row.addWidget(self.import_profile_btn)
        self.export_diagnostics_btn = QPushButton("Exportar diagnóstico…"); self.export_diagnostics_btn.clicked.connect(self._export_diagnostics); transfer_row.addWidget(self.export_diagnostics_btn)
        form.addRow("Backup e suporte:", transfer_row)
        appearance_layout.addWidget(appearance_box)
        privacy = QLabel(f"Privacidade: configurações locais em {APP_DIR}. Não há conta, nuvem ou telemetria.")
        privacy.setWordWrap(True); privacy.setObjectName("muted"); appearance_layout.addWidget(privacy)
        appearance_layout.addStretch(1)
        pages.addTab(appearance, "Aparência / Backup")

        # MIDI page
        midi_page = QWidget(); midi_page_layout = QVBoxLayout(midi_page); midi_page_layout.setContentsMargins(9, 8, 9, 8)
        midi_box = QFrame(); midi_box.setObjectName("panel"); midi_layout = QFormLayout(midi_box); midi_layout.setContentsMargins(13, 12, 13, 12)
        midi_title = QLabel("Conexão MIDI e reconexão automática"); midi_title.setObjectName("section"); midi_layout.addRow(midi_title)
        port_row = QHBoxLayout(); self.port_combo = QComboBox(); self.port_combo.addItem("Automático (SMC-Mixer)", "AUTO")
        self.port_combo.currentIndexChanged.connect(self._on_port_selected); port_row.addWidget(self.port_combo, 1)
        self.rescan_btn = QPushButton("Reescanear portas"); self.rescan_btn.clicked.connect(self._rescan_midi); port_row.addWidget(self.rescan_btn)
        midi_layout.addRow("Entrada MIDI:", port_row)
        self.transport_mode_combo = QComboBox()
        self.transport_mode_combo.addItem("Detectar pelo nome da porta", "auto")
        self.transport_mode_combo.addItem("USB", "usb")
        self.transport_mode_combo.addItem("Bluetooth LE (via driver Windows)", "bluetooth")
        transport_mode = str(self.store.data.get("midi_transport", "auto"))
        self.transport_mode_combo.setCurrentIndex(max(0, self.transport_mode_combo.findData(transport_mode)))
        self.transport_mode_combo.currentIndexChanged.connect(self._on_transport_mode_changed)
        transport_row = QHBoxLayout()
        transport_row.addWidget(self.transport_mode_combo, 1)
        self.ble_help_btn = QPushButton("Driver / BLE MIDI oficial")
        self.ble_help_btn.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://www.m-vave.com/download")))
        transport_row.addWidget(self.ble_help_btn)
        midi_layout.addRow("Tipo de conexão:", transport_row)
        midi_info = QLabel("CORREÇÃO IMPORTANTE — SELECT 2/Fader 6 e SELECT 3/Fader 7: se esses botões ainda movem os faders, o controlador está enviando mensagens CC que se sobrepõem. No MidiSuite da M-VAVE, mude somente os botões físicos M, S, R, SELECT e transporte de CC para Note; atribua uma nota exclusiva a cada botão e salve a configuração no controlador. Mantenha faders e knobs em CC. Uma mensagem MIDI idêntica não contém informação que permita separar as duas peças físicas; o aplicativo não pode adivinhar sua origem. Depois, reaprenda os botões nesta tela. Para Bluetooth LE, use a ponte/driver MIDI compatível do fabricante; selecionar Bluetooth aqui não cria a ponte. Feche outros programas MIDI antes de testar.")
        midi_info.setWordWrap(True); midi_info.setObjectName("muted"); midi_layout.addRow(midi_info)
        monitor_row = QHBoxLayout()
        midi_monitor_btn = QPushButton("Abrir monitor de eventos MIDI")
        midi_monitor_btn.clicked.connect(self._show_midi_monitor)
        monitor_row.addWidget(midi_monitor_btn)
        monitor_row.addStretch(1)
        midi_page_layout.addWidget(midi_box)
        midi_page_layout.addLayout(monitor_row)
        midi_page_layout.addStretch(1)
        pages.addTab(midi_page, "MIDI")

        # Equalizer APO page
        eq_page = QWidget(); eq_page_layout = QVBoxLayout(eq_page); eq_page_layout.setContentsMargins(9, 8, 9, 8)
        eq_box = QFrame(); eq_box.setObjectName("panel"); eq_layout = QFormLayout(eq_box); eq_layout.setContentsMargins(13, 12, 13, 12)
        eq_title = QLabel("Integração com Equalizer APO"); eq_title.setObjectName("section"); eq_layout.addRow(eq_title)
        path_row = QHBoxLayout(); self.eq_path_edit = QLineEdit(); self.eq_path_edit.setPlaceholderText(str(APP_DIR / "equalizerapo_filters.txt"))
        self.eq_path_edit.editingFinished.connect(lambda: self._on_eq_path_changed(self.eq_path_edit.text())); path_row.addWidget(self.eq_path_edit, 1)
        browse_btn = QPushButton("Escolher arquivo…"); browse_btn.clicked.connect(self._browse_eq_file); path_row.addWidget(browse_btn)
        eq_layout.addRow("Arquivo de filtros:", path_row)
        eq_buttons = QHBoxLayout(); copy_include_btn = QPushButton("Copiar linha Include"); copy_include_btn.clicked.connect(self._copy_include_line); eq_buttons.addWidget(copy_include_btn)
        open_dir_btn = QPushButton("Abrir pasta do arquivo"); open_dir_btn.clicked.connect(self._open_eq_folder); eq_buttons.addWidget(open_dir_btn)
        write_btn = QPushButton("Gerar / atualizar filtros"); write_btn.setObjectName("primary"); write_btn.clicked.connect(self._write_eq_file); eq_buttons.addWidget(write_btn)
        self.eqapo_setup_btn = QPushButton("Vincular ao APO automaticamente")
        self.eqapo_setup_btn.clicked.connect(self._configure_equalizer_apo)
        self.eqapo_setup_btn.setToolTip("Adiciona o arquivo de filtros ao config.txt do Equalizer APO, cria backup e solicita permissão de administrador se necessário.")
        eq_buttons.addWidget(self.eqapo_setup_btn)
        diagnose_eq_btn = QPushButton("Diagnosticar EQ")
        diagnose_eq_btn.setToolTip("Verifica arquivo de filtros, caminho Include e possíveis problemas de escopo.")
        diagnose_eq_btn.clicked.connect(self._diagnose_equalizer_apo)
        eq_buttons.addWidget(diagnose_eq_btn)
        eq_layout.addRow(eq_buttons)
        eq_help = QLabel("O PyCAW não processa DSP. O Equalizer APO aplica os filtros no dispositivo de saída escolhido no Windows. A linha Include precisa estar em config.txt; HP/LP habilitam Low Cut e High Cut.")
        eq_help.setWordWrap(True); eq_help.setObjectName("muted"); eq_layout.addRow(eq_help)
        eq_page_layout.addWidget(eq_box); eq_page_layout.addStretch(1); pages.addTab(eq_page, "Equalizador global")

        return pages

    def _show_midi_monitor(self) -> None:
        dialog = QDialog(self)
        dialog.setWindowTitle("Monitor de eventos MIDI · Rafael Souza")
        dialog.resize(760, 460)
        layout = QVBoxLayout(dialog)
        info = QLabel("Mostra as últimas 100 mensagens recebidas. Os valores ajudam a diferenciar CC absoluto, CC Toggle/Push e Note On/Off. Esta janela é somente de diagnóstico.")
        info.setWordWrap(True)
        layout.addWidget(info)
        from PyQt6.QtWidgets import QPlainTextEdit
        view = QPlainTextEdit()
        view.setReadOnly(True)
        view.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        view.setPlainText("\n".join(self._midi_event_log) if self._midi_event_log else "Nenhuma mensagem MIDI recebida ainda. Mova um fader/knob ou pressione um botão físico.")
        layout.addWidget(view, 1)
        buttons = QHBoxLayout()
        refresh = QPushButton("Atualizar")
        refresh.clicked.connect(lambda: view.setPlainText("\n".join(self._midi_event_log) if self._midi_event_log else "Nenhuma mensagem MIDI recebida ainda."))
        buttons.addWidget(refresh)
        clear = QPushButton("Limpar histórico")
        def clear_history() -> None:
            self._midi_event_log.clear()
            view.clear()
        clear.clicked.connect(clear_history)
        buttons.addWidget(clear)
        buttons.addStretch(1)
        close = QPushButton("Fechar")
        close.clicked.connect(dialog.accept)
        buttons.addWidget(close)
        layout.addLayout(buttons)
        dialog.exec()

    # ---------- Appearance, profile transfer and diagnostics ----------
    def _persist_root_settings(self) -> bool:
        if self.store.save():
            return True
        message = f"Não foi possível salvar as configurações: {self.store.last_error}"
        logging.getLogger("smc_mixer_suite").error(message)
        self.statusBar().showMessage(message, 7000)
        return False

    def _on_theme_changed(self, _name: str) -> None:
        if getattr(self, "_loading", False):
            return
        self.store.data["theme"] = self.theme_combo.currentText() or DEFAULT_THEME
        self._apply_theme(save=False)
        self._persist_root_settings()

    def _choose_accent_color(self) -> None:
        current = QColor(str(self.store.data.get("custom_accent") or resolve_palette(self.store.data.get("theme", DEFAULT_THEME))["accent"]))
        chosen = QColorDialog.getColor(current, self, "Escolher cor de destaque")
        if not chosen.isValid():
            return
        self.store.data["custom_accent"] = chosen.name().lower()
        self._apply_theme(save=False)
        if self._persist_root_settings():
            self.statusBar().showMessage(f"Cor de destaque alterada para {chosen.name().upper()}", 2500)

    def _reset_custom_accent(self, *_args) -> None:
        self.store.data["custom_accent"] = ""
        self._apply_theme(save=False)
        if self._persist_root_settings():
            self.statusBar().showMessage("Cor padrão do tema restaurada.", 2500)

    def _on_compact_ui_changed(self, checked: bool) -> None:
        if getattr(self, "_loading", False):
            return
        self.store.data["compact_ui"] = bool(checked)
        self._apply_theme(save=False)
        self._persist_root_settings()

    def _on_hud_options_changed(self, *_args) -> None:
        if getattr(self, "_loading", False):
            return
        self.store.data["show_action_hud"] = bool(self.hud_enabled_checkbox.isChecked())
        self.store.data["hud_position"] = str(self.hud_position_combo.currentData() or "bottom_right")
        self.store.data["hud_duration_ms"] = int(self.hud_duration_spin.value())
        if hasattr(self, "hud"):
            self.hud.set_options(
                enabled=self.store.data["show_action_hud"],
                position=self.store.data["hud_position"],
                duration_ms=self.store.data["hud_duration_ms"],
            )
        self._persist_root_settings()

    def _apply_theme(self, save: bool = False) -> None:
        theme_name = str(self.store.data.get("theme", DEFAULT_THEME))
        if hasattr(self, "theme_combo") and self.theme_combo.currentText() in THEMES:
            theme_name = self.theme_combo.currentText()
        if theme_name not in THEMES:
            theme_name = DEFAULT_THEME
        custom_accent = str(self.store.data.get("custom_accent", ""))
        palette = resolve_palette(theme_name, custom_accent)
        self._active_palette = palette
        compact = effective_compact_mode(
            bool(self.store.data.get("compact_ui", False)), self.width(), self.height()
        )
        self._effective_compact = compact
        self.setStyleSheet(build_stylesheet(DARK_STYLE, palette, compact))
        available_width = self.tabs.width() if hasattr(self, "tabs") else self.width()
        strip_width = recommended_channel_strip_width(available_width)
        for strip in getattr(self, "channel_strips", []):
            strip.set_theme_palette(palette, compact)
            strip.set_adaptive_width(compact or strip_width < 116, strip_width)
        for eq_control in getattr(self, "eq_controls", []):
            eq_knob = eq_control.get("knob")
            if isinstance(eq_knob, RotaryKnob):
                eq_knob.set_theme_colors(palette["accent"], palette["track"])
        if hasattr(self, "hud"):
            self.hud.set_theme_palette(palette)
        if hasattr(self, "connection_dot"):
            self.connection_dot.setStyleSheet(f"color:{palette['warning']}; font-size:16px;")
        if hasattr(self, "bank_label"):
            self.bank_label.setStyleSheet(
                f"padding:5px 10px; background:{palette['card']}; border:1px solid {palette['border']}; "
                f"border-radius:5px; color:{palette['text']}; font-weight:800;"
            )
        if hasattr(self, "accent_color_btn"):
            self.accent_color_btn.setText(f"Destaque {palette['accent'].upper()}  ·  botão direito para restaurar")
            self.accent_color_btn.setStyleSheet(f"border-left:6px solid {palette['accent']};")
            self.accent_color_btn.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            try:
                self.accent_color_btn.customContextMenuRequested.disconnect()
            except Exception:
                pass
            self.accent_color_btn.customContextMenuRequested.connect(self._reset_custom_accent)
        if hasattr(self, "theme_combo") and self.theme_combo.currentText() != theme_name:
            self.theme_combo.blockSignals(True)
            self.theme_combo.setCurrentText(theme_name)
            self.theme_combo.blockSignals(False)
        if save:
            self.store.data["theme"] = theme_name
            self._persist_root_settings()

    def _export_profile(self) -> None:
        suggested = f"SMC_{self.store.data['active_profile'].replace(' ', '_')}.json"
        path, _ = QFileDialog.getSaveFileName(self, "Exportar perfil", str(Path.home() / suggested), "Perfil SMC Mixer (*.json)")
        if not path:
            return
        payload = {
            "format": "smc-mixer-suite-profile",
            "format_version": 2,
            "profile_name": self.store.data["active_profile"],
            "profile": copy.deepcopy(self.profile),
        }
        try:
            destination = Path(path)
            if destination.suffix.lower() != ".json":
                destination = destination.with_suffix(".json")
            destination.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
            QMessageBox.information(self, "Perfil exportado", f"O perfil foi exportado para:\n{destination}")
        except Exception as exc:
            logging.getLogger("smc_mixer_suite").exception("Profile export failed")
            QMessageBox.critical(self, "Falha ao exportar", f"Não foi possível exportar o perfil.\n\n{exc}")

    def _import_profile(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Importar perfil", str(Path.home()), "Perfil SMC Mixer (*.json)")
        if not path:
            return
        try:
            payload = json.loads(Path(path).read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                raise ValueError("O JSON deve conter um objeto de perfil.")
            raw_profile = payload.get("profile", payload)
            if not isinstance(raw_profile, dict):
                raise ValueError("Não encontrei um perfil válido no arquivo.")
            suggested = str(payload.get("profile_name", raw_profile.get("name", Path(path).stem)))[:80]
            name, ok = QInputDialog.getText(self, "Importar perfil", "Nome para o perfil importado:", text=f"{suggested} (importado)")
            name = name.strip()[:80]
            if not ok or not name:
                return
            if name in self.store.data["profiles"]:
                QMessageBox.warning(self, "Nome já utilizado", "Já existe um perfil com esse nome. Escolha outro nome para não sobrescrever dados por acidente.")
                return
            previous_active = self.store.data["active_profile"]
            self.store.data["profiles"][name] = _normalize_profile(raw_profile, name)
            self.store.data["active_profile"] = name
            if not self._persist_root_settings():
                self.store.data["profiles"].pop(name, None)
                self.store.data["active_profile"] = previous_active
                return
            self._restore_solo_snapshot()
            self._load_profile_to_ui()
            self._sync_led_engine_settings()
            self.statusBar().showMessage(f"Perfil importado: {name}", 3500)
        except Exception as exc:
            logging.getLogger("smc_mixer_suite").exception("Profile import failed")
            QMessageBox.critical(self, "Falha ao importar", f"O arquivo não pôde ser importado. Verifique se é um JSON de perfil válido.\n\n{exc}")

    def _export_diagnostics(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Exportar diagnóstico", str(Path.home() / "SMC_Mixer_Suite_Diagnostico.zip"), "Pacote de diagnóstico (*.zip)")
        if not path:
            return
        try:
            ports = list(getattr(getattr(self, "midi", None), "_last_ports", []))
            destination = build_diagnostics_archive(path, __version__, ports)
            QMessageBox.information(self, "Diagnóstico exportado", f"Arquivo criado:\n{destination}\n\nO pacote não inclui settings.json nem senhas. Revise os logs antes de compartilhar.")
        except Exception as exc:
            logging.getLogger("smc_mixer_suite").exception("Diagnostics export failed")
            QMessageBox.critical(self, "Falha ao exportar diagnóstico", str(exc))

    def _filter_button_table(self, query: str) -> None:
        if not hasattr(self, "button_table"):
            return
        needle = str(query or "").strip().casefold()
        self._button_filtered_specs = []
        for spec in BUTTON_SPECS:
            row = self.profile.get("button_actions", {}).get(spec.control_id, {})
            action_label = next((label for label, key in ACTION_CHOICES if key == row.get("action")), str(row.get("action", "")))
            parts = [spec.control_id, spec.label, spec.group, spec.key or "", spec.help_text,
                     action_label, str(row.get("argument", "")), midi_key_label(row.get("midi"))]
            if not needle or needle in " ".join(parts).casefold():
                self._button_filtered_specs.append(spec)
        self._button_page = 0
        self._populate_button_table()

    def _change_button_page(self, delta: int) -> None:
        filtered = getattr(self, "_button_filtered_specs", list(BUTTON_SPECS))
        max_page = max(0, (len(filtered) - 1) // max(1, self._button_page_size))
        self._button_page = max(0, min(max_page, self._button_page + int(delta)))
        self._populate_button_table()

    def _button_spec_for_row(self, row_index: int):
        page_specs = getattr(self, "_button_page_specs", [])
        return page_specs[row_index] if 0 <= row_index < len(page_specs) else None

    def _create_tray(self) -> None:
        icon_path = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[2])) / "static" / "smc_mixer_suite.ico"
        icon = QIcon(str(icon_path)) if icon_path.exists() else self.style().standardIcon(QStyle.StandardPixmap.SP_MediaVolume)
        self.setWindowIcon(icon)
        self.tray = QSystemTrayIcon(icon, self)
        self.tray.setToolTip("SMC Mixer Suite")
        menu = QMenu()
        show_action = QAction("Abrir SMC Mixer Suite", self)
        show_action.triggered.connect(self._show_from_tray)
        menu.addAction(show_action)
        menu.addSeparator()
        exit_action = QAction("Sair", self)
        exit_action.triggered.connect(self._exit_application)
        menu.addAction(exit_action)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._on_tray_activated)
        self.tray.show()

    # ---------- Profiles, banks and widget hydration ----------
    def _load_profile_to_ui(self) -> None:
        self._loading = True
        self._eq_ab_active_slot = None
        if hasattr(self, "eq_ab_toggle_btn"):
            self.eq_ab_toggle_btn.setText("Comparar A/B")
        try:
            self.profile_combo.blockSignals(True)
            self.profile_combo.clear()
            self.profile_combo.addItems(list(self.store.data["profiles"].keys()))
            self.profile_combo.setCurrentText(self.store.data["active_profile"])
            self.profile_combo.blockSignals(False)

            self.store.sync_legacy_bank_fields(self.profile)
            self._bank_names = [str(bank.get("name") or f"Banco {i + 1}") for i, bank in enumerate(self.profile["banks"])]
            bank_number = int(self.profile.get("active_bank", 0)) + 1
            self.bank_label.setText(f"{self._bank_names[bank_number - 1].upper()}  ·  {bank_number}/4")

            for index, strip in enumerate(self.channel_strips):
                strip.set_name(self._current_channel_name(index))
                colors = self.active_bank.get("channel_colors", CHANNEL_DEFAULT_COLORS)
                strip.set_channel_color(colors[index] if index < len(colors) else CHANNEL_DEFAULT_COLORS[index])
                selected_target = self._current_target(index)
                items = [("Master output (Windows)", "__master__")]
                items.extend(self.audio.list_brightness_targets())
                items.append(("— Não atribuído —", ""))
                items.extend((self._process_label(row), row["key"]) for row in self._process_cache)
                strip.set_target_items(items, selected_target)
                strip.set_fader_value(75, "—", 0)
                strip.set_knob_value(0, -120, 120, "+0.0 dB\n63 Hz")
                strip.set_mapping_text("fader", "MAPEAR FADER" if not self.profile["fader_midi"][index] else f"✓ {midi_key_label(self.profile['fader_midi'][index])}")
                strip.set_mapping_text("knob", "MAPEAR KNOB" if not self.profile["knob_midi"][index] else f"✓ {midi_key_label(self.profile['knob_midi'][index])}")
                strip.set_selected(index == self._selected_channel)
                for suffix in ("mute", "solo", "rec", "select"):
                    row = self.profile["button_actions"].get(f"ch{index + 1}_{suffix}", {})
                    strip.set_button_mapped(suffix, bool(row.get("midi")))

            self.knob_target_combo.blockSignals(True)
            self.knob_target_combo.setCurrentIndex(0 if self.profile.get("knob_target_mode", "eq") == "eq" else 1)
            self.knob_target_combo.blockSignals(False)
            self.eq_band_mode_combo.blockSignals(True)
            self.eq_band_mode_combo.setCurrentIndex({3: 0, 5: 1, 8: 2}.get(int(self.profile.get("eq_mode", 8)), 2))
            self.eq_band_mode_combo.blockSignals(False)
            self._rebuild_eq_band_controls()
            self._load_eq_band_values()
            self.eq_fixed_freq_checkbox.blockSignals(True)
            self.eq_fixed_freq_checkbox.setChecked(bool(self.profile.get("eq_fixed_frequencies", True)))
            self.eq_fixed_freq_checkbox.blockSignals(False)
            self.eq_bypass_btn.blockSignals(True)
            self.eq_bypass_btn.setChecked(bool(self.profile["eq_bypass"]))
            self.eq_bypass_btn.setText("BYPASS ON" if self.profile["eq_bypass"] else "BYPASS OFF")
            self.eq_bypass_btn.blockSignals(False)
            self._load_eq_cutoff_values()
            self._refresh_eq_preset_combo()
            self.led_enabled_checkbox.blockSignals(True)
            self.led_enabled_checkbox.setChecked(bool(self.profile.get("led_feedback_enabled", False)))
            self.led_enabled_checkbox.blockSignals(False)
            led_idx = self.led_mode_combo.findData(self.profile.get("led_mode", "equalizer"))
            self.led_mode_combo.blockSignals(True)
            self.led_mode_combo.setCurrentIndex(max(0, led_idx))
            self.led_mode_combo.blockSignals(False)
            self.led_speed_slider.blockSignals(True)
            self.led_speed_slider.setValue(round(float(self.profile.get("led_speed", 1.0)) * 100))
            self.led_speed_slider.blockSignals(False)
            self.led_speed_label.setText(f"{self.led_speed_slider.value() / 100:.2f}×")
            self.led_brightness_slider.blockSignals(True)
            self.led_brightness_slider.setValue(round(float(self.profile.get("led_brightness", 0.8)) * 100))
            self.led_brightness_slider.blockSignals(False)
            self.led_brightness_label.setText(f"{self.led_brightness_slider.value()}%")
            self._rescan_led_outputs(select=self.profile.get("led_output_port", "AUTO"))
            self.knob_mode_combo.blockSignals(True)
            mode_key = normalize_knob_mode(self.profile.get("knob_mode", "relative_twos"))
            mode_index = self.knob_mode_combo.findData(mode_key)
            self.knob_mode_combo.setCurrentIndex(mode_index if mode_index >= 0 else 0)
            self.knob_mode_combo.blockSignals(False)
            self._knob_probe_samples.clear()
            self._detected_knob_modes.clear()
            self._update_knob_mode_help()
            if hasattr(self, "knob_input_status"):
                self.knob_input_status.setText("Entrada MIDI: aguardando giro de um encoder mapeado.")
            self.knob_step_spin.blockSignals(True)
            self.knob_step_spin.setValue(round(float(self.profile["knob_step_db"]) * 10))
            self.knob_step_spin.blockSignals(False)
            self.knob_invert_check.blockSignals(True)
            self.knob_invert_check.setChecked(bool(self.profile.get("knob_invert", False)))
            self.knob_invert_check.blockSignals(False)
            self.hysteresis_spin.blockSignals(True)
            self.hysteresis_spin.setValue(int(self.profile.get("midi_hysteresis", 1)))
            self.hysteresis_spin.blockSignals(False)
            self.eq_path_edit.blockSignals(True)
            self.eq_path_edit.setText(self.store.data.get("eq_file", str(APP_DIR / "equalizerapo_filters.txt")))
            self.eq_path_edit.blockSignals(False)
            if hasattr(self, "button_table"):
                self._populate_button_table()
            self._refresh_button_target_combos()
            self._refresh_midi_mapping_labels()
            self._update_knob_visuals()
            self._refresh_eq_preset_combo()
            self._sync_led_engine_settings()
            self._schedule_eq_write()
        finally:
            self._loading = False

    def _on_profile_selected(self, name: str) -> None:
        if self._loading or not name or name not in self.store.data["profiles"]:
            return
        self._restore_solo_snapshot()
        self._learn_timer.stop()
        self.store.set_active_profile(name)
        self.learning_target = None
        self._load_profile_to_ui()
        self.statusBar().showMessage(f"Perfil ativo: {name}", 3000)

    def _new_profile(self) -> None:
        name, ok = QInputDialog.getText(self, "Novo perfil", "Nome do perfil:")
        if not ok:
            return
        if not self.store.create_profile(name):
            QMessageBox.warning(self, "Perfil não criado", "Informe um nome que ainda não exista.")
            return
        self._load_profile_to_ui()

    def _clone_profile(self) -> None:
        name, ok = QInputDialog.getText(self, "Duplicar perfil", "Nome da cópia:", text=f"{self.store.data['active_profile']} - cópia")
        if not ok:
            return
        if not self.store.create_profile(name, clone_active=True):
            QMessageBox.warning(self, "Perfil não duplicado", "Informe um nome que ainda não exista.")
            return
        self._load_profile_to_ui()

    def _delete_profile(self) -> None:
        name = self.store.data["active_profile"]
        if len(self.store.data["profiles"]) <= 1:
            QMessageBox.information(self, "Perfil obrigatório", "O aplicativo precisa manter pelo menos um perfil.")
            return
        if QMessageBox.question(self, "Excluir perfil", f"Excluir o perfil ‘{name}’? Isso não pode ser desfeito.") != QMessageBox.StandardButton.Yes:
            return
        self.store.delete_profile(name)
        self._load_profile_to_ui()

    def _queue_profile_save(self) -> None:
        """Debounce profile JSON saves while faders/encoders are moving."""
        if hasattr(self, "_profile_save_timer"):
            self._profile_save_timer.start()
        else:
            self._save_profile()

    def _schedule_eq_write(self) -> None:
        """Throttle EQ file writes without postponing them until knob movement stops.

        A conventional debounced single-shot timer restarted on every MIDI tick could
        leave Equalizer APO with a stale curve while the user kept turning an encoder.
        Start only when idle: sustained moves then update the file at least every 90 ms.
        """
        timer = getattr(self, "_eq_save_timer", None)
        if timer is not None and not timer.isActive():
            timer.start()

    def _save_profile(self) -> None:
        if hasattr(self, "_profile_save_timer"):
            self._profile_save_timer.stop()
        try:
            self.store.sync_legacy_bank_fields(self.profile)
            if not self.store.save():
                self.statusBar().showMessage(f"Não foi possível salvar as configurações: {self.store.last_error}", 7000)
        except Exception as exc:
            logging.getLogger("smc_mixer_suite").exception("Profile save failed")
            if hasattr(self, "statusBar"):
                self.statusBar().showMessage(f"Falha ao salvar configurações: {exc}", 7000)

    @staticmethod
    def _process_label(row: dict[str, Any]) -> str:
        name = str(row.get("name") or row.get("key") or "Aplicativo")
        sessions = int(row.get("sessions", row.get("session_count", 1)) or 1)
        return f"{name} · {sessions} sessões" if sessions > 1 else name

    def _refresh_processes(self, processes: list[dict[str, Any]] | None = None, force: bool = False) -> None:
        """Update process menus only when the available application set changes."""
        if processes is None:
            return
        new_processes = [row for row in processes if isinstance(row, dict) and row.get("key")]
        old_signature = tuple(sorted((row.get("key", "").casefold(), int(row.get("sessions", 1) or 1)) for row in self._process_cache))
        new_signature = tuple(sorted((row.get("key", "").casefold(), int(row.get("sessions", 1) or 1)) for row in new_processes))
        if not force and old_signature == new_signature:
            self._process_cache = new_processes
            return
        self._process_cache = new_processes
        self._loading = True
        try:
            for index, strip in enumerate(self.channel_strips):
                items = [("Master output (Windows)", "__master__")]
                items.extend(self.audio.list_brightness_targets())
                items.append(("— Não atribuído —", ""))
                items.extend((self._process_label(row), row["key"]) for row in self._process_cache)
                strip.set_target_items(items, self._current_target(index))
        finally:
            self._loading = False

    def _on_fader_target_changed(self, index: int, target: str) -> None:
        if self._loading:
            return
        self.active_bank["fader_targets"][index] = target
        self.store.sync_legacy_bank_fields(self.profile)
        self._save_profile()
        self._refresh_audio_ui()

    def _on_channel_name_changed(self, index: int, name: str) -> None:
        if self._loading:
            return
        self.active_bank["channel_names"][index] = name[:48] or f"Canal {index + 1}"
        self.store.sync_legacy_bank_fields(self.profile)
        self._save_profile()
        self._refresh_button_target_combos()
        self.statusBar().showMessage(f"Canal {index + 1} renomeado para {self.active_bank['channel_names'][index]}", 2500)

    def _choose_channel_color(self, index: int) -> None:
        if self._loading or not (0 <= index < 8):
            return
        colors = self.active_bank.setdefault("channel_colors", list(CHANNEL_DEFAULT_COLORS))
        if len(colors) < 8:
            colors.extend(CHANNEL_DEFAULT_COLORS[len(colors):])
        current = QColor(str(colors[index] or CHANNEL_DEFAULT_COLORS[index]))
        chosen = QColorDialog.getColor(current, self, f"Cor do canal {index + 1}")
        if not chosen.isValid():
            return
        color = chosen.name().lower()
        colors[index] = color
        self.channel_strips[index].set_channel_color(color)
        self.store.sync_legacy_bank_fields(self.profile)
        self._save_profile()
        self.hud.show_event(self._current_channel_name(index), color.upper(), 100, "COR DO CANAL")
        self.statusBar().showMessage(f"Cor do canal {index + 1} salva: {color}", 2500)

    def _set_active_bank(self, index: int) -> None:
        index = max(0, min(3, index))
        if index == self.profile.get("active_bank", 0):
            return
        self._restore_solo_snapshot()
        self.profile["active_bank"] = index
        self.store.sync_legacy_bank_fields(self.profile)
        self._save_profile()
        self._load_profile_to_ui()
        self.statusBar().showMessage(f"Banco ativo: {self.active_bank.get('name', f'Banco {index + 1}')}", 2500)
        self.hud.show_event(f"Banco {index + 1}", f"{index + 1}/4", (index + 1) * 25, "NAVEGAÇÃO")

    def _navigate_bank(self, delta: int) -> None:
        current = int(self.profile.get("active_bank", 0))
        self._set_active_bank((current + delta) % 4)

    # ---------- Audio and on-screen adjustments ----------
    def _on_master_panel_volume_changed(self, value: int) -> None:
        """Apply the Windows master volume without blocking the Qt event loop."""
        if self._loading:
            return
        percent = max(0, min(100, int(value)))
        self.master_volume_label.setText(f"{percent}%")
        self._queue_volume_write("__master__", percent / 100.0)

    def _toggle_master_from_panel(self) -> None:
        """Toggle mute on the default Windows playback endpoint."""
        try:
            ok = self.audio.toggle_mute("__master__")
        except Exception:
            logging.getLogger("smc_mixer_suite").exception("Could not toggle Windows master mute")
            ok = False
        if not ok:
            self.statusBar().showMessage("Não foi possível alternar o mute do volume master do Windows.", 4500)
        else:
            self._refresh_audio_ui()

    def _on_microphone_panel_volume_changed(self, value: int) -> None:
        """Coalesce microphone slider changes and perform the COM write in a worker."""
        if self._loading:
            return
        percent = max(0, min(100, int(value)))
        self.microphone_volume_label.setText(f"{percent}%")
        self._microphone_write_pending = percent / 100.0
        self._microphone_write_timer.start()

    def _dispatch_microphone_write(self) -> None:
        """Start one microphone write at a time; retain only the latest pending value."""
        if self._microphone_write_active or self._microphone_write_pending is None:
            return
        scalar = self._microphone_write_pending
        self._microphone_write_pending = None
        worker = _MicrophoneWriteWorker(self.audio, scalar)
        worker.signals.finished.connect(self._on_microphone_write_finished)
        self._microphone_write_worker = worker
        self._microphone_write_active = True
        try:
            self._microphone_write_pool.start(worker)
        except Exception:
            self._microphone_write_active = False
            self._microphone_write_worker = None
            logging.getLogger("smc_mixer_suite").exception("Could not schedule microphone volume write")
            self.statusBar().showMessage("Não foi possível aplicar o ganho do microfone.", 4500)

    def _on_microphone_write_finished(self, ok: bool, scalar: float) -> None:
        self._microphone_write_active = False
        self._microphone_write_worker = None
        if not ok:
            logging.getLogger("smc_mixer_suite").warning("Microphone volume write was not applied (requested %.3f)", scalar)
            self.statusBar().showMessage("Não foi possível alterar o ganho do microfone. Verifique o dispositivo de captura padrão do Windows.", 5500)
        # If the user moved the slider while the worker was running, apply the most
        # recent value rather than replaying every intermediate position.
        if self._microphone_write_pending is not None:
            self._dispatch_microphone_write()

    def _toggle_microphone_from_panel(self) -> None:
        """Toggle mute on the default Windows capture endpoint."""
        try:
            ok = self.audio.toggle_microphone_mute()
        except Exception:
            logging.getLogger("smc_mixer_suite").exception("Could not toggle Windows microphone mute")
            ok = False
        if not ok:
            self.statusBar().showMessage("Não foi possível alternar o mute do microfone do Windows.", 4500)
        else:
            self._refresh_audio_ui()

    def _on_display_target_changed(self, _index: int) -> None:
        """Refresh the brightness control for the selected display target."""
        target = str(self.display_target_combo.currentData() or "")
        scalar = self._last_volumes.get(target)
        if scalar is not None:
            percent = round(max(0.0, min(1.0, float(scalar))) * 100)
            self.display_brightness_slider.blockSignals(True)
            self.display_brightness_slider.setValue(percent)
            self.display_brightness_slider.blockSignals(False)
            self.display_brightness_label.setText(f"{percent}%")
        else:
            self.display_brightness_label.setText(f"{self.display_brightness_slider.value()}%")

    def _on_display_brightness_changed(self, value: int) -> None:
        """Queue a brightness write for the currently selected compatible display."""
        if self._loading:
            return
        percent = max(0, min(100, int(value)))
        self.display_brightness_label.setText(f"{percent}%")
        target = str(self.display_target_combo.currentData() or "")
        if target and self.audio.is_brightness_target(target):
            self._queue_volume_write(target, percent / 100.0)

    def _launch_quick_target(self) -> None:
        """Open the path, application or URL entered in the Windows quick-action field."""
        target = self.quick_launch_edit.text().strip()
        if not target:
            self.statusBar().showMessage("Informe um aplicativo, arquivo ou URL para abrir.", 3500)
            self.quick_launch_edit.setFocus()
            return
        ok, message = execute_action("launch", target, self.audio)
        self.statusBar().showMessage(("✓ " if ok else "⚠ ") + message, 5000)

    def _schedule_macro_save(self, *_args) -> None:
        """Debounce edits to the eight user-configurable macro rows."""
        timer = getattr(self, "_macro_save_timer", None)
        if timer is not None:
            timer.start()

    def _persist_macros_from_ui(self) -> None:
        """Copy macro editor values to the active profile and queue a profile save."""
        rows = getattr(self, "macro_rows", [])
        macros = []
        for index, row in enumerate(rows[:8]):
            macros.append({
                "name": row["name"].text().strip() or f"Macro {index + 1}",
                "action": str(row["action"].currentData() or "none"),
                "argument": row["argument"].text().strip(),
            })
        while len(macros) < 8:
            macros.append({"name": f"Macro {len(macros) + 1}", "action": "none", "argument": ""})
        self.profile["macros"] = macros
        self._queue_profile_save()

    def _on_ui_fader_changed(self, index: int, value: int) -> None:
        if self._loading:
            return
        target = self._current_target(index)
        if target:
            scalar = value / 100.0
            self._queue_volume_write(target, scalar)
        if self.audio.is_brightness_target(target):
            label = f"{value}% · BRILHO"
        else:
            label = f"{value}%  ·  {self._db_label(value / 100.0)}"
        self.channel_strips[index].set_fader_value(value, label, value)
        if self.audio.is_brightness_target(target):
            self.channel_strips[index].set_meter_percent(value, "Brilho de tela")

    @staticmethod
    def _db_label(scalar: float) -> str:
        return "−∞ dB" if scalar <= 0 else f"{20 * math.log10(max(1e-9, scalar)):+.1f} dB"

    def _queue_volume_write(self, target: str, scalar: float) -> None:
        if not target:
            return
        value = max(0.0, min(1.0, float(scalar)))
        self._pending_volume_updates[target] = value
        self._last_volumes[target] = value
        self._volume_apply_timer.start()

    def _apply_pending_volume_updates(self) -> None:
        if not self._pending_volume_updates:
            return
        updates = dict(self._pending_volume_updates)
        self._pending_volume_updates.clear()
        brightness = {target: value for target, value in updates.items() if self.audio.is_brightness_target(target)}
        audio = {target: value for target, value in updates.items() if not self.audio.is_brightness_target(target)}
        if audio:
            outcomes = self.audio.set_volumes(audio)
            failed = [target for target, ok in outcomes.items() if not ok]
            if failed:
                logging.getLogger("smc_mixer_suite").debug("Volume targets without an active audio session: %s", failed)
        if brightness:
            self._pending_brightness_updates.update(brightness)
            self._dispatch_brightness_writes()

    def _dispatch_brightness_writes(self) -> None:
        if self._brightness_worker_active or not self._pending_brightness_updates:
            return
        updates = dict(self._pending_brightness_updates)
        self._pending_brightness_updates.clear()
        worker = _BrightnessWriteWorker(self.audio, updates)
        worker.signals.finished.connect(self._on_brightness_writes_finished)
        self._brightness_write_worker = worker
        self._brightness_worker_active = True
        self._brightness_write_pool.start(worker)

    def _on_brightness_writes_finished(self, outcomes: object) -> None:
        self._brightness_worker_active = False
        self._brightness_write_worker = None
        if isinstance(outcomes, dict):
            failures = [target for target, ok in outcomes.items() if not ok]
            if failures:
                self.statusBar().showMessage("Não foi possível alterar o brilho. Alguns monitores externos não aceitam controle DDC/CI; verifique compatibilidade e permissões.", 5500)
        if self._pending_brightness_updates:
            self._dispatch_brightness_writes()

    def _on_hardware_knob_double_click(self, index: int) -> None:
        if self.profile.get("knob_target_mode", "eq") == "eq" and index < int(self.profile.get("eq_mode", 8)):
            self._reset_eq_band(index)
        else:
            self.statusBar().showMessage("O reset Flat por duplo clique está disponível quando os knobs controlam o EQ.", 3000)

    def _on_ui_knob_changed(self, index: int, value: int) -> None:
        if self._loading:
            return
        mode = self.profile.get("knob_target_mode", "eq")
        if mode == "eq":
            if index >= int(self.profile.get("eq_mode", 8)):
                return
            self.profile["eq_gains"][index] = clamp_gain(value / 10.0)
            self._store_active_eq_mode_gains()
            self._mark_eq_curve_custom()
            self._sync_eq_knob(index)
            self._schedule_eq_write()
            self._queue_profile_save()
        else:
            target = self._current_target(index)
            if target:
                self._queue_volume_write(target, value / 100.0)
            label = f"{value}% BRILHO" if self.audio.is_brightness_target(target) else f"{value}%"
            self.channel_strips[index].knob_value.setText(label)

    def _refresh_audio_ui(self) -> None:
        """Schedule at most one audio poll at a time; never block the GUI on COM calls."""
        if self._audio_poll_pending:
            return
        targets = [self._current_target(index) for index in range(8)]
        # The dedicated Windows panel must keep master and monitor controls fresh even
        # when all hardware faders are assigned to individual applications.
        targets.append("__master__")
        targets.extend(target for _label, target in self.audio.list_brightness_targets())
        targets = list(dict.fromkeys(targets))
        self._audio_poll_pending = True
        worker = _AudioPollWorker(self.audio, targets)
        worker.signals.finished.connect(self._on_audio_snapshot)
        self._audio_poll_worker = worker
        try:
            self._audio_poll_pool.start(worker)
        except Exception as exc:
            self._audio_poll_pending = False
            self._audio_poll_worker = None
            logging.getLogger("smc_mixer_suite").exception("Could not schedule audio polling")
            self.statusBar().showMessage(f"Não foi possível atualizar o áudio do Windows: {exc}", 5000)

    def _on_audio_snapshot(self, snapshot: object) -> None:
        self._audio_poll_pending = False
        self._audio_poll_worker = None
        if not isinstance(snapshot, dict):
            return
        processes = snapshot.get("processes", [])
        volumes = snapshot.get("volumes", {})
        mutes = snapshot.get("mutes", {})
        levels_db = snapshot.get("levels_db", {})
        levels_are_peak = snapshot.get("levels_are_peak", {})
        error = str(snapshot.get("error", "") or "")
        if isinstance(processes, list):
            self._refresh_processes(processes)
        if isinstance(volumes, dict):
            self._last_volumes = dict(volumes)
        if isinstance(mutes, dict):
            self._last_mutes = dict(mutes)
        mic_volume = snapshot.get("microphone_volume")
        mic_mute = snapshot.get("microphone_mute")
        if mic_volume is not None and hasattr(self, "microphone_volume_slider") and not self.microphone_volume_slider.isSliderDown():
            mic_pct = round(max(0.0, min(1.0, float(mic_volume))) * 100)
            self.microphone_volume_slider.blockSignals(True)
            self.microphone_volume_slider.setValue(mic_pct)
            self.microphone_volume_slider.blockSignals(False)
            self.microphone_volume_label.setText(f"{mic_pct}%")
        if hasattr(self, "microphone_mute_btn") and mic_mute is not None:
            self.microphone_mute_btn.setText("Desmutar microfone" if bool(mic_mute) else "Silenciar microfone")
        master_mute = self._last_mutes.get("__master__")
        if hasattr(self, "master_mute_btn") and master_mute is not None:
            self.master_mute_btn.setText("Desmutar master" if bool(master_mute) else "Silenciar master")
        if isinstance(levels_db, dict):
            self._last_levels_db = dict(levels_db)
        if isinstance(levels_are_peak, dict):
            self._last_levels_are_peak = dict(levels_are_peak)
        master_scalar = self._last_volumes.get("__master__")
        if master_scalar is not None and hasattr(self, "master_volume_slider") and not self.master_volume_slider.isSliderDown():
            master_pct = round(max(0.0, min(1.0, float(master_scalar))) * 100)
            self.master_volume_slider.blockSignals(True)
            self.master_volume_slider.setValue(master_pct)
            self.master_volume_slider.blockSignals(False)
            self.master_volume_label.setText(f"{master_pct}%")
        if hasattr(self, "display_target_combo"):
            display_target = str(self.display_target_combo.currentData() or "")
            display_scalar = self._last_volumes.get(display_target)
            if display_scalar is not None and not self.display_brightness_slider.isSliderDown():
                display_pct = round(max(0.0, min(1.0, float(display_scalar))) * 100)
                self.display_brightness_slider.blockSignals(True)
                self.display_brightness_slider.setValue(display_pct)
                self.display_brightness_slider.blockSignals(False)
                self.display_brightness_label.setText(f"{display_pct}%")
        if error and error != self._last_audio_error:
            logging.getLogger("smc_mixer_suite").warning("Audio snapshot warning: %s", error)
            if not self.audio.available:
                self.statusBar().showMessage(f"Áudio do Windows indisponível: {error}", 6500)
            self._last_audio_error = error
        elif not error:
            self._last_audio_error = ""

        # Re-read targets after the background job completes; user may have changed a channel meanwhile.
        targets = [self._current_target(index) for index in range(8)]
        for index, strip in enumerate(self.channel_strips):
            target = targets[index]
            scalar = self._last_volumes.get(target) if target else None
            if scalar is None:
                if not strip.fader.isSliderDown():
                    fallback_label = "Brilho indisponível" if self.audio.is_brightness_target(target) else ("Sem sessão" if target else "—")
                    strip.set_fader_value(strip.fader.value(), fallback_label, 0)
            else:
                percent = round(scalar * 100)
                is_brightness = self.audio.is_brightness_target(target)
                label = f"{percent}% · BRILHO" if is_brightness else f"{percent}%  ·  {self._db_label(scalar)}"
                if not strip.fader.isSliderDown():
                    strip.set_fader_value(percent, label, percent)
                else:
                    live = strip.fader.value()
                    live_label = f"{live}% · BRILHO" if is_brightness else f"{live}%  ·  {self._db_label(live / 100.0)}"
                    strip.fader_value.setText(live_label)
                meter_db = self._last_levels_db.get(target)
                is_peak = bool(self._last_levels_are_peak.get(target, False))
                if meter_db is None:
                    meter_db = self.audio._peak_to_db(scalar)
                    is_peak = False
                if is_brightness:
                    strip.set_meter_percent(percent, "Brilho de tela")
                else:
                    strip.set_meter_db(meter_db, actual_peak=is_peak)
                if self.profile.get("knob_target_mode") == "app_gain":
                    strip.set_knob_value(percent, 0, 100, f"{percent}%")
        if self.profile.get("knob_target_mode") == "eq":
            self._update_knob_visuals()
        self._push_led_state(self._last_volumes, self._last_mutes)

    def _update_knob_visuals(self) -> None:
        mode = self.profile.get("knob_target_mode", "eq")
        strips = getattr(self, "channel_strips", [])
        volumes = self._last_volumes
        for index, strip in enumerate(strips):
            if mode == "eq":
                if index < int(self.profile.get("eq_mode", 8)):
                    gain = float(self.profile["eq_gains"][index])
                    freq = self._eq_frequency_label(index)
                    strip.set_knob_value(round(gain * 10), -120, 120, f"{gain:+.1f} dB\n{freq}")
                    strip.knob.setToolTip(f"Knob {index + 1} → EQ {freq}: {gain:+.1f} dB. Arraste para ajuste fino; duplo clique para Flat.")
                else:
                    strip.set_knob_value(0, -120, 120, "N/A")
                    strip.knob.setToolTip(f"Knob {index + 1}: sem banda no modo de {self.profile.get('eq_mode', 8)} bandas.")
            else:
                target = self._current_target(index)
                scalar = volumes.get(target) if target else None
                percent = round((scalar or 0.0) * 100)
                strip.set_knob_value(percent, 0, 100, f"{percent}%" if scalar is not None else "—")

    # ---------- MIDI learn, mapping, action execution and HUD ----------
    def _show_mapping_repair_warning(self) -> None:
        """Explain any duplicate legacy MIDI routes removed at startup."""
        warnings = list(getattr(self.store, "mapping_repair_warnings", []) or [])
        if not warnings:
            return
        details = "\n\n".join(warnings[:12])
        if len(warnings) > 12:
            details += f"\n\n… e mais {len(warnings) - 12} conflito(s)."
        if getattr(self.store, "mapping_repair_persisted", True):
            backup_note = "Uma cópia das configurações anteriores foi preservada em settings.json.bak."
        else:
            backup_note = (
                "A correção está ativa apenas nesta execução porque o arquivo de configurações não pôde ser salvo. "
                "Verifique a permissão de escrita e faça uma cópia manual de settings.json antes de fechar."
            )
        QMessageBox.warning(
            self,
            "Mapeamentos MIDI conflitantes corrigidos",
            "Foi detectado que um mesmo sinal MIDI estava associado a mais de um controle. "
            "Para impedir que um botão mova um fader ou acione funções inesperadas, "
            "as associações físicas conflitantes foram removidas. As ações e os destinos "
            "dos canais foram preservados. Faça novamente o aprendizado apenas dos controles listados.\n\n"
            + details + "\n\n" + backup_note,
        )
        self.store.mapping_repair_warnings.clear()

    def _start_learn(self, kind: str, index: int) -> None:
        self.learning_target = (kind, index)
        if kind in {"fader", "knob"}:
            self._analog_learn_sampler.reset()
            self._analog_learn_last_hint = 0.0
        self._learn_timer.start()
        label = {"fader": "fader", "knob": "encoder/knob"}.get(kind, "controle")
        if kind == "fader":
            hint = "Mova o fader continuamente; um clique de botão não será aceito."
        elif kind == "knob":
            hint = "Gire o knob em ambos os sentidos; um clique de botão não será aceito."
        else:
            hint = f"MIDI LEARN: mova o {label} físico {index + 1}…"
        self.statusBar().showMessage(f"MIDI LEARN · {label} {index + 1}: {hint}", 15000)
        self.hud.show_event(f"Mapear {label} {index + 1}", "AGUARDANDO", 0, "MIDI LEARN")
        if kind == "fader":
            self.channel_strips[index].set_mapping_text("fader", "AGUARDANDO…")
        elif kind == "knob":
            self.channel_strips[index].set_mapping_text("knob", "AGUARDANDO…")

    def _start_button_learn(self, control_id: str) -> None:
        if control_id not in BUTTON_SPEC_BY_ID:
            return
        self._select_simple_button_target(control_id, navigate=False)
        self.learning_target = ("button", control_id)
        self._learn_timer.start()
        spec = BUTTON_SPEC_BY_ID[control_id]
        self.statusBar().showMessage(f"Aprendizado MIDI: pressione UMA vez o botão físico para associar a {self._control_display_name(control_id)}…", 15000)
        self.hud.show_event(f"Mapear {self._control_display_name(control_id)}", "AGUARDANDO", 0, "MIDI LEARN")
        self._refresh_simple_button_mapping_status()
        if control_id in self.global_buttons:
            self.global_buttons[control_id].setText("…")
        if hasattr(self, "button_table"):
            match_index = next((i for i, item in enumerate(self._button_filtered_specs) if item.control_id == control_id), None)
            if match_index is None and hasattr(self, "button_search_edit") and self.button_search_edit.text():
                self.button_search_edit.clear()
                match_index = next((i for i, item in enumerate(self._button_filtered_specs) if item.control_id == control_id), None)
            if match_index is not None:
                self._button_page = match_index // self._button_page_size
                self._populate_button_table()
                row_index = match_index % self._button_page_size
                self.button_table.selectRow(row_index)
                cell = self.button_table.cellWidget(row_index, 5)
                if cell is not None:
                    cell.setText("Aguardando…")
                midi_label = self.button_table.cellWidget(row_index, 1)
                if midi_label is not None:
                    midi_label.setText("Pressione o botão físico…")
        self._navigate_to_buttons_tab()

    def _cancel_midi_learn_timeout(self) -> None:
        if self.learning_target is None:
            return
        target = self.learning_target
        self.learning_target = None
        self._analog_learn_sampler.reset()
        self._refresh_midi_mapping_labels()
        if hasattr(self, "button_table"):
            self._populate_button_table()
        self._refresh_simple_button_mapping_status()
        self.statusBar().showMessage("Aprendizado MIDI expirou após 15 segundos; nenhum mapeamento foi alterado.", 4500)
        logging.getLogger("smc_mixer_suite").info("MIDI Learn timed out: %r", target)

    def _find_mapping_conflicts(self, key: str, kind: str, ref: Any) -> list[tuple[str, str, Any]]:
        conflicts: list[tuple[str, str, Any]] = []
        profile = self.profile
        for index, mapped in enumerate(profile.get("fader_midi", [])):
            if mapped == key and not (kind == "fader" and int(ref) == index):
                conflicts.append(("fader", f"Fader {index + 1}", index))
        for index, mapped in enumerate(profile.get("knob_midi", [])):
            if mapped == key and not (kind == "knob" and int(ref) == index):
                conflicts.append(("knob", f"Knob {index + 1}", index))
        for control_id, row in profile.get("button_actions", {}).items():
            if row.get("midi") == key and not (kind == "button" and str(ref) == control_id):
                conflicts.append(("button", self._control_display_name(control_id), control_id))
        return conflicts

    def _resolve_mapping_conflicts(self, key: str, kind: str, ref: Any) -> bool:
        conflicts = self._find_mapping_conflicts(key, kind, ref)
        if not conflicts:
            return True
        names = "\n".join(f"• {name}" for _, name, _ in conflicts)
        answer = QMessageBox(self)
        answer.setIcon(QMessageBox.Icon.Warning)
        answer.setWindowTitle("Entrada MIDI já utilizada")
        answer.setText(f"{midi_key_label(key)} já está associado a outro(s) controle(s):\n\n{names}\n\nPara evitar que um sinal acione controles inesperados, escolha se deseja transferir esta entrada.")
        replace_button = answer.addButton("Substituir mapeamentos anteriores", QMessageBox.ButtonRole.AcceptRole)
        answer.addButton("Cancelar aprendizado", QMessageBox.ButtonRole.RejectRole)
        answer.exec()
        if answer.clickedButton() is not replace_button:
            self.statusBar().showMessage("Mapeamento cancelado; as associações existentes foram preservadas.", 3500)
            self._refresh_midi_mapping_labels()
            self._populate_button_table()
            return False
        for conflict_kind, _name, old_ref in conflicts:
            if conflict_kind == "fader":
                self.profile["fader_midi"][int(old_ref)] = None
            elif conflict_kind == "knob":
                self.profile["knob_midi"][int(old_ref)] = None
            else:
                self.profile["button_actions"][str(old_ref)]["midi"] = None
        return True

    def _effective_knob_mode(self, key: str, value: int, index: int) -> str | None:
        """Return a configured or inferred encoder protocol; never guess from one CC alone."""
        configured = normalize_knob_mode(self.profile.get("knob_mode", "auto"))
        if configured != "auto":
            if hasattr(self, "knob_input_status"):
                label = KNOB_MODES.get(configured, configured)
                self.knob_input_status.setText(f"Última entrada: Knob {index + 1} · {midi_key_label(key)} = {value} · {label}.")
            return configured

        detected = self._detected_knob_modes.get(key)
        if detected:
            if hasattr(self, "knob_input_status"):
                self.knob_input_status.setText(f"Knob {index + 1}: formato detectado — {KNOB_MODES[detected]} · última CC {value}.")
            return detected

        samples = self._knob_probe_samples.setdefault(key, [])
        samples.append(int(value))
        del samples[:-8]
        detected = infer_knob_mode(samples)
        if detected:
            self._detected_knob_modes[key] = detected
            self._knob_probe_samples.pop(key, None)
            text = KNOB_MODES[detected]
            self.statusBar().showMessage(f"Knob {index + 1}: formato detectado — {text}. Se precisar, escolha manualmente outro formato no EQ.", 5000)
            if hasattr(self, "knob_input_status"):
                self.knob_input_status.setText(f"Knob {index + 1}: formato detectado — {text} · última CC {value}.")
            return detected

        if hasattr(self, "knob_input_status"):
            self.knob_input_status.setText(
                f"Auto detecção: Knob {index + 1}, última CC {value}. Gire de forma contínua por 3–6 passos; "
                "se não responder, escolha manualmente Absoluto ou um dos formatos CW relativos."
            )
        return None

    def _flush_pending_analog_midi(self) -> None:
        pending = list(self._pending_analog_midi.values())
        self._pending_analog_midi.clear()
        self._processing_coalesced_midi = True
        try:
            for message in pending:
                self._on_midi_message(*message)
        finally:
            self._processing_coalesced_midi = False

    def _on_midi_message(self, msg_type: str, channel: int, number: int, value: int) -> None:
        key = midi_key(msg_type, channel, number)
        if msg_type == "cc" and not self._processing_coalesced_midi:
            self._fader_motion_guard.record(key, value)
        # Coalesce only a uniquely mapped analog CC route. Button events remain
        # immediate; conflicting/ambiguous routes are never coalesced or dispatched.
        if not self._processing_coalesced_midi and self.learning_target is None and msg_type == "cc":
            owners = midi_route_owners(self.profile, key)
            coalesce_this_event = len(owners) == 1 and owners[0][0] == "fader"
            if len(owners) == 1 and owners[0][0] == "knob":
                # Relative encoders encode each detent as a separate event; dropping
                # intermediate packets would make the knob feel slow or lose steps.
                configured_mode = normalize_knob_mode(self.profile.get("knob_mode", "auto"))
                effective_mode = self._detected_knob_modes.get(key, configured_mode)
                coalesce_this_event = effective_mode == "absolute"
            if coalesce_this_event:
                self._pending_analog_midi[key] = (msg_type, channel, number, value)
                if not self._analog_midi_timer.isActive():
                    self._analog_midi_timer.start()
                return
        event_line = f"{time.strftime('%H:%M:%S')}  {msg_type.upper():8} ch={channel + 1:02d} number={number:03d} value={value:03d}  {key}"
        self._midi_event_log.append(event_line)
        del self._midi_event_log[:-100]
        previous_value = self._midi_values.get(key, 0)
        self._midi_values[key] = int(value)

        if self.learning_target is not None:
            kind, ref = self.learning_target
            # Never learn a continuous analog route as a button. Otherwise moving a
            # mapped fader while the button wizard is armed can capture that CC and
            # make the physical selection button appear to move a fader.
            if kind == "button":
                analog_owners = analog_route_owners(self.profile, key)
                if analog_owners:
                    now = time.monotonic()
                    last_notice = self._learn_conflict_notice.get(key, 0.0)
                    if now - last_notice >= 1.0:
                        owner_text = ", ".join(owner[1] for owner in analog_owners)
                        self.statusBar().showMessage(
                            f"Mapeamento bloqueado: {midi_key_label(key)} já controla {owner_text}. "
                            "No MidiSuite da M-VAVE, mude esse botão físico de CC para Note, atribua uma nota exclusiva, salve no controlador e tente novamente. "
                            "Não transfira o CC do fader: uma mesma mensagem CC não distingue os dois controles.",
                            8000,
                        )
                        self._learn_conflict_notice[key] = now
                    return
            acceptable = False
            if kind in ("fader", "knob"):
                # Analog controls require a short motion signature; a single CC
                # edge from a button must never become a fader/knob mapping.
                if msg_type != "cc":
                    return
                acceptable, sample_count, learn_message = self._analog_learn_sampler.feed(kind, key, value)
                if not acceptable:
                    now = time.monotonic()
                    if now - self._analog_learn_last_hint >= 0.45:
                        self.statusBar().showMessage(learn_message, 1800)
                        self._analog_learn_last_hint = now
                    if kind == "fader":
                        self.channel_strips[int(ref)].set_mapping_text("fader", f"AMOSTRAS {sample_count}/4")
                    else:
                        self.channel_strips[int(ref)].set_mapping_text("knob", f"AMOSTRAS {sample_count}/4")
                    return
            elif kind == "button":
                trigger_mode = str(self.profile.get("button_actions", {}).get(str(ref), {}).get("trigger_mode", "note"))
                if trigger_mode == "cc_single_toggle":
                    acceptable = msg_type == "cc"
                elif trigger_mode == "cc_push":
                    acceptable = msg_type == "cc" and value > 0
                elif trigger_mode == "note":
                    acceptable = msg_type == "note_on" and value > 0
                    if msg_type == "cc":
                        now = time.monotonic()
                        if now - self._learn_conflict_notice.get("button-note-hint", 0.0) >= 1.0:
                            self.statusBar().showMessage(
                                "Sinal CC recebido. Para evitar que botões interfiram nos faders, configure este botão como Note no MidiSuite da M-VAVE; depois tente novamente.",
                                6500,
                            )
                            self._learn_conflict_notice["button-note-hint"] = now
                else:
                    acceptable = (msg_type == "cc" and value > 0) or (msg_type == "note_on" and value > 0)
            if acceptable:
                # Stop the learn session before any modal dialog; queued MIDI events cannot remap twice.
                self.learning_target = None
                self._learn_timer.stop()
                if not self._resolve_mapping_conflicts(key, kind, ref):
                    return
                if kind == "fader":
                    self.profile["fader_midi"][int(ref)] = key
                    assigned = f"Fader {int(ref) + 1}"
                elif kind == "knob":
                    self.profile["knob_midi"][int(ref)] = key
                    self._knob_probe_samples.pop(key, None)
                    self._detected_knob_modes.pop(key, None)
                    assigned = f"Knob {int(ref) + 1}"
                    if hasattr(self, "knob_input_status"):
                        self.knob_input_status.setText(f"Knob {int(ref) + 1} mapeado em {midi_key_label(key)}; gire-o para detectar o formato.")
                else:
                    self.profile["button_actions"][str(ref)]["midi"] = key
                    assigned = self._control_display_name(str(ref))
                if kind == "button":
                    # The press used for MIDI Learn is consumed intentionally. Reset
                    # the remembered level so a fixed-value CC on the next physical
                    # tap is not mistaken for the same already-seen value.
                    self._midi_values[key] = 0
                    self._button_press_gate.mark_consumed(key)
                self._analog_learn_sampler.reset()
                self._save_profile()
                self._refresh_midi_mapping_labels()
                self._populate_button_table()
                self._refresh_simple_button_mapping_status()
                learned_message = f"Controle aprendido: {assigned} ← {midi_key_label(key)}"
                if kind == "button":
                    learned_message += ". A pressão usada no aprendizado foi consumida; pressione novamente para executar a ação."
                self.statusBar().showMessage(learned_message, 5000)
                value_pct = round(value * 100 / 127) if msg_type == "cc" else 100
                self.hud.show_event(assigned, f"{value_pct}%" if kind == "fader" else "MAPEADO", value_pct, "MIDI LEARN")
                return
            # Critical safety rule: while MIDI Learn is active, never let another
            # message continue to normal runtime routing. This prevents learning a
            # button while another mapped fader/knob remains live.
            return

        # Last-line safety guard: an identical MIDI key cannot safely represent a
        # fader and a button simultaneously. Resolve this before touching any analog
        # widget; the old code handled analog routes first and could move a fader
        # before noticing the conflict further below.
        owners = midi_route_owners(self.profile, key)
        if len(owners) > 1:
            names = ", ".join(owner[1] for owner in owners)
            logging.getLogger("smc_mixer_suite").error("Ambiguous MIDI key %s routed to %s", key, names)
            now = time.monotonic()
            last_notice = self._learn_conflict_notice.get(f"runtime:{key}", 0.0)
            if now - last_notice >= 1.5:
                self.statusBar().showMessage(
                    f"Sinal MIDI ambíguo ({midi_key_label(key)}): {names}. Nenhuma ação foi executada. "
                    "Configure os botões da M-VAVE como Note e refaça os mapeamentos.",
                    6500,
                )
                self._learn_conflict_notice[f"runtime:{key}"] = now
            return

        consumed = False
        # Faders: duplicate samples are ignored; 1-step jitter is filtered for the audio API.
        if msg_type == "cc":
            for index, mapped in enumerate(self.profile["fader_midi"]):
                if not mapped or mapped != key:
                    continue
                consumed = True
                if not self._fader_motion_guard.allow_fader_value(key, value):
                    # Isolated 0/127 edges are typical of button CCs. Do not let
                    # a button impulse pull an analog fader to either extreme.
                    now = time.monotonic()
                    notice_key = f"endpoint:{key}"
                    if now - self._learn_conflict_notice.get(notice_key, 0.0) >= 1.5:
                        self.statusBar().showMessage(
                            f"Sinal CC de extremidade bloqueado em {midi_key_label(key)}: não houve movimento contínuo de fader. "
                            "Se era o fader físico, mova-o por uma faixa maior. Configure botões como Note no MidiSuite.",
                            5000,
                        )
                        self._learn_conflict_notice[notice_key] = now
                    continue
                pct = round(value * 100 / 127)
                strip = self.channel_strips[index]
                target = self._current_target(index)
                is_brightness = self.audio.is_brightness_target(target)
                label = f"{pct}% · BRILHO" if is_brightness else f"{pct}%  ·  {self._db_label(value / 127.0)}"
                strip.set_fader_value(pct, label, pct)
                if is_brightness:
                    strip.set_meter_percent(pct, "Brilho de tela")
                applied = self._last_fader_applied.get(key)
                hysteresis = int(self.profile.get("midi_hysteresis", 1))
                if target and (applied is None or abs(value - applied) > hysteresis or value in (0, 127)):
                    scalar = value / 127.0
                    self._queue_volume_write(target, scalar)
                    self._last_fader_applied[key] = value
                self.hud.show_event(f"{self._current_channel_name(index)} · Fader {index + 1}", f"{pct}%", pct, "BRILHO" if is_brightness else "VOLUME")

            for index, mapped in enumerate(self.profile["knob_midi"]):
                if not mapped or mapped != key:
                    continue
                consumed = True
                mode = self.profile.get("knob_target_mode", "eq")
                if mode == "eq":
                    if index >= int(self.profile.get("eq_mode", 8)):
                        continue
                    knob_mode = self._effective_knob_mode(key, value, index)
                    if knob_mode is None:
                        continue
                    if knob_mode == "absolute":
                        gain = absolute_cc_to_gain(value, invert=bool(self.profile.get("knob_invert", False)))
                    else:
                        delta = decode_relative_delta(value, knob_mode)
                        if self.profile.get("knob_invert", False):
                            delta = -delta
                        if delta == 0:
                            continue
                        gain = apply_relative_gain_step(
                            float(self.profile["eq_gains"][index]), delta,
                            float(self.profile["knob_step_db"]),
                        )
                    # Keep the neutral state canonical: -0.0 and tiny floating-point
                    # residues must never be persisted or rendered as +/-0.1 dB.
                    self.profile["eq_gains"][index] = 0.0 if round(gain, 1) == 0 else max(-12.0, min(12.0, round(gain, 1)))
                    self._store_active_eq_mode_gains()
                    self._mark_eq_curve_custom()
                    self._sync_eq_knob(index)
                    self._schedule_eq_write()
                    self._queue_profile_save()
                    self._update_knob_visuals()
                    display = f"{self.profile['eq_gains'][index]:+.1f} dB"
                    bar = round((self.profile["eq_gains"][index] + 12) / 24 * 100)
                    freq_label = self._eq_frequency_label(index)
                    self.hud.show_event(f"Knob {index + 1} · EQ {freq_label}", display, bar, "EQUALIZER")
                else:
                    target = self._current_target(index)
                    knob_mode = self._effective_knob_mode(key, value, index)
                    if knob_mode is None:
                        continue
                    if knob_mode == "absolute":
                        knob_value = 127 - value if self.profile.get("knob_invert", False) else value
                        new_scalar = knob_value / 127.0
                    else:
                        delta = decode_relative_delta(value, knob_mode)
                        if self.profile.get("knob_invert", False):
                            delta = -delta
                        if delta == 0:
                            continue
                        current = self._last_volumes.get(target) if target else None
                        if current is None:
                            # Never make a synchronous COM query from the MIDI callback.
                            # Refresh asynchronously and ignore this encoder step until a
                            # valid audio snapshot is available.
                            self._refresh_audio_ui()
                            continue
                        new_scalar = max(0.0, min(1.0, current + delta / 127.0))
                    if target:
                        self._queue_volume_write(target, new_scalar)
                    pct = round(new_scalar * 100)
                    self.channel_strips[index].set_knob_value(pct, 0, 100, f"{pct}%")
                    self.hud.show_event(f"Knob {index + 1} · {self._current_channel_name(index)}", f"{pct}%", pct, "GANHO DO APP")

        # Normalize button activations from Note On and multiple CC button protocols.
        # In particular, do not drop a repeated fixed-value CC merely because the
        # preceding tap also sent 127; suppress switch-bounce with a short debounce.
        analog_keys = {mapped for mapped in (self.profile["fader_midi"] + self.profile["knob_midi"]) if mapped}
        mapped_button_rows = [
            (control_id, action_row)
            for control_id, action_row in self.profile["button_actions"].items()
            if action_row.get("midi") == key
        ]
        if mapped_button_rows:
            consumed = True
            conflicting_analog = analog_route_owners(self.profile, key)
            if conflicting_analog:
                # A runtime guard for hand-edited settings or a profile modified by
                # an older build. Do not trigger the button action in parallel with
                # the analog route; startup repair normally removes this condition.
                owners_text = ", ".join(owner[1] for owner in conflicting_analog)
                logging.getLogger("smc_mixer_suite").error(
                    "Ignoring conflicting button route %s; also mapped to %s", key, owners_text
                )
                self.statusBar().showMessage(
                    f"Conflito MIDI: {midi_key_label(key)} também está em {owners_text}. "
                    "Remapeie esses controles.", 5000
                )
                mapped_button_rows = []
            for control_id, action_row in mapped_button_rows:
                trigger_mode = str(action_row.get("trigger_mode", "note"))
                is_button_press = self._button_press_gate.should_activate(
                    key, msg_type, value, previous_value, analog_keys, trigger_mode=trigger_mode
                )
                if not is_button_press:
                    continue
                ok, message = self._execute_control_action(control_id)
                self.statusBar().showMessage(("✓ " if ok else "⚠ ") + message, 3500)
                self.hud.show_event(self._control_display_name(control_id), "ACIONADO", 100, "BOTÃO")

        if not consumed and msg_type in ("cc", "note_on") and self.learning_target is None:
            # Raw/unmapped MIDI is diagnostic input, not an activated function.
            # Keep it out of the floating OSD so stray controller messages do not
            # repeatedly interrupt the desktop while discovering controls.
            if msg_type == "cc" and (previous_value == 0 or abs(value - previous_value) >= 4):
                logging.getLogger("smc_mixer_suite").debug("Unmapped MIDI input: %s value=%s", key, value)
            elif msg_type == "note_on" and value > 0:
                logging.getLogger("smc_mixer_suite").debug("Unmapped MIDI note: %s value=%s", key, value)

    def _control_display_name(self, control_id: str) -> str:
        spec = BUTTON_SPEC_BY_ID.get(control_id)
        if spec is None:
            return control_id
        if spec.channel is not None:
            return f"{self._current_channel_name(spec.channel)} · {spec.key}"
        return spec.key or spec.label

    def _on_virtual_button_pressed(self, control_id: str) -> None:
        """A left-click on the on-screen hardware button executes its action.

        MIDI Learn remains available from the button table or the right-click
        context menu. This avoids the confusing old behavior where clicking the
        visible Mute button only entered MIDI Learn instead of muting the channel.
        """
        ok, message = self._execute_control_action(control_id)
        self.statusBar().showMessage(("✓ " if ok else "⚠ ") + message, 3500)
        self.hud.show_event(
            self._control_display_name(control_id),
            "EXECUTADO" if ok else "VERIFICAR",
            100 if ok else 0,
            "CONTROLE VIRTUAL",
        )

    def _execute_control_action(self, control_id: str) -> tuple[bool, str]:
        spec = BUTTON_SPEC_BY_ID.get(control_id)
        if spec is None:
            return False, f"Controle desconhecido: {control_id}"
        row = self.profile["button_actions"].get(control_id, {})
        action = str(row.get("action", "none"))
        argument = str(row.get("argument", ""))
        channel = spec.channel

        if action == "channel_mute":
            if channel is None:
                return False, "A ação Mute deste canal só pode ser usada em um botão de canal."
            target = self._current_target(channel)
            if not target:
                return False, f"{self._current_channel_name(channel)} não tem um aplicativo atribuído."
            ok = self.audio.toggle_mute(target)
            return ok, f"Mute alternado: {self._current_channel_name(channel)}" if ok else "Não foi possível alternar o mute deste canal."
        if action == "channel_solo":
            if channel is None:
                return False, "A ação Solo só pode ser usada em um botão de canal."
            return self._toggle_solo(channel)
        if action == "channel_select":
            if channel is None:
                return False, "A seleção de canal só se aplica aos botões de canal."
            self._selected_channel = channel
            for index, strip in enumerate(self.channel_strips):
                strip.set_selected(index == channel)
            return True, f"Canal selecionado: {self._current_channel_name(channel)}"
        if action == "bank_prev":
            self._navigate_bank(-1)
            return True, f"Banco anterior: {self.profile['active_bank'] + 1}"
        if action == "bank_next":
            self._navigate_bank(1)
            return True, f"Próximo banco: {self.profile['active_bank'] + 1}"
        if action == "shift_toggle":
            mode = "app_gain" if self.profile.get("knob_target_mode", "eq") == "eq" else "eq"
            self.profile["knob_target_mode"] = mode
            self.knob_target_combo.blockSignals(True)
            self.knob_target_combo.setCurrentIndex(0 if mode == "eq" else 1)
            self.knob_target_combo.blockSignals(False)
            self._save_profile()
            self._update_knob_visuals()
            return True, f"Modo dos knobs: {'EQ global' if mode == 'eq' else 'ganho de aplicativo'}"

        if action == "macro":
            try:
                macro_index = int(argument.strip()) - 1
            except (TypeError, ValueError):
                return False, "Informe o número da macro, de 1 a 8."
            return self._run_macro(macro_index)
        if action == "macro_sequence":
            return self._run_macro_sequence(argument, self._control_display_name(control_id))

        return execute_action(action, argument, self.audio)

    def _restore_solo_snapshot(self) -> None:
        if self._solo_snapshot is not None:
            # Batch restore avoids enumerating all Windows sessions once per channel.
            self.audio.set_mutes(self._solo_snapshot)
        self._solo_snapshot = None
        self._solo_channel = None

    def _toggle_solo(self, channel: int) -> tuple[bool, str]:
        target = self._current_target(channel)
        if not target:
            return False, f"{self._current_channel_name(channel)} não tem um aplicativo atribuído."
        if target == "__master__":
            return False, "Solo de canal exige um aplicativo individual; escolha um processo no seletor do canal."
        # Repeating the active Solo restores the original state exactly.
        if self._solo_snapshot is not None and self._solo_channel == channel:
            self.audio.set_mutes(self._solo_snapshot)
            self._solo_snapshot = None
            self._solo_channel = None
            self._push_led_state(self._last_volumes, self._last_mutes)
            return True, "Solo desativado; estados de mute anteriores restaurados."

        # Switching directly from one Solo to another must restore the ORIGINAL
        # mute state first. Capturing the currently forced-muted state here would
        # make the next Solo restore the previous Solo instead of the user's state.
        if self._solo_snapshot is not None:
            self.audio.set_mutes(self._solo_snapshot)
            self._solo_snapshot = None
            self._solo_channel = None

        targets = sorted({
            self._current_target(i) for i in range(8)
            if self._current_target(i) and self._current_target(i) != "__master__"
        })
        current_mutes = self.audio.get_mutes(targets)
        snapshot = {
            name: state for name, state in current_mutes.items()
            if state is not None
        }
        desired: dict[str, bool] = {}
        for app_target in targets:
            desired[app_target] = app_target.casefold() != target.casefold()
        outcomes = self.audio.set_mutes(desired)
        if not outcomes.get(target, False):
            # Do not retain a Solo state if the selected app no longer has a session.
            self.audio.set_mutes(snapshot)
            self._push_led_state(self._last_volumes, self._last_mutes)
            return False, f"Não foi possível ativar Solo para {self._current_channel_name(channel)}; confira se o aplicativo ainda tem áudio ativo."
        self._solo_snapshot = snapshot
        self._solo_channel = channel
        self._push_led_state(self._last_volumes, self._last_mutes)
        return True, f"Solo ativo: {self._current_channel_name(channel)}"

    def _refresh_midi_mapping_labels(self) -> None:
        profile = self.profile
        for index, strip in enumerate(getattr(self, "channel_strips", [])):
            fader_key = profile["fader_midi"][index]
            knob_key = profile["knob_midi"][index]
            strip.set_mapping_text("fader", "MAPEAR FADER" if not fader_key else f"✓ {midi_key_label(fader_key)}")
            strip.set_mapping_text("knob", "MAPEAR KNOB" if not knob_key else f"✓ {midi_key_label(knob_key)}")
            for suffix in ("mute", "solo", "rec", "select"):
                strip.set_button_mapped(suffix, bool(profile["button_actions"].get(f"ch{index + 1}_{suffix}", {}).get("midi")))
        for index, widgets in enumerate(getattr(self, "eq_controls", [])):
            widgets["mapping"].setText(midi_key_label(profile["knob_midi"][index]))
        if hasattr(self, "button_table"):
            for row_index, spec in enumerate(getattr(self, "_button_page_specs", [])):
                midi_cell = self.button_table.cellWidget(row_index, 1)
                if midi_cell:
                    midi_cell.setText(midi_key_label(profile["button_actions"][spec.control_id].get("midi")))
        for spec in BUTTON_SPECS:
            if spec.control_id in self.global_buttons:
                button = self.global_buttons[spec.control_id]
                button.setText(self._global_button_caption(spec.control_id))
                button.setIcon(self._global_button_icon(spec.control_id))
        self._refresh_simple_button_mapping_status()

    def _populate_button_table(self) -> None:
        if not hasattr(self, "button_table"):
            return
        was_loading = self._loading
        filtered = getattr(self, "_button_filtered_specs", list(BUTTON_SPECS))
        page_size = max(1, int(getattr(self, "_button_page_size", 8)))
        max_page = max(0, (len(filtered) - 1) // page_size)
        self._button_page = max(0, min(max_page, int(getattr(self, "_button_page", 0))))
        start_index = self._button_page * page_size
        self._button_page_specs = list(filtered[start_index:start_index + page_size])
        self.button_table.setRowCount(len(self._button_page_specs))
        for row_index, spec in enumerate(self._button_page_specs):
            row = self.profile["button_actions"].setdefault(spec.control_id, {"midi": None, "action": spec.default_action, "argument": spec.default_argument})
            name_item = QTableWidgetItem(self._control_display_name(spec.control_id))
            name_item.setToolTip(spec.help_text)
            name_item.setData(Qt.ItemDataRole.UserRole, spec.control_id)
            self.button_table.setItem(row_index, 0, name_item)
            midi_label = QLabel(midi_key_label(row.get("midi"))); midi_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.button_table.setCellWidget(row_index, 1, midi_label)
            action_combo = QComboBox()
            for label, key in ACTION_CHOICES:
                action_combo.addItem(label, key)
            action_index = action_combo.findData(row.get("action", spec.default_action))
            action_combo.setCurrentIndex(action_index if action_index >= 0 else 0)
            action_combo.currentIndexChanged.connect(lambda _idx, cid=spec.control_id, combo=action_combo: self._on_button_field(cid, "action", combo.currentData()))
            self.button_table.setCellWidget(row_index, 2, action_combo)
            argument_edit = QLineEdit(str(row.get("argument", "")))
            argument_edit.setPlaceholderText(ACTION_HINTS.get(str(row.get("action", "none")), "Argumento opcional"))
            argument_edit.textChanged.connect(lambda text, cid=spec.control_id: self._on_button_field(cid, "argument", text))
            self.button_table.setCellWidget(row_index, 3, argument_edit)
            capture_btn = QPushButton("Capturar…")
            capture_btn.setToolTip("Captura uma combinação real de teclas do teclado do computador e grava no campo Argumento.")
            capture_btn.clicked.connect(lambda _checked=False, cid=spec.control_id, edit=argument_edit, combo=action_combo: self._capture_button_shortcut(cid, edit, combo))
            self.button_table.setCellWidget(row_index, 4, capture_btn)
            map_btn = QPushButton("Mapear" if not row.get("midi") else "Remapear")
            map_btn.clicked.connect(lambda _checked=False, cid=spec.control_id: self._start_button_learn(cid))
            self.button_table.setCellWidget(row_index, 5, map_btn)
            self.button_table.setRowHeight(row_index, 32)
        if hasattr(self, "button_page_label"):
            pages = max(1, (len(filtered) + page_size - 1) // page_size)
            self.button_page_label.setText(f"Página {self._button_page + 1}/{pages} · {len(self._button_page_specs)} controles nesta página")
            self.button_prev_page_btn.setEnabled(self._button_page > 0)
            self.button_next_page_btn.setEnabled(self._button_page < pages - 1)
        if hasattr(self, "button_search_count"):
            self.button_search_count.setText(f"{len(filtered)} de {len(BUTTON_SPECS)} controles")
        self._loading = was_loading
        self._refresh_midi_mapping_labels()

    def _capture_button_shortcut(self, control_id: str, argument_edit: QLineEdit, action_combo: QComboBox) -> None:
        dialog = ShortcutCaptureDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted or not dialog.shortcut:
            return
        action_index = action_combo.findData("shortcut")
        if action_index >= 0:
            action_combo.setCurrentIndex(action_index)
        argument_edit.setText(dialog.shortcut)
        self._on_button_field(control_id, "action", "shortcut")
        self._on_button_field(control_id, "argument", dialog.shortcut)
        self.statusBar().showMessage(f"Atalho capturado para {self._control_display_name(control_id)}: {dialog.shortcut}", 4000)
        self.hud.show_event(self._control_display_name(control_id), dialog.shortcut.upper(), 100, "ATALHO CAPTURADO")

    def _on_button_field(self, control_id: str, field: str, value: Any) -> None:
        if self._loading:
            return
        self.profile["button_actions"][control_id][field] = value
        if field == "action":
            # Make the argument placeholder match the action without overwriting user's text.
            for row_index, spec in enumerate(getattr(self, "_button_page_specs", [])):
                if spec.control_id == control_id:
                    edit = self.button_table.cellWidget(row_index, 3)
                    if edit is not None:
                        edit.setPlaceholderText(ACTION_HINTS.get(str(value), "Argumento opcional"))
                    break
        self._save_profile()

    def _show_button_context_menu(self, control_id: str, global_pos: QPoint) -> None:
        menu = QMenu(self)
        configure = menu.addAction("Configurar ação deste botão…")
        learn = menu.addAction("Aprender botão físico…")
        unmap = menu.addAction("Remover associação física")
        chosen = menu.exec(global_pos)
        if chosen == configure:
            self._select_simple_button_target(control_id, navigate=True)
        elif chosen == learn:
            self._start_button_learn(control_id)
        elif chosen == unmap:
            row = self.profile.setdefault("button_actions", {}).setdefault(control_id, {"midi": None, "action": "none", "argument": ""})
            row["midi"] = None
            self._save_profile()
            self._populate_button_table()
            self._refresh_midi_mapping_labels()
            self._refresh_simple_button_mapping_status()

    def _unmap_selected_button(self) -> None:
        row_index = self.button_table.currentRow()
        spec = self._button_spec_for_row(row_index)
        if spec is None:
            return
        control_id = spec.control_id
        self.profile["button_actions"][control_id]["midi"] = None
        self._save_profile()
        self._populate_button_table()
        self.statusBar().showMessage(f"Entrada MIDI removida de {self._control_display_name(control_id)}", 3000)

    def _reset_button_actions(self) -> None:
        if QMessageBox.question(self, "Restaurar ações padrão", "Restaurar ações padrão para os 43 botões? Os números MIDI aprendidos serão removidos.") != QMessageBox.StandardButton.Yes:
            return
        from smc_suite.hardware import default_button_actions
        self.profile["button_actions"] = default_button_actions()
        self._save_profile()
        self._populate_button_table()
        self._refresh_midi_mapping_labels()

    # ---------- Equalizer controls ----------
    def _store_active_eq_mode_gains(self) -> None:
        mode = self._active_eq_mode()
        count = int(mode)
        gains = [clamp_gain(value) for value in self.profile.get("eq_gains", [])[:count]]
        gains += [0.0] * (count - len(gains))
        self.profile.setdefault("eq_gains_by_mode", {})[mode] = gains

    def _mark_eq_curve_custom(self) -> None:
        """Keep the preset selector honest without doing extra UI work per MIDI tick."""
        already_custom = self.profile.get("eq_selected_preset") == "__current__"
        self.profile["eq_selected_preset"] = "__current__"
        if not hasattr(self, "eq_preset_combo"):
            return
        idx = self.eq_preset_combo.findData("__current__")
        if idx < 0:
            self.eq_preset_combo.addItem("Personalizado (curva atual)", "__current__")
            idx = self.eq_preset_combo.findData("__current__")
        if already_custom and self.eq_preset_combo.currentData() == "__current__":
            return
        self.eq_preset_combo.blockSignals(True)
        self.eq_preset_combo.setCurrentIndex(idx)
        self.eq_preset_combo.blockSignals(False)
        self._on_eq_preset_selection_changed(idx)

    def _active_eq_mode(self) -> str:
        return normalize_mode(self.profile.get("eq_mode", 8))

    def _eq_frequencies(self, mode: str | None = None) -> list[float]:
        mode = normalize_mode(mode if mode is not None else self.profile.get("eq_mode", 8))
        return sanitize_frequencies(self.profile.get("eq_custom_frequencies", {}).get(mode, DEFAULT_FREQUENCIES[mode]), mode)

    def _eq_frequency_label(self, index: int) -> str:
        freqs = self._eq_frequencies()
        return frequency_label(freqs[index]) if 0 <= index < len(freqs) else "desativada"

    def _load_eq_cutoff_values(self) -> None:
        if not hasattr(self, "eq_low_cut_enabled"):
            return
        for widget, value in (
            (self.eq_low_cut_enabled, bool(self.profile.get("eq_low_cut_enabled", False))),
            (self.eq_low_cut_spin, int(round(float(self.profile.get("eq_low_cut_hz", 40.0))))),
            (self.eq_high_cut_enabled, bool(self.profile.get("eq_high_cut_enabled", False))),
            (self.eq_high_cut_spin, int(round(float(self.profile.get("eq_high_cut_hz", 18000.0))))),
        ):
            widget.blockSignals(True)
            widget.setChecked(value) if isinstance(widget, QCheckBox) else widget.setValue(value)
            widget.blockSignals(False)
        self.eq_low_cut_spin.setEnabled(self.eq_low_cut_enabled.isChecked())
        self.eq_high_cut_spin.setEnabled(self.eq_high_cut_enabled.isChecked())

    def _on_eq_cutoff_changed(self, *_args) -> None:
        if self._loading:
            return
        self.profile["eq_low_cut_enabled"] = bool(self.eq_low_cut_enabled.isChecked())
        self.profile["eq_low_cut_hz"] = max(20.0, min(200.0, float(self.eq_low_cut_spin.value())))
        self.profile["eq_high_cut_enabled"] = bool(self.eq_high_cut_enabled.isChecked())
        self.profile["eq_high_cut_hz"] = max(5000.0, min(20000.0, float(self.eq_high_cut_spin.value())))
        self.eq_low_cut_spin.setEnabled(self.profile["eq_low_cut_enabled"])
        self.eq_high_cut_spin.setEnabled(self.profile["eq_high_cut_enabled"])
        self._mark_eq_curve_custom()
        self._queue_profile_save()
        self._schedule_eq_write()
        self.statusBar().showMessage("Cortes Low/High atualizados; o arquivo APO será regenerado.", 2200)

    def _on_eq_mode_changed(self, _index: int) -> None:
        if self._loading:
            return
        new_mode = str(self.eq_band_mode_combo.currentData() or 8)
        old_mode = str(self.profile.get("eq_mode", 8))
        if new_mode == old_mode:
            return
        self._store_active_eq_mode_gains()
        self.profile["eq_mode"] = int(new_mode)
        saved = self.profile.setdefault("eq_gains_by_mode", {}).get(new_mode, [0.0] * int(new_mode))
        new_gains = [clamp_gain(value) for value in list(saved)[:int(new_mode)]]
        new_gains += [0.0] * (int(new_mode) - len(new_gains))
        self.profile["eq_gains"] = [0.0] * 8
        self.profile["eq_gains"][:len(new_gains)] = new_gains
        self._rebuild_eq_band_controls()
        self._load_eq_band_values()
        self._save_profile()
        self._update_knob_visuals()
        self._schedule_eq_write()
        self.statusBar().showMessage(f"Modo de {new_mode} bandas ativo; os ganhos desse modo foram restaurados.", 4000)

    def _load_eq_band_values(self) -> None:
        freqs = self._eq_frequencies()
        for index, widgets in enumerate(self.eq_controls):
            gain = float(self.profile["eq_gains"][index])
            for widget, value in ((widgets["knob"], round(gain * 10)), (widgets["gain"], gain), (widgets["freq"], freqs[index])):
                widget.blockSignals(True)
                widget.setValue(value)
                widget.blockSignals(False)
            widgets["freq"].setEnabled(not self.profile.get("eq_fixed_frequencies", True))
            widgets["mapping"].setText(midi_key_label(self.profile["knob_midi"][index]))
        self._refresh_eq_preset_combo()

    def _on_eq_knob_value(self, index: int, value: int) -> None:
        if self._loading or index >= int(self.profile.get("eq_mode", 8)):
            return
        gain = clamp_gain(value / 10.0)
        self.profile["eq_gains"][index] = gain
        self._store_active_eq_mode_gains()
        self._mark_eq_curve_custom()
        widgets = self.eq_controls[index]
        widgets["gain"].blockSignals(True)
        widgets["gain"].setValue(gain)
        widgets["gain"].blockSignals(False)
        self._update_knob_visuals()
        self._queue_profile_save()
        self._schedule_eq_write()

    def _on_eq_gain_spin(self, index: int, value: float) -> None:
        if self._loading or index >= int(self.profile.get("eq_mode", 8)):
            return
        gain = clamp_gain(value)
        self.profile["eq_gains"][index] = gain
        self._store_active_eq_mode_gains()
        self._mark_eq_curve_custom()
        widgets = self.eq_controls[index]
        widgets["knob"].blockSignals(True)
        widgets["knob"].setValue(round(gain * 10))
        widgets["knob"].blockSignals(False)
        widgets["gain"].blockSignals(True)
        widgets["gain"].setValue(gain)
        widgets["gain"].blockSignals(False)
        self._update_knob_visuals()
        self._queue_profile_save()
        self._schedule_eq_write()

    def _reset_eq_band(self, index: int) -> None:
        if not (0 <= index < min(len(self.eq_controls), int(self.profile.get("eq_mode", 8)))):
            return
        # Update the model explicitly so reset also works when the spinbox is already
        # at 0.0 dB or when the event originated from the visual hardware knob.
        self.profile["eq_gains"][index] = 0.0
        self._store_active_eq_mode_gains()
        self._sync_eq_knob(index)
        self._mark_eq_curve_custom()
        self._update_knob_visuals()
        self._save_profile()
        self._eq_save_timer.stop()
        self._write_eq_file()
        self.hud.show_event(f"EQ · {self._eq_frequency_label(index)}", "0.0 dB · FLAT", 50, "RESET DE BANDA")

    def _restore_eq_flat(self) -> None:
        """Restore a truly neutral EQ in every band mode, preserving user presets."""
        for mode_key, frequencies in DEFAULT_FREQUENCIES.items():
            self.profile.setdefault("eq_gains_by_mode", {})[mode_key] = [0.0] * len(frequencies)
        self.profile["eq_gains"] = [0.0] * 8
        self.profile["eq_bypass"] = False
        self.profile["eq_low_cut_enabled"] = False
        self.profile["eq_high_cut_enabled"] = False
        self.profile["eq_selected_preset"] = "Flat / Neutro"
        self.eq_bypass_btn.blockSignals(True)
        self.eq_bypass_btn.setChecked(False)
        self.eq_bypass_btn.setText("BYPASS OFF")
        self.eq_bypass_btn.blockSignals(False)
        self._load_eq_cutoff_values()
        self._load_eq_band_values()
        self._update_knob_visuals()
        self._refresh_eq_preset_combo()
        self._save_profile()
        self._eq_save_timer.stop()
        written = self._write_eq_file()
        linked_now = "EQ VINCULADO" in self.eq_file_status.text()
        self.statusBar().showMessage(
            "EQ Flat salvo: ganhos zerados nos modos de 3/5/8 bandas; Low/High Cut desligados. "
            + ("Filtros atualizados no APO." if written and linked_now else "Para afetar o áudio do Windows, clique em 'Vincular ao APO'."),
            7000,
        )
        self.hud.show_event("Equalizador global", "FLAT · 0.0 dB", 50, "EQ RESTAURADO")

    def _sync_eq_knob(self, index: int) -> None:
        if not 0 <= index < len(getattr(self, "eq_controls", [])):
            return
        widgets = self.eq_controls[index]
        gain = clamp_gain(float(self.profile["eq_gains"][index]))
        widgets["knob"].blockSignals(True)
        widgets["knob"].setValue(round(gain * 10))
        widgets["knob"].blockSignals(False)
        widgets["gain"].blockSignals(True)
        widgets["gain"].setValue(gain)
        widgets["gain"].blockSignals(False)

    def _on_eq_fixed_frequency_toggled(self, checked: bool) -> None:
        if self._loading:
            return
        self.profile["eq_fixed_frequencies"] = bool(checked)
        for widgets in self.eq_controls:
            widgets["freq"].setEnabled(not checked)
        self._save_profile()

    def _on_eq_frequency_changed(self, index: int, value: float) -> None:
        if self._loading or self.profile.get("eq_fixed_frequencies", True):
            return
        mode = self._active_eq_mode()
        frequencies = self._eq_frequencies(mode)
        if index >= len(frequencies):
            return
        candidate = max(20.0, min(20000.0, float(value)))
        lower_bound = frequencies[index - 1] + 1.0 if index > 0 else 20.0
        upper_bound = frequencies[index + 1] - 1.0 if index < len(frequencies) - 1 else 20000.0
        if candidate < lower_bound or candidate > upper_bound:
            self.statusBar().showMessage("Mantenha as frequências em ordem crescente, da esquerda para a direita.", 3500)
            widgets = self.eq_controls[index]
            widgets["freq"].blockSignals(True)
            widgets["freq"].setValue(frequencies[index])
            widgets["freq"].blockSignals(False)
            return
        frequencies[index] = candidate
        self.profile["eq_custom_frequencies"][mode] = frequencies
        self.band_freqs = [frequency_label(f) for f in frequencies]
        self._mark_eq_curve_custom()
        self._queue_profile_save()
        self._schedule_eq_write()
        self.statusBar().showMessage(f"Frequência da banda {index + 1}: {frequency_label(value)}", 2200)

    def _restore_suggested_frequencies(self) -> None:
        mode = self._active_eq_mode()
        self.profile["eq_custom_frequencies"][mode] = DEFAULT_FREQUENCIES[mode].copy()
        self.profile["eq_fixed_frequencies"] = True
        self.eq_fixed_freq_checkbox.blockSignals(True)
        self.eq_fixed_freq_checkbox.setChecked(True)
        self.eq_fixed_freq_checkbox.blockSignals(False)
        self._rebuild_eq_band_controls()
        self._load_eq_band_values()
        self._queue_profile_save()
        self._schedule_eq_write()
        self.statusBar().showMessage("Frequências recomendadas restauradas.", 3000)

    def _on_eq_preset_selection_changed(self, _index: int) -> None:
        name = self.eq_preset_combo.currentData() if hasattr(self, "eq_preset_combo") else None
        is_user = bool(name and name in self.profile.get("eq_user_presets", {}))
        if hasattr(self, "eq_update_preset_btn"):
            self.eq_update_preset_btn.setEnabled(is_user)
        if hasattr(self, "eq_delete_preset_btn"):
            self.eq_delete_preset_btn.setEnabled(is_user)

    def _apply_selected_eq_preset(self) -> None:
        name = self.eq_preset_combo.currentData()
        if not name or name == "__current__":
            return
        user_entry = self.profile.get("eq_user_presets", {}).get(name) if name not in FACTORY_PRESETS else None
        if user_entry and isinstance(user_entry.get("gains_by_mode"), dict) and all(
            mode in user_entry["gains_by_mode"] and len(user_entry["gains_by_mode"][mode]) == len(DEFAULT_FREQUENCIES[mode])
            for mode in DEFAULT_FREQUENCIES
        ):
            # Version-2 user presets restore the exact mode/frequency/gain configuration.
            saved_frequencies = user_entry.get("frequencies_by_mode", {})
            for mode_key in DEFAULT_FREQUENCIES:
                self.profile["eq_custom_frequencies"][mode_key] = sanitize_frequencies(
                    saved_frequencies.get(mode_key, DEFAULT_FREQUENCIES[mode_key]), mode_key
                )
            self.profile["eq_gains_by_mode"] = {
                mode_key: [clamp_gain(v) for v in user_entry["gains_by_mode"][mode_key]]
                for mode_key in DEFAULT_FREQUENCIES
            }
            self.profile["eq_mode"] = int(normalize_mode(user_entry.get("mode", 8)))
            self.profile["eq_fixed_frequencies"] = bool(user_entry.get("eq_fixed_frequencies", True))
            self.profile["eq_bypass"] = bool(user_entry.get("eq_bypass", False))
            self.profile["eq_low_cut_enabled"] = bool(user_entry.get("eq_low_cut_enabled", False))
            self.profile["eq_low_cut_hz"] = max(20.0, min(200.0, float(user_entry.get("eq_low_cut_hz", 40.0))))
            self.profile["eq_high_cut_enabled"] = bool(user_entry.get("eq_high_cut_enabled", False))
            self.profile["eq_high_cut_hz"] = max(5000.0, min(20000.0, float(user_entry.get("eq_high_cut_hz", 18000.0))))
            self._load_eq_cutoff_values()
            self.eq_band_mode_combo.blockSignals(True)
            self.eq_band_mode_combo.setCurrentIndex({3: 0, 5: 1, 8: 2}.get(int(self.profile["eq_mode"]), 2))
            self.eq_band_mode_combo.blockSignals(False)
            self.eq_fixed_freq_checkbox.blockSignals(True)
            self.eq_fixed_freq_checkbox.setChecked(self.profile["eq_fixed_frequencies"])
            self.eq_fixed_freq_checkbox.blockSignals(False)
            self.eq_bypass_btn.blockSignals(True)
            self.eq_bypass_btn.setChecked(self.profile["eq_bypass"])
            self.eq_bypass_btn.setText("BYPASS ON" if self.profile["eq_bypass"] else "BYPASS OFF")
            self.eq_bypass_btn.blockSignals(False)
            self._rebuild_eq_band_controls()
            self._load_eq_band_values()
        else:
            # Factory presets and legacy user presets are frequency-interpolated.
            if name in FACTORY_PRESETS:
                anchors = FACTORY_PRESETS[name]
            else:
                entry = user_entry or {}
                anchors = entry.get("gains", [0.0] * 8)
            mode_gains: dict[str, list[float]] = {}
            for mode_key in DEFAULT_FREQUENCIES:
                mode_frequencies = self._eq_frequencies(mode_key)
                mode_gains[mode_key] = preset_gains_for_frequencies(anchors, mode_frequencies)
            self.profile["eq_gains_by_mode"] = mode_gains
        active_mode = self._active_eq_mode()
        active_gains = self.profile["eq_gains_by_mode"][active_mode]
        self.profile["eq_gains"] = [0.0] * 8
        self.profile["eq_gains"][:len(active_gains)] = active_gains
        self.profile["eq_selected_preset"] = name
        self._load_eq_band_values()
        self._update_knob_visuals()
        self._queue_profile_save()
        self._schedule_eq_write()
        self.hud.show_event(f"Preset EQ · {name}", "APLICADO", 50, "EQUALIZADOR")

    def _capture_eq_ab_slot(self, slot_name: str) -> None:
        slot_name = str(slot_name).upper()
        if slot_name not in ("A", "B"):
            return
        self.profile.setdefault("eq_ab_slots", {"A": None, "B": None})[slot_name] = self._capture_eq_preset_snapshot(
            f"Comparação A/B · slot {slot_name}"
        )
        self._eq_ab_active_slot = slot_name
        self._save_profile()
        self.eq_ab_toggle_btn.setText(f"Comparar A/B · {slot_name} ativo")
        self.statusBar().showMessage(f"Curva atual armazenada no slot {slot_name} da comparação A/B.", 3000)

    def _toggle_eq_ab(self) -> None:
        slots = self.profile.get("eq_ab_slots", {})
        if not isinstance(slots, dict) or not isinstance(slots.get("A"), dict) or not isinstance(slots.get("B"), dict):
            QMessageBox.information(
                self, "Comparação A/B",
                "Salve uma curva em A e outra em B antes de alternar. Os dois slots preservam ganhos, frequências, modo e bypass."
            )
            return
        if self._eq_ab_active_slot == "A":
            target_slot = "B"
        else:
            target_slot = "A"
        snapshot = slots[target_slot]
        try:
            mode = normalize_mode(snapshot.get("mode", 8))
            frequency_source = snapshot.get("frequencies_by_mode", {})
            gains_source = snapshot.get("gains_by_mode", {})
            self.profile["eq_custom_frequencies"] = {
                mode_key: sanitize_frequencies(
                    frequency_source.get(mode_key, DEFAULT_FREQUENCIES[mode_key]), mode_key
                )
                for mode_key in DEFAULT_FREQUENCIES
            }
            self.profile["eq_gains_by_mode"] = {}
            for mode_key, default_frequencies in DEFAULT_FREQUENCIES.items():
                values = gains_source.get(mode_key, []) if isinstance(gains_source, dict) else []
                if not isinstance(values, list):
                    values = []
                values = [clamp_gain(value) for value in values[:len(default_frequencies)]]
                values += [0.0] * (len(default_frequencies) - len(values))
                self.profile["eq_gains_by_mode"][mode_key] = values
            self.profile["eq_mode"] = int(mode)
            self.profile["eq_fixed_frequencies"] = bool(snapshot.get("eq_fixed_frequencies", True))
            self.profile["eq_bypass"] = bool(snapshot.get("eq_bypass", False))
            self.profile["eq_low_cut_enabled"] = bool(snapshot.get("eq_low_cut_enabled", False))
            self.profile["eq_low_cut_hz"] = max(20.0, min(200.0, float(snapshot.get("eq_low_cut_hz", 40.0))))
            self.profile["eq_high_cut_enabled"] = bool(snapshot.get("eq_high_cut_enabled", False))
            self.profile["eq_high_cut_hz"] = max(5000.0, min(20000.0, float(snapshot.get("eq_high_cut_hz", 18000.0))))
            self._load_eq_cutoff_values()
            active_values = self.profile["eq_gains_by_mode"][mode]
            self.profile["eq_gains"] = [0.0] * 8
            self.profile["eq_gains"][:len(active_values)] = active_values
            self.profile["eq_selected_preset"] = "__current__"
            self.eq_band_mode_combo.blockSignals(True)
            self.eq_band_mode_combo.setCurrentIndex({"3": 0, "5": 1, "8": 2}.get(mode, 2))
            self.eq_band_mode_combo.blockSignals(False)
            self.eq_fixed_freq_checkbox.blockSignals(True)
            self.eq_fixed_freq_checkbox.setChecked(self.profile["eq_fixed_frequencies"])
            self.eq_fixed_freq_checkbox.blockSignals(False)
            self.eq_bypass_btn.blockSignals(True)
            self.eq_bypass_btn.setChecked(self.profile["eq_bypass"])
            self.eq_bypass_btn.setText("BYPASS ON" if self.profile["eq_bypass"] else "BYPASS OFF")
            self.eq_bypass_btn.blockSignals(False)
            self._rebuild_eq_band_controls()
            self._load_eq_band_values()
            self._update_knob_visuals()
            self._refresh_eq_preset_combo()
            self._eq_ab_active_slot = target_slot
            self.eq_ab_toggle_btn.setText(f"Comparar A/B · {target_slot} ativo")
            self._queue_profile_save()
            self._schedule_eq_write()
            self.hud.show_event(f"Equalização · slot {target_slot}", "CURVA APLICADA", 50, "COMPARAÇÃO A/B")
        except Exception as exc:
            logging.getLogger("smc_mixer_suite").exception("Could not restore EQ A/B snapshot")
            QMessageBox.warning(self, "Falha na comparação A/B", f"Não foi possível aplicar a curva salva.\n\n{exc}")

    def _capture_eq_preset_snapshot(self, description: str) -> dict[str, Any]:
        mode = self._active_eq_mode()
        gains_by_mode = {}
        for mode_key, count_freqs in DEFAULT_FREQUENCIES.items():
            values = list(self.profile.get("eq_gains_by_mode", {}).get(mode_key, []))
            if mode_key == mode:
                values = list(self.profile["eq_gains"][:int(mode_key)])
            values = [clamp_gain(v) for v in values[:len(count_freqs)]]
            values += [0.0] * (len(count_freqs) - len(values))
            gains_by_mode[mode_key] = values
        current_reference = gains_to_reference(self._eq_frequencies(mode), self.profile["eq_gains"][:int(mode)])
        return {
            "gains": current_reference,
            "gains_by_mode": gains_by_mode,
            "frequencies_by_mode": {key: list(self.profile["eq_custom_frequencies"][key]) for key in DEFAULT_FREQUENCIES},
            "mode": int(mode),
            "eq_fixed_frequencies": bool(self.profile.get("eq_fixed_frequencies", True)),
            "eq_bypass": bool(self.profile.get("eq_bypass", False)),
            "eq_low_cut_enabled": bool(self.profile.get("eq_low_cut_enabled", False)),
            "eq_low_cut_hz": float(self.profile.get("eq_low_cut_hz", 40.0)),
            "eq_high_cut_enabled": bool(self.profile.get("eq_high_cut_enabled", False)),
            "eq_high_cut_hz": float(self.profile.get("eq_high_cut_hz", 18000.0)),
            "description": description,
        }

    def _save_eq_preset_as(self) -> None:
        name, ok = QInputDialog.getText(self, "Salvar preset de equalização", "Nome do novo preset:")
        name = name.strip()[:80]
        if not ok or not name:
            return
        if name == "__current__" or name in FACTORY_PRESETS or name in self.profile.get("eq_user_presets", {}):
            QMessageBox.warning(self, "Nome já utilizado", "Escolha um nome diferente dos presets de fábrica e dos seus presets salvos.")
            return
        self.profile.setdefault("eq_user_presets", {})[name] = self._capture_eq_preset_snapshot(
            f"Preset completo salvo no modo {self.profile.get('eq_mode', 8)} bandas"
        )
        self.profile["eq_selected_preset"] = name
        self._refresh_eq_preset_combo()
        self._save_profile()
        self.statusBar().showMessage(f"Preset personalizado salvo: {name}", 3500)

    def _update_selected_eq_preset(self) -> None:
        name = self.eq_preset_combo.currentData()
        if not name or name not in self.profile.get("eq_user_presets", {}):
            QMessageBox.information(self, "Preset de fábrica", "Os presets de fábrica são protegidos. Use 'Salvar novo' para criar uma cópia editável.")
            return
        self.profile["eq_user_presets"][name] = self._capture_eq_preset_snapshot(
            f"Preset completo atualizado no modo {self.profile.get('eq_mode', 8)} bandas"
        )
        self.profile["eq_selected_preset"] = name
        self._refresh_eq_preset_combo()
        self._save_profile()
        self.statusBar().showMessage(f"Preset atualizado: {name}", 3000)

    def _delete_selected_eq_preset(self) -> None:
        name = self.eq_preset_combo.currentData()
        if not name or name not in self.profile.get("eq_user_presets", {}):
            return
        answer = QMessageBox.question(self, "Excluir preset", f"Excluir o preset personalizado '{name}'?")
        if answer != QMessageBox.StandardButton.Yes:
            return
        del self.profile["eq_user_presets"][name]
        self.profile["eq_selected_preset"] = "Flat / Neutro"
        self._refresh_eq_preset_combo()
        self._save_profile()
        self._apply_selected_eq_preset()

    def _on_eq_bypass(self, checked: bool) -> None:
        if self._loading:
            return
        self.profile["eq_bypass"] = checked
        self.eq_bypass_btn.setText("BYPASS ON" if checked else "BYPASS OFF")
        self._queue_profile_save()
        self._schedule_eq_write()

    def _on_band7_frequency_changed(self, _index: int) -> None:
        # Compatibility hook for profiles created before editable frequency fields.
        if self._loading or not hasattr(self, "band7_combo"):
            return
        self.profile["eq_custom_frequencies"]["8"][6] = float(self.band7_combo.currentData())
        self._queue_profile_save()
        self._schedule_eq_write()

    def _on_knob_mode_changed(self, _index: int) -> None:
        if self._loading:
            return
        self.profile["knob_mode"] = normalize_knob_mode(self.knob_mode_combo.currentData())
        self._knob_probe_samples.clear()
        self._detected_knob_modes.clear()
        self._save_profile()
        self._update_knob_mode_help()
        if hasattr(self, "knob_input_status"):
            self.knob_input_status.setText("Entrada MIDI: aguardando giro de um encoder mapeado.")
        self.statusBar().showMessage(f"Formato dos encoders: {self.knob_mode_combo.currentText()}", 3000)

    def _update_knob_mode_help(self) -> None:
        if not hasattr(self, "knob_mode_help"):
            return
        mode = normalize_knob_mode(self.profile.get("knob_mode", "auto"))
        step = float(self.profile.get("knob_step_db", 0.5))
        if mode == "auto":
            text = "Automático: gire o encoder por alguns passos. O programa detecta CC absoluto ou os formatos CW 1/127 e 63/65. Se não responder ou girar ao contrário, selecione o formato manualmente e use Inverter giro."
        elif mode == "absolute":
            text = "CC absoluto: a posição recebida (0–127) vira −12 a +12 dB. Use quando o encoder foi configurado como CC/absoluto no MidiSuite; marque Inverter giro se o sentido estiver contrário."
        elif mode == "relative_centered":
            text = f"CW centrado: 63 = um passo para baixo e 65 = um passo para cima. Cada passo altera {step:.1f} dB. Use quando o MidiSuite envia 63/65; marque Inverter giro se necessário."
        else:
            text = f"CW relativo: 1 = um passo para cima e 127 = um passo para baixo. Cada passo altera {step:.1f} dB. Use quando o MidiSuite envia 1/127; marque Inverter giro se necessário."
        self.knob_mode_help.setText(text)

    def _on_knob_target_mode_changed(self, _index: int) -> None:
        if self._loading:
            return
        self.profile["knob_target_mode"] = self.knob_target_combo.currentData()
        self._save_profile()
        self._update_knob_visuals()

    def _on_knob_step_changed(self, value: int) -> None:
        if self._loading:
            return
        self.profile["knob_step_db"] = value / 10.0
        self._save_profile()
        self._update_knob_mode_help()

    def _on_knob_invert_changed(self, checked: bool) -> None:
        if self._loading:
            return
        self.profile["knob_invert"] = bool(checked)
        self._save_profile()
        self.statusBar().showMessage(
            "Sentido dos encoders invertido." if checked else "Sentido normal dos encoders.", 2500
        )

    def _on_hysteresis_changed(self, value: int) -> None:
        if self._loading:
            return
        self.profile["midi_hysteresis"] = int(value)
        self._save_profile()

    # ---------- Hardware LED feedback and animation settings ----------
    def _rescan_led_outputs(self, _checked: bool = False, select: str | None = None) -> None:
        if not hasattr(self, "led_output_combo"):
            return
        preferred = select or (self.led_output_combo.currentData() if self.led_output_combo.count() else "AUTO")
        if not preferred or preferred == "AUTO":
            preferred = self.profile.get("led_output_port", "AUTO") if hasattr(self, "store") else "AUTO"
        ports = LedAnimationEngine.list_output_ports()
        self.led_output_combo.blockSignals(True)
        self.led_output_combo.clear()
        self.led_output_combo.addItem("Automático (SMC-Mixer)", "AUTO")
        for name in ports:
            self.led_output_combo.addItem(name, name)
        if preferred != "AUTO" and preferred not in ports:
            self.led_output_combo.addItem(f"{preferred} (aguardando reconexão)", preferred)
        idx = self.led_output_combo.findData(preferred)
        self.led_output_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.led_output_combo.blockSignals(False)
        if hasattr(self, "profile") and preferred:
            self.profile["led_output_port"] = preferred if preferred == "AUTO" or preferred in ports else preferred
        self._sync_led_engine_settings()

    def _on_led_settings_changed(self, *_args) -> None:
        if self._loading:
            return
        self.profile["led_feedback_enabled"] = bool(self.led_enabled_checkbox.isChecked())
        self.profile["led_mode"] = str(self.led_mode_combo.currentData() or "equalizer")
        self.profile["led_speed"] = max(0.25, min(4.0, self.led_speed_slider.value() / 100.0))
        self.profile["led_brightness"] = max(0.05, min(1.0, self.led_brightness_slider.value() / 100.0))
        self.profile["led_output_port"] = str(self.led_output_combo.currentData() or "AUTO")
        self.led_speed_label.setText(f"{self.profile['led_speed']:.2f}×")
        self.led_brightness_label.setText(f"{round(self.profile['led_brightness'] * 100)}%")
        self._queue_profile_save()
        self._sync_led_engine_settings()
        if not self.profile["led_feedback_enabled"]:
            self.led_status_label.setText("Feedback físico desativado; nenhuma mensagem de LED será enviada ao controlador.")
        elif self.profile["led_mode"] == "off":
            self.led_status_label.setText("Stealth Mode selecionado: o controlador receberá comandos para apagar os LEDs.")
        else:
            self.led_status_label.setText(f"Efeito configurado: {LED_MODES[self.profile['led_mode']]}. Aguardando confirmação da porta de saída MIDI.")

    def _sync_led_engine_settings(self) -> None:
        if not hasattr(self, "led_engine"):
            return
        profile = self.profile
        output_port = str(profile.get("led_output_port", "AUTO"))
        if hasattr(self, "led_output_combo") and self.led_output_combo.currentData() is not None:
            output_port = str(self.led_output_combo.currentData())
        input_port = str(self.store.data.get("midi_port", "AUTO"))
        if hasattr(self, "port_combo") and self.port_combo.currentData() is not None:
            input_port = str(self.port_combo.currentData())
        self.led_engine.configure(
            enabled=bool(profile.get("led_feedback_enabled", False)),
            mode=str(profile.get("led_mode", "equalizer")),
            speed=float(profile.get("led_speed", 1.0)),
            brightness=float(profile.get("led_brightness", 0.8)),
            output_port=output_port,
            input_port=input_port,
        )

    def _push_led_state(self, volumes: dict[str, float | None] | None = None, mutes: dict[str, bool | None] | None = None) -> None:
        if not hasattr(self, "led_engine"):
            return
        targets = [self._current_target(i) for i in range(8)]
        if volumes is None:
            volumes = self._last_volumes
        if mutes is None:
            mutes = self._last_mutes
        levels = []
        muted = []
        for target in targets:
            scalar = volumes.get(target) if target else None
            levels.append(max(0.0, min(1.0, float(scalar or 0.0))))
            state = mutes.get(target) if target else False
            muted.append(bool(state) if state is not None else False)
        if self.profile.get("knob_target_mode", "eq") == "eq":
            knobs = [((float(self.profile["eq_gains"][i]) + 12.0) / 24.0) if i < int(self.profile.get("eq_mode", 8)) else 0.0 for i in range(8)]
        else:
            knobs = levels.copy()
        selected = [i == self._selected_channel or i == self._solo_channel for i in range(8)]
        record_armed = []
        actions = self.profile.get("button_actions", {})
        for i in range(8):
            row = actions.get(f"ch{i+1}_rec", {})
            # A configured REC action is marked as armed; an unconfigured button stays dark.
            record_armed.append(str(row.get("action", "none")) != "none")
        self.led_engine.set_state(levels=levels, knobs=knobs, muted=muted, selected=selected, record_armed=record_armed)
        if hasattr(self, "led_preview_bars"):
            for bar, value in zip(self.led_preview_bars, levels):
                bar.setValue(round(value * 100))

    def _test_led_output(self) -> None:
        if not self.led_enabled_checkbox.isChecked():
            QMessageBox.information(self, "Feedback desativado", "Marque primeiro 'Ativar animações e feedback na unidade física'.")
            return
        self.led_engine.request_test()
        self.led_status_label.setText("Teste sequencial enviado: 32 LEDs, um por vez, pelas quatro linhas (aprox. 5 s). Se só a primeira linha responder, confira CC Mode e o mapeamento de LEDs no MidiSuite.")

    def _on_led_engine_status(self, text: str) -> None:
        if hasattr(self, "led_status_label"):
            self.led_status_label.setText(text)

    # ---------- MIDI port status and settings ----------
    def _on_midi_status(self, text: str) -> None:
        low = text.casefold()
        connected = "midi conectado:" in low
        old_port = str(getattr(self, "_connected_port_name", "") or "")
        new_port = text.split(":", 1)[1].strip() if connected and ":" in text else ""
        # Auto-detection is scoped to a live MIDI connection. Do not reuse a
        # relative/absolute guess after USB/Bluetooth reconnect or port change:
        # devices/drivers can resume with a different stream or reordered events.
        if (old_port and (not connected or new_port != old_port)):
            self._knob_probe_samples.clear()
            self._detected_knob_modes.clear()
            self._midi_values.clear()
            self._last_fader_applied.clear()
            try:
                self._button_press_gate.reset_all()
            except Exception:
                pass
        self.connection_label.setText(text)
        palette = getattr(self, "_active_palette", resolve_palette(DEFAULT_THEME))
        self.connection_dot.setStyleSheet(f"color:{palette['success'] if connected else palette['warning']}; font-size:16px;")
        self.tray.setToolTip("SMC Mixer Suite — " + text)
        if hasattr(self, "bt_label"):
            self.bt_label.setText("MIDI conectado" if connected else "MIDI / Bluetooth · desconectado ou aguardando")
        self._connected_port_name = new_port
        self._update_transport_indicator(connected)
        port_name = self._connected_port_name.casefold()
        if connected and (str(self.store.data.get("midi_transport", "auto")) == "bluetooth" or any(w in port_name for w in ("bluetooth", "ble", "sinco", "wireless"))):
            self._battery_poll_timer.stop()

    def _update_transport_indicator(self, connected: bool | None = None) -> None:
        if not hasattr(self, "transport_label"):
            return
        if connected is None:
            connected = bool(getattr(self, "_connected_port_name", ""))
        if not connected:
            message = "Conexão física: desconectado"
            color = "#d6a84e"
        else:
            forced = str(self.store.data.get("midi_transport", "auto"))
            port = str(getattr(self, "_connected_port_name", "") or "")
            normalized = port.casefold()
            if forced == "bluetooth" or any(word in normalized for word in ("bluetooth", "ble", "sinco", "wireless", "m-vave bt")):
                message = "Conexão física: Bluetooth LE"
                color = "#38bdf8"
            elif forced == "usb" or "usb" in normalized:
                message = "Conexão física: USB"
                color = "#34d399"
            else:
                message = "Conexão física: MIDI ativo · transporte não identificado"
                color = "#a78bfa"
        self.transport_label.setText(message)
        self.transport_label.setStyleSheet(f"padding:4px 8px;background:#202630;border:1px solid {color};border-radius:5px;font-weight:750;color:{color};")

    def _on_transport_mode_changed(self, _index: int) -> None:
        if self._loading:
            return
        mode = str(self.transport_mode_combo.currentData() or "auto")
        self.store.data["midi_transport"] = mode
        self._persist_root_settings()
        self._update_transport_indicator()
        if mode == "bluetooth":
            self.statusBar().showMessage("Bluetooth LE usa a porta MIDI virtual fornecida pelo driver/bridge do Windows; o modo não instala nem substitui o driver.", 6500)

    def _request_battery_probe(self) -> None:
        if self._battery_probe_pending:
            return
        self._battery_probe_pending = True
        self.battery_probe_btn.setEnabled(False)
        self.battery_probe_btn.setText("Lendo BLE…")
        self.battery_label.setText("Bateria SMC: consultando BLE…")
        worker = _BatteryProbeWorker()
        worker.signals.finished.connect(self._on_battery_probe_finished)
        self._battery_probe_worker = worker
        self._battery_pool.start(worker)

    def _on_battery_probe_finished(self, result: object) -> None:
        self._battery_probe_pending = False
        self.battery_probe_btn.setEnabled(True)
        self.battery_probe_btn.setText("Ler bateria BLE")
        if not isinstance(result, dict):
            result = {"level": None, "charging": None, "device": None, "error": "Resposta BLE inválida"}
        self._battery_last_result = dict(result)
        level = result.get("level")
        charging = result.get("charging")
        error = str(result.get("error") or "")
        device = str(result.get("device") or "SMC-Mixer")
        now = time.monotonic()
        if level is None:
            self.battery_label.setText("Bateria SMC: N/D · firmware não forneceu percentual")
            self.charge_label.setText("Carga: não reportada via Bluetooth GATT")
            self.battery_eta_label.setText("Tempo de recarga: indisponível sem telemetria")
            self.battery_label.setToolTip(error)
            logging.getLogger("smc_mixer_suite").info("Battery status unavailable: %s", error)
            self._battery_previous_sample = None
            self._battery_previous_charging = None
            self._battery_rate_pct_per_min = None
            self._battery_poll_timer.stop()
            self.statusBar().showMessage("O SMC-Mixer não expôs percentual de bateria via Bluetooth GATT. O programa não vai estimar um valor inventado.", 6500)
            return
        level = max(0, min(100, int(level)))
        self.battery_label.setText(f"Bateria SMC: {level}% · {device}")
        self.battery_label.setToolTip("Percentual lido do serviço padrão Bluetooth Battery Service.")
        if charging is True:
            self.charge_label.setText("Carga: carregando")
        elif charging is False:
            self.charge_label.setText("Carga: não carregando")
        else:
            self.charge_label.setText("Carga: estado não informado pelo firmware")
        previous = self._battery_previous_sample
        if self._battery_previous_charging is not charging:
            previous = None
            self._battery_rate_pct_per_min = None
        if charging is True and previous is not None:
            old_level, old_time = previous
            minutes = (now - old_time) / 60.0
            delta = level - old_level
            if minutes >= 1.0 and delta > 0:
                rate = delta / minutes
                self._battery_rate_pct_per_min = rate if rate > 0 else None
        self._battery_previous_sample = (level, now)
        self._battery_previous_charging = charging
        if level >= 100:
            self.battery_eta_label.setText("Tempo de recarga: carga completa")
        elif charging is not True:
            self.battery_eta_label.setText("Tempo de recarga: não carregando")
        elif self._battery_rate_pct_per_min and self._battery_rate_pct_per_min > 0:
            remaining = int(max(0, round((100 - level) / self._battery_rate_pct_per_min)))
            self.battery_eta_label.setText(f"Tempo de recarga estimado: {remaining // 60} h {remaining % 60:02d} min")
        else:
            self.battery_eta_label.setText("Tempo de recarga: medindo a taxa de carga…")
        self._battery_poll_timer.start()


    def _on_midi_ports(self, ports: list[str]) -> None:
        current = self.store.data.get("midi_port", "AUTO")
        self.port_combo.blockSignals(True)
        self.port_combo.clear()
        self.port_combo.addItem("Automático (SMC-Mixer)", "AUTO")
        for port in ports:
            self.port_combo.addItem(port, port)
        if current != "AUTO" and current not in ports:
            self.port_combo.addItem(f"{current} (aguardando reconexão)", current)
        idx = self.port_combo.findData(current)
        self.port_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.port_combo.blockSignals(False)
        self._sync_led_engine_settings()

    def _on_port_selected(self, _index: int) -> None:
        if self._loading:
            return
        port = self.port_combo.currentData() or "AUTO"
        self.store.set_pref("midi_port", port)
        if hasattr(self, "midi"):
            self.midi.set_requested_port(port)
        self._sync_led_engine_settings()

    def _rescan_midi(self) -> None:
        if hasattr(self, "midi"):
            self.midi.request_rescan()
        self.statusBar().showMessage("Reescaneando portas MIDI…", 2500)

    def _on_eq_path_changed(self, text: str) -> None:
        if self._loading:
            return
        self.store.set_pref("eq_file", text.strip())
        self._schedule_eq_write()

    def _browse_eq_file(self) -> None:
        current = self.eq_path_edit.text().strip() or str(APP_DIR / "equalizerapo_filters.txt")
        path, _ = QFileDialog.getSaveFileName(self, "Arquivo de filtros Equalizer APO", current, "Arquivos de texto (*.txt);;Todos os arquivos (*.*)")
        if path:
            self.eq_path_edit.setText(path)
            self.store.set_pref("eq_file", path)
            self._schedule_eq_write()

    def _write_eq_at_path(self, path: str | Path) -> Path:
        """Render the currently selected EQ curve to a specific output path."""
        return write_config(
            str(path), self.profile["eq_gains"], self.profile["eq_bypass"],
            self.profile.get("eq_band7_freq", 8000),
            mode=self.profile.get("eq_mode", 8), frequencies=self._eq_frequencies(),
            low_cut_enabled=bool(self.profile.get("eq_low_cut_enabled", False)),
            low_cut_hz=float(self.profile.get("eq_low_cut_hz", 40.0)),
            high_cut_enabled=bool(self.profile.get("eq_high_cut_enabled", False)),
            high_cut_hz=float(self.profile.get("eq_high_cut_hz", 18000.0)),
        )

    def _write_eq_file(self) -> Path | None:
        path = self.store.data.get("eq_file", "").strip() or str(APP_DIR / "equalizerapo_filters.txt")
        try:
            written = self._write_eq_at_path(path)
            cuts = []
            if self.profile.get("eq_low_cut_enabled", False): cuts.append(f"HP {self.profile.get('eq_low_cut_hz', 40):g} Hz")
            if self.profile.get("eq_high_cut_enabled", False): cuts.append(f"LP {self.profile.get('eq_high_cut_hz', 18000):g} Hz")
            cut_text = (" · " + ", ".join(cuts)) if cuts else " · cortes desligados"
            config_text = str(self.store.data.get("eqapo_config_path", "") or "").strip()
            config_path = Path(os.path.expandvars(config_text)).expanduser() if config_text else find_equalizer_apo_config()
            linked = False
            if config_path is not None and config_path.is_file():
                try:
                    config_contents = config_path.read_text(encoding="utf-8-sig", errors="replace")
                    linked = include_exists(config_contents, written, config_path.parent)
                except OSError:
                    linked = False
            if linked:
                message = (
                    f"EQ VINCULADO · arquivo atualizado ({self.profile.get('eq_mode', 8)} bandas{cut_text}) em {written}; "
                    f"Include encontrado em {config_path}. Confirme que o APO está habilitado no dispositivo de saída."
                )
            else:
                message = (
                    f"EQ GERADO, AINDA NÃO VINCULADO ({self.profile.get('eq_mode', 8)} bandas{cut_text}): {written}. "
                    "Clique em 'Vincular ao APO'."
                )
            self.eq_file_status.setText(message)
            self.statusBar().showMessage("Arquivo EQ atualizado." if linked else "Arquivo EQ gerado, mas ainda não vinculado ao Equalizer APO.", 4500)
            return written
        except Exception as exc:
            message = f"Não foi possível gravar o arquivo EQ: {exc}"
            self.eq_file_status.setText(message)
            self.statusBar().showMessage(message, 7000)
            logging.getLogger("smc_mixer_suite").exception("EQ filter file write failed")
            return None

    def _configure_equalizer_apo(self) -> None:
        """Link a filter file located beside APO config.txt for reliable live reloads."""
        source_path = APP_DIR / "equalizerapo_filters.txt"
        try:
            # Always keep a writable source copy, even if the currently selected
            # APO-folder file is unwritable because a previous elevation was cancelled.
            source_filter = self._write_eq_at_path(source_path)
        except Exception as exc:
            QMessageBox.warning(self, "Equalizer APO", f"Não consegui gerar o arquivo de filtros de origem.\n\n{exc}")
            return

        preferred = str(self.store.data.get("eqapo_config_path", "") or "").strip()
        config_path = Path(os.path.expandvars(preferred)).expanduser() if preferred else find_equalizer_apo_config()
        if config_path is None or not config_path.is_file():
            selected, _ = QFileDialog.getOpenFileName(
                self, "Selecione config.txt do Equalizer APO", r"C:\Program Files\EqualizerAPO\config",
                "Configuração do Equalizer APO (config.txt);;Arquivos de texto (*.txt)",
            )
            if not selected:
                QMessageBox.information(self, "Equalizer APO", "Instale o Equalizer APO e selecione o arquivo config.txt para vincular o EQ global.")
                self.store.set_pref("eq_file", str(source_filter))
                self.eq_path_edit.setText(str(source_filter))
                self._write_eq_file()
                return
            config_path = Path(selected)

        config_path = config_path.resolve()
        target_filter = (config_path.parent / "SMC_Mixer_Suite_filters.txt").resolve()
        old_filter_text = str(self.store.data.get("eq_file", "") or "").strip()
        old_filter = Path(os.path.expandvars(old_filter_text)).expanduser() if old_filter_text else source_filter
        obsolete = [source_filter]
        if str(old_filter.resolve()) != str(target_filter):
            obsolete.append(old_filter)

        try:
            # A file beside config.txt is monitored much more reliably for live
            # updates than an Include that points to an arbitrary external folder.
            self._write_eq_at_path(target_filter)
            backup = configure_include_file(config_path, target_filter, remove_paths=obsolete)
            self.store.set_pref("eqapo_config_path", str(config_path))
            self.store.set_pref("eq_file", str(target_filter))
            self.eq_path_edit.setText(str(target_filter))
            self._write_eq_file()
            details = (
                "O Include foi atualizado. " + f"Backup criado: {backup}"
                if backup is not None else "O Include já estava configurado corretamente; não foi criada uma linha duplicada."
            )
            QMessageBox.information(
                self, "Equalizer APO vinculado",
                details + "\n\nO arquivo de filtros foi colocado na pasta config do APO para que as alterações dos knobs/ganhos possam ser recarregadas. "
                "Confirme que o APO está habilitado no dispositivo de saída certo. Se não houver mudança sonora, recarregue a configuração no Configuration Editor.",
            )
            self.statusBar().showMessage("EQ vinculado: arquivo de filtros na pasta config do Equalizer APO.", 5000)
            return
        except PermissionError:
            # Program Files normally blocks writes. Ask for UAC once, copy the
            # filter under the APO config folder, grant Modify on that single file
            # to this user, and replace the old Include with the local Include.
            if os.name != "nt":
                QMessageBox.warning(self, "Permissão necessária", "Não tenho permissão para alterar a configuração do Equalizer APO neste sistema.")
                return
            try:
                script_path = APP_DIR / "configure_equalizer_apo_admin.ps1"
                script_path.write_text(ELEVATED_POWERSHELL_SCRIPT, encoding="utf-8-sig")
                powershell = str(Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe")
                params = (
                    f'-NoProfile -ExecutionPolicy Bypass -File "{script_path}" '
                    f'-ConfigPath "{config_path}" -SourceFilterPath "{source_filter}" -TargetFilterPath "{target_filter}"'
                )
                result = ctypes.windll.shell32.ShellExecuteW(None, "runas", powershell, params, str(APP_DIR), 1)
                if result <= 32:
                    raise OSError(f"O Windows recusou a elevação (código {result}).")
                self.store.set_pref("eqapo_config_path", str(config_path))
                self.store.set_pref("eq_file", str(target_filter))
                self.eq_path_edit.setText(str(target_filter))
                self.eq_file_status.setText("Aguardando autorização do Windows. O EQ será atualizado após confirmar a janela de administrador.")
                self.statusBar().showMessage("Autorize o vínculo no aviso do Windows; ele permite atualizar somente o arquivo de filtros do APO.", 7000)
                self._eq_link_verify_timer.start()
            except Exception as exc:
                QMessageBox.warning(
                    self, "Não foi possível configurar automaticamente",
                    f"O Windows não permitiu alterar a configuração.\n\n{exc}\n\nTente novamente e aceite a solicitação de administrador.",
                )
        except Exception as exc:
            logging.getLogger("smc_mixer_suite").exception("Equalizer APO integration failed")
            QMessageBox.warning(self, "Falha ao configurar Equalizer APO", f"Não foi possível vincular o arquivo de filtros.\n\n{exc}")

    def _diagnose_equalizer_apo(self) -> None:
        """Inspect the EQ filter file and its Include in Equalizer APO config.txt.

        This is intentionally read-only: diagnostics should never rewrite APO
        configuration or silently alter the active EQ while the user is checking it.
        """
        logger = logging.getLogger("smc_mixer_suite")
        report: list[str] = ["Diagnóstico do Equalizer APO", ""]

        try:
            stored_config = str(self.store.data.get("eqapo_config_path", "") or "").strip()
            config_path = Path(os.path.expandvars(stored_config)).expanduser() if stored_config else None
            if config_path is None or not config_path.is_file():
                config_path = find_equalizer_apo_config()

            stored_filter = str(self.store.data.get("eq_file", "") or "").strip()
            ui_filter = self.eq_path_edit.text().strip() if hasattr(self, "eq_path_edit") else ""
            filter_text = stored_filter or ui_filter or str(APP_DIR / "equalizerapo_filters.txt")
            filter_path = Path(os.path.expandvars(filter_text)).expanduser()

            filter_exists = filter_path.is_file()
            report.append(f"Arquivo de filtros: {filter_path}")
            report.append(f"Arquivo existe: {'SIM' if filter_exists else 'NÃO'}")
            if filter_exists:
                try:
                    filter_content = filter_path.read_text(encoding="utf-8-sig", errors="replace")
                except OSError as exc:
                    filter_content = ""
                    report.append(f"Leitura do arquivo: FALHOU ({exc})")
                filter_lines = [
                    line.strip() for line in filter_content.splitlines()
                    if line.strip().lower().startswith("filter ") and ":" in line
                ]
                enabled_filters = [line for line in filter_lines if ": on " in line.lower()]
                disabled_filters = [line for line in filter_lines if ": off " in line.lower()]
                report.append(f"Filtros encontrados: {len(filter_lines)}")
                report.append(f"Filtros ON/OFF: {len(enabled_filters)} ON / {len(disabled_filters)} OFF")
                if "bypass global: ativado" in filter_content.casefold():
                    report.append("Estado do arquivo: BYPASS ativado (filtros desabilitados por configuração)")
                elif not enabled_filters and filter_lines:
                    report.append("Estado do arquivo: nenhum filtro marcado como ON")
            else:
                report.append("Filtros: não foi possível contar porque o arquivo não existe.")

            if config_path is None or not config_path.is_file():
                report.extend([
                    "",
                    "config.txt do Equalizer APO: NÃO ENCONTRADO",
                    "Ação: instale o Equalizer APO ou escolha o config.txt na aba de configuração.",
                ])
                linked = False
            else:
                config_path = config_path.resolve()
                report.append(f"config.txt: {config_path}")
                try:
                    config_content = config_path.read_text(encoding="utf-8-sig", errors="replace")
                except OSError as exc:
                    config_content = ""
                    report.append(f"Leitura de config.txt: FALHOU ({exc})")

                linked = bool(filter_exists and include_exists(config_content, filter_path, config_path.parent))
                report.append(f"Include correspondente ao arquivo escolhido: {'SIM' if linked else 'NÃO'}")

                matching_include_index = None
                all_lines = config_content.splitlines()
                for index, line in enumerate(all_lines):
                    if line.strip().lower().startswith("include:") and include_exists(line, filter_path, config_path.parent):
                        matching_include_index = index
                        break
                scope_index = next((
                    index for index, line in enumerate(all_lines)
                    if line.strip().lower().startswith(("device:", "channel:"))
                ), None)
                if matching_include_index is None:
                    report.append("Posição do Include: sem referência correspondente encontrada.")
                elif scope_index is not None and matching_include_index > scope_index:
                    report.append("Posição do Include: ATENÇÃO — aparece depois de Device:/Channel:.")
                else:
                    report.append(f"Posição do Include: linha {matching_include_index + 1}; antes de escopos Device/Channel.")

            if not linked:
                report.extend([
                    "",
                    "Correção sugerida: clique em 'Vincular ao APO automaticamente' e aceite a solicitação de administrador, se aparecer.",
                ])
            else:
                report.extend([
                    "",
                    "Os arquivos e a referência Include estão vinculados.",
                    "Isso NÃO comprova sozinho que o Equalizer APO esteja habilitado no dispositivo de saída usado pelo Windows.",
                    "Se o som não mudar, confira o dispositivo no Equalizer APO Configurator e recarregue a configuração.",
                ])

            if bool(self.profile.get("eq_bypass", False)):
                report.extend(["", "Atenção: o bypass global está ATIVADO no perfil atual."])

            message = "\n".join(report)
            if hasattr(self, "eq_file_status"):
                self.eq_file_status.setText(
                    "Diagnóstico EQ: vínculo confirmado nos arquivos." if linked
                    else "Diagnóstico EQ: vínculo incompleto; consulte o relatório."
                )
            self.statusBar().showMessage("Diagnóstico do Equalizer APO concluído.", 5000)
            logger.info("Equalizer APO diagnostic completed: config=%s filter=%s linked=%s", config_path, filter_path, linked)
            if linked and filter_exists:
                QMessageBox.information(self, "Diagnóstico do Equalizer APO", message)
            else:
                QMessageBox.warning(self, "Diagnóstico do Equalizer APO", message)
        except Exception as exc:
            logger.exception("Equalizer APO diagnostic failed")
            QMessageBox.warning(
                self,
                "Falha no diagnóstico do Equalizer APO",
                f"Não foi possível concluir o diagnóstico.\n\n{exc}\n\nConsulte o log local do SMC Mixer Suite.",
            )

    def _copy_include_line(self) -> None:
        path = self.store.data.get("eq_file", "").strip() or str(APP_DIR / "equalizerapo_filters.txt")
        line = include_line(path)
        QApplication.clipboard().setText(line)
        self._write_eq_file()
        QMessageBox.information(self, "Linha Include copiada", f"Copiei esta linha para a área de transferência:\n\n{line}\n\nCole-a no config.txt do Equalizer APO e salve o arquivo.")

    def _open_eq_folder(self) -> None:
        path = self.store.data.get("eq_file", "").strip() or str(APP_DIR / "equalizerapo_filters.txt")
        folder = str(Path(os.path.expandvars(path)).expanduser().parent)
        Path(folder).mkdir(parents=True, exist_ok=True)
        try:
            os.startfile(folder)
        except Exception as exc:
            QMessageBox.warning(self, "Não foi possível abrir a pasta", str(exc))

    # ---------- Tray / exit ----------
    def _show_from_tray(self) -> None:
        self.showMaximized()
        self.raise_()
        self.activateWindow()

    def _on_tray_activated(self, reason: QSystemTrayIcon.ActivationReason) -> None:
        if reason in (QSystemTrayIcon.ActivationReason.DoubleClick, QSystemTrayIcon.ActivationReason.Trigger):
            self._show_from_tray()

    def closeEvent(self, event) -> None:
        if self._allow_exit:
            event.accept()
            return
        event.ignore()
        self.hide()
        self.tray.showMessage("SMC Mixer Suite", "O aplicativo continua ativo na bandeja do sistema.", QSystemTrayIcon.MessageIcon.Information, 2200)

    def _exit_application(self) -> None:
        self._restore_solo_snapshot()
        self._allow_exit = True
        if hasattr(self, "_analog_midi_timer"):
            self._analog_midi_timer.stop()
            self._flush_pending_analog_midi()
        if hasattr(self, "_profile_save_timer"):
            self._profile_save_timer.stop()
        if hasattr(self, "_learn_timer"):
            self._learn_timer.stop()
        if hasattr(self, "_volume_apply_timer"):
            self._volume_apply_timer.stop()
            self._apply_pending_volume_updates()
        if hasattr(self, "_microphone_write_timer"):
            self._microphone_write_timer.stop()
            self._dispatch_microphone_write()
        self._save_profile()
        if hasattr(self, "_refresh_timer"):
            self._refresh_timer.stop()
        if hasattr(self, "midi"):
            self.midi.stop()
        if hasattr(self, "led_engine"):
            self.led_engine.stop()
        try:
            self._audio_poll_pool.waitForDone(2500)
            self._microphone_write_pool.waitForDone(2500)
        except Exception:
            pass
        self.hud.hide()
        self.tray.hide()
        if self._com_initialized and self._comtypes is not None:
            try:
                self._comtypes.CoUninitialize()
            except Exception:
                logging.getLogger("smc_mixer_suite").exception("COM cleanup failed")
            self._com_initialized = False
        QApplication.quit()
