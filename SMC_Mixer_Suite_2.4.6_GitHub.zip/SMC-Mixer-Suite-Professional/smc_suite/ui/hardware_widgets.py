from __future__ import annotations

import math
import time
from typing import Any

from PyQt6.QtCore import Qt, QPoint, QRectF, pyqtSignal, QTimer, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QColor, QPainter, QPainterPath, QPen, QFont
from PyQt6.QtWidgets import (
    QApplication, QComboBox, QFrame, QGraphicsOpacityEffect, QHBoxLayout, QLabel,
    QLineEdit, QProgressBar, QPushButton, QSlider, QVBoxLayout, QWidget, QSizePolicy,
)


class RotaryKnob(QWidget):
    """Mouse-adjustable visual replica of an endless rotary encoder."""
    valueChanged = pyqtSignal(int)
    doubleClicked = pyqtSignal()

    def __init__(self, minimum: int = -24, maximum: int = 24, value: int = 0, parent=None) -> None:
        super().__init__(parent)
        self._minimum = minimum
        self._maximum = maximum
        self._value = value
        self._drag_y: int | None = None
        self._accent_color = QColor("#39b488")
        self._track_color = QColor("#303945")
        self.setFixedSize(54, 54)
        self.setCursor(Qt.CursorShape.SizeVerCursor)
        self.setToolTip("Arraste verticalmente para ajustar em passos finos. Duplo clique restaura 0,0 dB quando o alvo é o EQ.")

    def setRange(self, minimum: int, maximum: int) -> None:  # Qt-like API
        self._minimum, self._maximum = minimum, maximum
        self.setValue(self._value, emit=False)

    def setValue(self, value: int, emit: bool = False) -> None:
        value = max(self._minimum, min(self._maximum, int(value)))
        if value == self._value:
            self.update()
            return
        self._value = value
        self.update()
        if emit:
            self.valueChanged.emit(value)

    def value(self) -> int:
        return self._value

    def mouseDoubleClickEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.doubleClicked.emit()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_y = int(event.position().y())
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:
        if self._drag_y is not None and event.buttons() & Qt.MouseButton.LeftButton:
            y = int(event.position().y())
            delta = self._drag_y - y
            if delta:
                span = self._maximum - self._minimum
                step = max(1, round(span / 240))
                self.setValue(self._value + delta * step, emit=True)
                self._drag_y = y
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        self._drag_y = None
        super().mouseReleaseEvent(event)

    def set_theme_colors(self, accent: str, track: str) -> None:
        self._accent_color = QColor(accent)
        self._track_color = QColor(track)
        self.update()

    def set_compact(self, compact: bool) -> None:
        size = 44 if compact else 54
        self.set_diameter(size)

    def set_diameter(self, size: int) -> None:
        """Set a square, DPI-friendly knob size without changing its value."""
        size = max(44, min(96, int(size)))
        self.setFixedSize(size, size)
        self.update()

    def paintEvent(self, _event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        cx, cy = self.width() / 2, self.height() / 2
        r = min(cx, cy) - 5
        fraction = (self._value - self._minimum) / max(1, self._maximum - self._minimum)

        # Outer ring and 270-degree value arc; visual direction follows the physical knob.
        track = QPainterPath()
        accent = QPainterPath()
        steps = 100
        for i in range(steps + 1):
            frac = i / steps
            angle = math.radians(135 + 270 * frac)
            pt = (cx + math.cos(angle) * (r - 1), cy + math.sin(angle) * (r - 1))
            if i == 0:
                track.moveTo(*pt)
            else:
                track.lineTo(*pt)
            if frac <= fraction:
                if accent.elementCount() == 0:
                    accent.moveTo(*pt)
                else:
                    accent.lineTo(*pt)
        p.setPen(QPen(self._track_color, 4.4, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawPath(track)
        p.setPen(QPen(self._accent_color, 4.4, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawPath(accent)
        p.setPen(QPen(QColor("#20252d"), 1))
        p.setBrush(QColor("#202428"))
        p.drawEllipse(QRectF(cx - r + 7, cy - r + 7, (r - 7) * 2, (r - 7) * 2))

        angle = math.radians(135 + 270 * fraction)
        x2 = cx + math.cos(angle) * (r - 13)
        y2 = cy + math.sin(angle) * (r - 13)
        p.setPen(QPen(QColor("#f4f7fb"), 2.6, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawLine(round(cx), round(cy), round(x2), round(y2))
        p.setPen(QPen(Qt.PenStyle.NoPen))
        p.setBrush(QColor("#aeb7bf"))
        p.drawEllipse(QRectF(cx - 3, cy - 3, 6, 6))
        p.end()


class LedDbMeter(QWidget):
    """Compact segmented dB meter. Actual peak is shown when Windows exposes it; otherwise it visualizes control attenuation."""
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._db = -60.0
        self._percent = 0.0
        self._mode = "db"
        self._actual_peak = False
        self._color = QColor("#39b488")
        self.setMinimumWidth(30)
        self.setMaximumWidth(36)
        self._compact = False
        self.setMinimumHeight(70)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        self.setToolTip("Escala de -60 a 0 dB. Quando a API de sessão não disponibiliza pico real, mostra a atenuação do volume configurado.")

    def set_db(self, value: float | None, actual_peak: bool = False) -> None:
        self._mode = "db"
        if value is None or not math.isfinite(float(value)):
            self._db = -60.0
            self._actual_peak = False
        else:
            self._db = max(-60.0, min(0.0, float(value)))
            self._actual_peak = bool(actual_peak)
        self.setToolTip(
            f"Pico da sessão: {self._db:.1f} dBFS" if self._actual_peak else
            f"Ganho/volume configurado: {self._db:.1f} dB (não é pico acústico do processo)."
        )
        self.update()

    def set_percent(self, value: float | None, label: str = "Brilho") -> None:
        self._mode = "percent"
        try:
            self._percent = max(0.0, min(100.0, float(value))) if value is not None else 0.0
        except (TypeError, ValueError):
            self._percent = 0.0
        self._actual_peak = False
        self.setToolTip(f"{label}: {self._percent:.0f}%")
        self.update()

    def set_color(self, color: str) -> None:
        qcolor = QColor(color)
        if qcolor.isValid():
            self._color = qcolor
            self.update()

    def set_compact(self, compact: bool) -> None:
        self._compact = bool(compact)
        self.setMinimumWidth(26 if compact else 30)
        self.setMaximumWidth(30 if compact else 36)
        self.updateGeometry()
        self.update()

    def paintEvent(self, _event) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        label_w = 16 if self._compact else 18
        bar_x = 1 if self._compact else 2
        bar_w = max(5, min(9, w - label_w - 4))
        top, bottom = 5, h - 5
        count = 24
        gap = 2
        seg_h = max(2.0, (bottom - top - (count - 1) * gap) / count)
        active = max(0, min(count, int(round((self._db + 60.0) / 60.0 * count)))) if self._mode == "db" else int(round(self._percent / 100.0 * count))
        for i in range(count):
            y = bottom - seg_h - i * (seg_h + gap)
            threshold_db = -60.0 + (i + 0.5) * (60.0 / count)
            if i < active:
                if self._mode == "db" and threshold_db >= -6:
                    color = QColor("#ef4444")
                elif self._mode == "db" and threshold_db >= -12:
                    color = QColor("#fbbf24")
                else:
                    color = QColor(self._color)
            else:
                color = QColor("#2e3743")
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(color)
            p.drawRoundedRect(QRectF(bar_x, y, bar_w, seg_h), 1.2, 1.2)
        p.setPen(QColor("#91a0b3"))
        font = p.font()
        font.setPixelSize(6 if self._compact else 7)
        p.setFont(font)
        if self._mode == "percent":
            for pct in (100, 75, 50, 25, 0):
                y = bottom - (pct / 100.0) * (bottom - top)
                p.drawText(bar_x + bar_w + 2, int(y + 3), str(pct))
        else:
            for db in (0, -6, -12, -24, -36, -60):
                y = bottom - ((db + 60.0) / 60.0) * (bottom - top)
                p.drawText(bar_x + bar_w + 2, int(y + 3), str(db))
        p.end()


class ChannelStrip(QFrame):
    faderChanged = pyqtSignal(int, int)
    knobChanged = pyqtSignal(int, int)
    knobResetRequested = pyqtSignal(int)
    targetChanged = pyqtSignal(int, str)
    nameCommitted = pyqtSignal(int, str)
    learnRequested = pyqtSignal(str, int)
    buttonActivated = pyqtSignal(str)
    buttonContextRequested = pyqtSignal(str, QPoint)
    colorChangeRequested = pyqtSignal(int)

    BUTTONS = [("M", "mute", "Silenciar canal"), ("S", "solo", "Solo: silenciar os outros canais"),
               ("R", "rec", "Ação de gravação configurável"), ("□", "select", "Selecionar canal")]

    def __init__(self, index: int, parent=None) -> None:
        super().__init__(parent)
        self.index = index
        self._loading = False
        self._channel_color = "#39b488"
        self._theme_palette = None
        self._compact = False
        self.setObjectName("channelStrip")
        self.setMinimumWidth(108)
        self.setMaximumWidth(184)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self._base_stylesheet = """
            QFrame#channelStrip { background:#20242b; border:1px solid #343b46; border-radius:9px; }
            QFrame#channelStrip[selected="true"] { border:2px solid #58a6ff; }
            QLabel { border:none; }
            QLineEdit#channelName { background:#171b21; border:1px solid #39424f; border-radius:5px; padding:5px 3px; font-weight:650; }
            QComboBox#appTarget { background:#171b21; border:1px solid #39424f; border-radius:5px; padding:4px 2px; }
            QPushButton#learnSmall { padding:3px; font-size:10px; min-height:19px; }
            QPushButton#hardwareKey { padding:1px; font-weight:800; min-height:25px; max-height:29px; min-width:24px; }
            QPushButton#hardwareKey:checked { background:#1d4ed8; border-color:#60a5fa; color:white; }
            QSlider::groove:vertical { background:#11151a; border:1px solid #3d4754; width:10px; border-radius:5px; }
            QSlider::handle:vertical { background:#d7e0ec; border:1px solid #ffffff; height:24px; width:28px; margin:0 -9px; border-radius:5px; }
            QSlider::handle:vertical:hover { background:#70c0ff; }
            QProgressBar#vuMeter { background:#11151a; border:1px solid #333c47; border-radius:3px; width:7px; }
            QProgressBar#vuMeter::chunk { background:#36d399; border-radius:2px; }
        """
        self.setStyleSheet(self._base_stylesheet)

        root = QVBoxLayout(self)
        root.setContentsMargins(4, 5, 4, 4)
        root.setSpacing(3)

        channel_header = QLabel(f"CHANNEL {index + 1:02d}")
        channel_header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        channel_header.setStyleSheet("color:#9ba8b8; font-size:9px; font-weight:800; letter-spacing:1px;")
        root.addWidget(channel_header)

        self.knob = RotaryKnob()
        knob_row = QHBoxLayout()
        knob_row.setContentsMargins(0, 0, 0, 0)
        knob_row.addStretch(1)
        knob_row.addWidget(self.knob)
        knob_row.addStretch(1)
        root.addLayout(knob_row)

        self.knob_value = QLabel("+0.0 dB")
        self.knob_value.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.knob_value.setStyleSheet("font-weight:700; color:#dce7f3; font-size:11px;")
        root.addWidget(self.knob_value)
        self.knob_map_btn = QPushButton("APRENDER KNOB")
        self.knob_map_btn.setObjectName("learnSmall")
        self.knob_map_btn.setToolTip("Associar o encoder físico deste canal. Gire o knob quando o app pedir.")
        self.knob_map_btn.clicked.connect(lambda: self.learnRequested.emit("knob", self.index))
        root.addWidget(self.knob_map_btn)
        self.knob.valueChanged.connect(lambda value: self.knobChanged.emit(self.index, value))
        self.knob.doubleClicked.connect(lambda: self.knobResetRequested.emit(self.index))

        self.name_edit = QLineEdit(f"Canal {index + 1}")
        self.name_edit.setObjectName("channelName")
        self.name_edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.name_edit.setMaxLength(48)
        self.name_edit.setPlaceholderText("Nome do canal")
        self.name_edit.setToolTip("Clique e renomeie este canal. O nome é salvo no perfil/banco ativo.")
        self.name_edit.editingFinished.connect(self._commit_name)
        name_row = QHBoxLayout()
        name_row.setContentsMargins(0, 0, 0, 0)
        name_row.setSpacing(3)
        name_row.addWidget(self.name_edit, 1)
        self.color_button = QPushButton("●")
        self.color_button.setObjectName("channelColor")
        self.color_button.setFixedSize(24, 25)
        self.color_button.setToolTip("Personalizar a cor deste canal")
        self.color_button.clicked.connect(lambda: self.colorChangeRequested.emit(self.index))
        name_row.addWidget(self.color_button)
        root.addLayout(name_row)

        self.target = QComboBox()
        self.target.setObjectName("appTarget")
        self.target.setMinimumWidth(0)
        self.target.setToolTip("Destino do fader: volume master ou sessão de áudio de um aplicativo.")
        self.target.currentIndexChanged.connect(self._target_changed)
        root.addWidget(self.target)

        controls = QHBoxLayout()
        controls.setContentsMargins(0, 0, 0, 0)
        controls.setSpacing(4)
        self.meter = LedDbMeter()
        self.meter.set_color(self._channel_color)
        controls.addWidget(self.meter)

        self.fader = QSlider(Qt.Orientation.Vertical)
        self.fader.setRange(0, 100)
        self.fader.setValue(75)
        self.fader.setInvertedAppearance(False)  # 0 bottom, 100 top: same direction as hardware.
        self.fader.setMinimumHeight(160)
        self.fader.setFixedWidth(32)
        self.fader.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        self.fader.setTickPosition(QSlider.TickPosition.NoTicks)
        self.fader.valueChanged.connect(lambda value: self.faderChanged.emit(self.index, value))
        self.fader.setToolTip("Fader vertical: 0% embaixo, 100% em cima.")
        controls.addWidget(self.fader, 1)

        button_col = QVBoxLayout()
        button_col.setContentsMargins(0, 7, 0, 7)
        button_col.setSpacing(4)
        self.hardware_buttons: dict[str, QPushButton] = {}
        for glyph, suffix, tooltip in self.BUTTONS:
            control_id = f"ch{index + 1}_{suffix}"
            btn = QPushButton(glyph)
            btn.setObjectName("hardwareKey")
            btn.setFixedSize(26, 26)
            btn.setToolTip(f"{tooltip}. Clique para executar; clique direito abre o assistente simples de ação/MIDI.")
            btn.clicked.connect(lambda _checked=False, cid=control_id: self.buttonActivated.emit(cid))
            btn.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            btn.customContextMenuRequested.connect(lambda pos, cid=control_id, b=btn: self.buttonContextRequested.emit(cid, b.mapToGlobal(pos)))
            self.hardware_buttons[suffix] = btn
            button_col.addWidget(btn)
        button_col.addStretch(1)
        controls.addLayout(button_col)
        root.addLayout(controls, 1)

        self.fader_value = QLabel("75%  ·  -2.5 dB")
        self.fader_value.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.fader_value.setStyleSheet("color:#b7c3d2; font-size:10px; font-weight:700;")
        root.addWidget(self.fader_value)
        self.fader_map_btn = QPushButton("APRENDER FADER")
        self.fader_map_btn.setObjectName("learnSmall")
        self.fader_map_btn.setToolTip("Associar o fader físico deste canal. Mova o fader quando o app pedir.")
        self.fader_map_btn.clicked.connect(lambda: self.learnRequested.emit("fader", self.index))
        root.addWidget(self.fader_map_btn)

    def set_theme_palette(self, palette: dict[str, str], compact: bool = False) -> None:
        self._theme_palette = dict(palette)
        self._compact = bool(compact)
        self._apply_channel_style()
        self.knob.set_theme_colors(self._channel_color, palette["track"])
        self.knob.set_compact(compact)
        self.layout().setContentsMargins(3 if compact else 4, 3 if compact else 5, 3 if compact else 4, 3 if compact else 4)
        self.layout().setSpacing(2 if compact else 3)
        if compact:
            self.fader.setMinimumHeight(120)
            self.meter.setMinimumHeight(120)
        else:
            self.fader.setMinimumHeight(160)
            self.meter.setMinimumHeight(160)

    def set_adaptive_width(self, compact: bool, minimum_width: int | None = None) -> None:
        """Reduce channel-strip chrome before content can be clipped horizontally."""
        compact = bool(compact)
        width = max(90, min(116, int(minimum_width if minimum_width is not None else (108 if compact else 116))))
        if compact == getattr(self, "_adaptive_compact", None) and width == getattr(self, "_adaptive_min_width", None):
            return
        self._adaptive_compact = compact
        self._adaptive_min_width = width
        self.setMinimumWidth(width)
        self.fader.setFixedWidth(27 if compact else 32)
        self.meter.set_compact(compact)
        self.color_button.setFixedSize(20 if compact else 24, 22 if compact else 25)
        for button in self.hardware_buttons.values():
            button.setFixedSize(22 if compact else 26, 22 if compact else 26)
        for button in (self.knob_map_btn, self.fader_map_btn):
            button.setText("APRENDER" if compact else ("APRENDER KNOB" if button is self.knob_map_btn else "APRENDER FADER"))
            button.setToolTip("Associar encoder físico deste canal" if button is self.knob_map_btn else "Associar fader físico deste canal")
        self.knob.set_compact(compact)
        if compact:
            self.fader.setMinimumHeight(120)
            self.meter.setMinimumHeight(120)
            self.layout().setContentsMargins(2, 3, 2, 3)
            self.layout().setSpacing(2)
        else:
            self.fader.setMinimumHeight(160)
            self.meter.setMinimumHeight(160)
            self.layout().setContentsMargins(4, 5, 4, 4)
            self.layout().setSpacing(3)
        self.updateGeometry()

    def set_channel_color(self, color: str) -> None:
        parsed = QColor(color)
        if not parsed.isValid():
            return
        self._channel_color = parsed.name().lower()
        self.meter.set_color(self._channel_color)
        self.knob.set_theme_colors(self._channel_color, self._theme_palette["track"] if self._theme_palette else "#3b424d")
        self._apply_channel_style()

    def _apply_channel_style(self) -> None:
        palette = self._theme_palette or {"panel":"#20242b", "border":"#343b46", "accent":"#58a6ff", "input":"#171b21", "accent_dark":"#1d4ed8", "accent_border":"#60a5fa", "text":"#d7e0ec", "window":"#11151a", "success":"#36d399", "track":"#3b424d"}
        replacements = {
            "#20242b": palette["panel"], "#343b46": palette["border"],
            "#58a6ff": palette["accent"], "#171b21": palette["input"],
            "#39424f": palette["border"], "#1d4ed8": palette["accent_dark"],
            "#60a5fa": palette["accent_border"], "#d7e0ec": palette["accent"],
            "#ffffff": palette["accent_border"], "#70c0ff": palette["accent"],
            "#11151a": palette["window"], "#3d4754": palette["border"],
            "#36d399": palette["success"],
        }
        style = self._base_stylesheet
        for old, value in replacements.items():
            style = style.replace(old, value)
        style += f"\nQFrame#channelStrip {{ border-top:3px solid {self._channel_color}; }}\nQSlider::handle:vertical {{ background:{self._channel_color}; }}\nQPushButton#channelColor {{ color:{self._channel_color}; border:1px solid {self._channel_color}; background:{palette['input']}; font-size:18px; padding:0; }}\n"
        self.setStyleSheet(style)
        self.color_button.setToolTip(f"Cor deste canal: {self._channel_color.upper()} · clique para alterar")

    def _commit_name(self) -> None:
        if not self._loading:
            self.nameCommitted.emit(self.index, self.name_edit.text().strip() or f"Canal {self.index + 1}")

    def _target_changed(self, _index: int) -> None:
        if not self._loading:
            self.targetChanged.emit(self.index, str(self.target.currentData() or ""))

    def set_name(self, name: str) -> None:
        self._loading = True
        self.name_edit.setText(name)
        self._loading = False

    def set_target_items(self, items: list[tuple[str, str]], selected: str) -> None:
        self._loading = True
        self.target.blockSignals(True)
        self.target.clear()
        for label, data in items:
            self.target.addItem(label, data)
        found = self.target.findData(selected)
        if found < 0 and selected:
            self.target.addItem(f"{selected} (sem sessão ativa)", selected)
            found = self.target.findData(selected)
        self.target.setCurrentIndex(found if found >= 0 else 1 if self.target.count() > 1 else 0)
        self.target.blockSignals(False)
        self._loading = False

    def target_value(self) -> str:
        return str(self.target.currentData() or "")

    def set_fader_value(self, value: int, label: str | None = None, meter: int | None = None) -> None:
        self._loading = True
        self.fader.blockSignals(True)
        self.fader.setValue(max(0, min(100, int(value))))
        self.fader.blockSignals(False)
        self._loading = False
        self.fader_value.setText(label or f"{int(value)}%")
        meter_percent = max(0, min(100, int(value if meter is None else meter)))
        db = -60.0 if meter_percent <= 0 else max(-60.0, min(0.0, 20.0 * math.log10(meter_percent / 100.0)))
        self.meter.set_db(db, actual_peak=False)

    def set_meter_db(self, db_value: float | None, actual_peak: bool = False) -> None:
        self.meter.set_db(db_value, actual_peak)

    def set_meter_percent(self, percent: float | None, label: str = "Brilho") -> None:
        self.meter.set_percent(percent, label)

    def set_knob_value(self, value: int, minimum: int, maximum: int, label: str) -> None:
        self._loading = True
        self.knob.setRange(minimum, maximum)
        self.knob.setValue(value, emit=False)
        self._loading = False
        self.knob_value.setText(label)

    def set_mapping_text(self, kind: str, text: str) -> None:
        if kind == "fader":
            self.fader_map_btn.setText(text)
        else:
            self.knob_map_btn.setText(text)

    def set_button_mapped(self, suffix: str, mapped: bool) -> None:
        button = self.hardware_buttons[suffix]
        button.setProperty("mapped", bool(mapped))
        button.setStyleSheet("background:#193b33; border-color:#2c9d78;" if mapped else "")

    def set_selected(self, selected: bool) -> None:
        self.setProperty("selected", bool(selected))
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()


class HudOverlay(QWidget):
    """Small, always-on-top OSD that fades away after hardware input."""

    def __init__(self, parent=None) -> None:
        flags = Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint
        super().__init__(parent, flags)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setFixedSize(310, 98)
        self._effect = QGraphicsOpacityEffect(self)
        self._effect.setOpacity(1.0)
        self.setGraphicsEffect(self._effect)
        self._animation = QPropertyAnimation(self._effect, b"opacity", self)
        self._animation.setDuration(320)
        self._animation.setStartValue(1.0)
        self._animation.setEndValue(0.0)
        self._animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._animation.finished.connect(self.hide)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._fade_out)
        self._enabled = True
        self._position = "bottom_right"
        self._duration_ms = 1180
        self._last_event_id: tuple[str, str] | None = None
        self._last_timer_restart = 0.0

        self._base_stylesheet = """
            QWidget { background:transparent; }
            QFrame#hudCard { background:rgba(18,22,29,235); border:1px solid rgba(57,180,136,190); border-radius:12px; }
            QLabel#hudTitle { color:#a9c9e8; font-size:10px; font-weight:800; letter-spacing:1px; background:transparent; }
            QLabel#hudName { color:#f5f7fb; font-size:14px; font-weight:700; background:transparent; }
            QLabel#hudValue { color:#79c3ff; font-size:22px; font-weight:800; background:transparent; }
            QProgressBar { background:#29313b; border:0; border-radius:3px; height:5px; max-height:5px; }
            QProgressBar::chunk { background:#50b2ff; border-radius:3px; }
        """
        self.setStyleSheet(self._base_stylesheet)
        card = QFrame(self)
        card.setObjectName("hudCard")
        row = QHBoxLayout(card)
        row.setContentsMargins(13, 10, 13, 10)
        row.setSpacing(10)
        left = QVBoxLayout()
        left.setSpacing(3)
        self.kicker = QLabel("SMC MIXER · HARDWARE INPUT")
        self.kicker.setObjectName("hudTitle")
        self.name = QLabel("Canal 1")
        self.name.setObjectName("hudName")
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.bar.setTextVisible(False)
        left.addWidget(self.kicker)
        left.addWidget(self.name)
        left.addWidget(self.bar)
        row.addLayout(left, 1)
        self.value = QLabel("0%")
        self.value.setObjectName("hudValue")
        self.value.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        row.addWidget(self.value)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(card)

    def set_theme_palette(self, palette: dict[str, str]) -> None:
        accent = QColor(palette["accent"])
        accent_rgba = f"rgba({accent.red()},{accent.green()},{accent.blue()},190)"
        style = self._base_stylesheet.replace("rgba(57,180,136,190)", accent_rgba)
        style = style.replace("#79c3ff", palette["accent"]).replace("#50b2ff", palette["accent"])
        style = style.replace("#a9c9e8", palette["muted"])
        self.setStyleSheet(style)

    def set_options(self, enabled: bool | None = None, position: str | None = None, duration_ms: int | None = None) -> None:
        if enabled is not None:
            self._enabled = bool(enabled)
        if position in {"bottom_right", "bottom_left", "top_right", "top_left"}:
            self._position = str(position)
        if duration_ms is not None:
            self._duration_ms = max(700, min(5000, int(duration_ms)))
        if not self._enabled:
            self._timer.stop()
            self._animation.stop()
            self.hide()

    def show_event(self, name: str, value_text: str, value_percent: int | None = None, detail: str = "HARDWARE INPUT") -> None:
        if not self._enabled:
            return
        event_id = (str(name), str(detail))
        now = time.monotonic()
        same_visible_event = self.isVisible() and self._last_event_id == event_id
        # Continuous fader updates reuse the existing window instead of restarting
        # animations/raising the popup on every MIDI packet. Buttons/actions still
        # get a full immediate presentation.
        self.kicker.setText(f"SMC MIXER · {detail.upper()}")
        self.name.setText(name)
        self.value.setText(value_text)
        self.bar.setValue(max(0, min(100, int(value_percent or 0))))
        if same_visible_event:
            if now - self._last_timer_restart >= 0.07:
                self._animation.stop()
                self._effect.setOpacity(1.0)
                self._timer.start(self._duration_ms)
                self._last_timer_restart = now
            return
        self._animation.stop()
        self._timer.stop()
        self._effect.setOpacity(1.0)
        screen = QApplication.primaryScreen()
        if screen is not None:
            area = screen.availableGeometry()
            margin = 22
            x = area.left() + margin if self._position.endswith("left") else area.right() - self.width() - margin
            y = area.top() + margin if self._position.startswith("top") else area.bottom() - self.height() - margin
            self.move(x, y)
        self._last_event_id = event_id
        self._last_timer_restart = now
        self.show()
        self.raise_()
        self._timer.start(self._duration_ms)

    def _fade_out(self) -> None:
        self._animation.start()
