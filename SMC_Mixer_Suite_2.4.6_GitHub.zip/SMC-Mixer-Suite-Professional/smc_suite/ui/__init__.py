"""Qt user interface package."""
