"""EQ band layouts, factory presets and frequency-aware preset interpolation.

The app writes Equalizer APO text filters; it does not pretend that Pycaw itself
processes audio. Frequencies are kept as floats in Hz and gains as dB.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable

REFERENCE_FREQUENCIES = [63.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 8000.0, 16000.0]
DEFAULT_FREQUENCIES: dict[str, list[float]] = {
    "3": [100.0, 1000.0, 10000.0],
    "5": [60.0, 250.0, 1000.0, 4000.0, 12000.0],
    "8": REFERENCE_FREQUENCIES.copy(),
}
BAND_LABELS: dict[str, list[str]] = {
    "3": ["GRAVES", "MÉDIOS", "AGUDOS"],
    "5": ["SUB / GRAVE", "MÉDIO-GRAVE", "MÉDIOS", "PRESENÇA", "AGUDOS"],
    "8": ["SUB-GRAVE", "GRAVES", "MÉDIO-GRAVE", "MÉDIOS", "MÉDIO-ALTOS", "PRESENÇA", "AGUDOS", "BRILHO"],
}

# Curves are anchored to REFERENCE_FREQUENCIES and interpolated in log-frequency
# for 3- and 5-band modes or for customized band-center frequencies.
FACTORY_PRESETS: dict[str, list[float]] = {
    "Flat / Neutro":                 [0, 0, 0, 0, 0, 0, 0, 0],
    "Música (Vocal Booster)":        [-1.0, 0.0, 0.5, 1.0, 2.0, 2.0, 1.0, 0.5],
    "Cinema / Filmes":               [3.5, 3.0, 1.0, 0.0, 1.5, 2.0, 2.5, 1.5],
    "Voz / Podcast":                 [-6.0, -3.0, -1.0, 1.0, 3.0, 3.0, 1.5, 0.0],
    "Games / FPS":                   [-2.0, -1.0, 0.0, 1.5, 2.5, 3.0, 3.5, 2.0],
    "Rock / Metal":                  [3.0, 2.0, 1.0, -1.0, -0.5, 1.5, 3.0, 2.5],
    "Pop / Eletrônica":              [4.0, 3.0, 1.5, 0.0, 1.0, 2.0, 3.0, 3.5],
    "Acoustic / Instrumental":       [1.0, 0.5, 0.0, 1.5, 2.0, 1.5, 0.5, -0.5],
    "Bass Boost":                    [6.0, 5.0, 3.0, 1.0, 0.0, 0.0, 0.0, -0.5],
    "Night Mode":                    [2.0, 1.5, 0.5, 0.0, 1.0, 1.0, 0.0, -1.0],
}


def normalize_mode(mode: object) -> str:
    text = str(mode)
    return text if text in DEFAULT_FREQUENCIES else "8"


def clamp_gain(value: float) -> float:
    return round(max(-12.0, min(12.0, float(value))), 1)


def sanitize_frequencies(values: Iterable[object], mode: object) -> list[float]:
    """Return a bounded, strictly increasing sequence of band-center frequencies.

    An equalizer remains intuitive only if the displayed bands stay ordered from
    low to high. Bad/old JSON values are repaired rather than allowed to create
    overlapping or reversed controls.
    """
    key = normalize_mode(mode)
    defaults = DEFAULT_FREQUENCIES[key]
    try:
        items = list(values)
    except TypeError:
        items = []
    cleaned: list[float] = []
    for idx, default in enumerate(defaults):
        try:
            freq = float(items[idx])
        except (IndexError, TypeError, ValueError):
            freq = default
        freq = round(max(20.0, min(20000.0, freq)), 1)
        if cleaned and freq <= cleaned[-1]:
            freq = min(20000.0, round(cleaned[-1] + 1.0, 1))
        cleaned.append(freq)
    # If malformed data pushed the last entries beyond the audible range, repair
    # from the right while preserving the nearest valid frequencies when possible.
    if cleaned and cleaned[-1] > 20000.0:
        cleaned[-1] = 20000.0
    for idx in range(len(cleaned) - 2, -1, -1):
        if cleaned[idx] >= cleaned[idx + 1]:
            cleaned[idx] = max(20.0, round(cleaned[idx + 1] - 1.0, 1))
    return cleaned


def gains_by_mode_from_reference(reference_gains: Iterable[float], frequency_map: dict[str, Iterable[float]] | None = None) -> dict[str, list[float]]:
    """Project an 8-point reference curve into all supported band layouts."""
    reference = [clamp_gain(v) for v in list(reference_gains)[:8]]
    reference += [0.0] * (8 - len(reference))
    frequencies = frequency_map or DEFAULT_FREQUENCIES
    return {
        mode: preset_gains_for_frequencies(reference, sanitize_frequencies(frequencies.get(mode, DEFAULT_FREQUENCIES[mode]), mode))
        for mode in DEFAULT_FREQUENCIES
    }


def interpolate_curve(source_freqs: Iterable[float], source_gains: Iterable[float], target_freqs: Iterable[float]) -> list[float]:
    """Interpolate an EQ curve on a logarithmic frequency axis."""
    points = []
    for freq, gain in zip(source_freqs, source_gains):
        f = max(20.0, min(20000.0, float(freq)))
        points.append((math.log10(f), clamp_gain(float(gain))))
    points.sort(key=lambda item: item[0])
    if not points:
        return [0.0 for _ in target_freqs]
    # Merge duplicate frequency centers to avoid division by zero.
    unique: list[tuple[float, float]] = []
    for point in points:
        if unique and abs(point[0] - unique[-1][0]) < 1e-9:
            unique[-1] = (unique[-1][0], point[1])
        else:
            unique.append(point)
    if len(unique) == 1:
        return [unique[0][1] for _ in target_freqs]
    result = []
    for target in target_freqs:
        x = math.log10(max(20.0, min(20000.0, float(target))))
        if x <= unique[0][0]:
            result.append(unique[0][1]); continue
        if x >= unique[-1][0]:
            result.append(unique[-1][1]); continue
        for i in range(1, len(unique)):
            x1, y1 = unique[i - 1]
            x2, y2 = unique[i]
            if x1 <= x <= x2:
                t = (x - x1) / (x2 - x1)
                result.append(clamp_gain(y1 + (y2 - y1) * t))
                break
    return result


def preset_gains_for_frequencies(preset_gains: Iterable[float], target_freqs: Iterable[float]) -> list[float]:
    gains = list(preset_gains)
    if len(gains) < len(REFERENCE_FREQUENCIES):
        gains += [0.0] * (len(REFERENCE_FREQUENCIES) - len(gains))
    return interpolate_curve(REFERENCE_FREQUENCIES, gains[:8], target_freqs)


def gains_to_reference(freqs: Iterable[float], gains: Iterable[float]) -> list[float]:
    return interpolate_curve(freqs, gains, REFERENCE_FREQUENCIES)


def frequency_label(freq: float) -> str:
    f = float(freq)
    if f >= 1000 and abs(f / 1000 - round(f / 1000)) < 0.001:
        return f"{round(f / 1000):d} kHz"
    if f >= 1000:
        return f"{f / 1000:.1f} kHz"
    return f"{f:g} Hz"
