"""MIDI route validation helpers.

A physical MIDI key must control exactly one logical input. Duplicate routes can
make a channel-select button move a volume fader, or trigger two unrelated actions.
This module is deliberately UI-independent so the safety rule is testable.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any

from smc_suite.hardware import BUTTON_SPEC_BY_ID


def _button_label(control_id: str) -> str:
    spec = BUTTON_SPEC_BY_ID.get(control_id)
    if spec is None:
        return f"Botão {control_id}"
    if spec.channel is not None:
        return f"Canal {spec.channel + 1} · {spec.key or spec.label}"
    return str(spec.key or spec.label or control_id)


def midi_route_owners(profile: dict[str, Any], key: str) -> list[tuple[str, str, int | str]]:
    """Return every route using *key*: (kind, display label, reference)."""
    key = str(key or "")
    if not key:
        return []
    owners: list[tuple[str, str, int | str]] = []
    for index, mapped in enumerate(profile.get("fader_midi", [])):
        if mapped and str(mapped) == key:
            owners.append(("fader", f"Fader {index + 1}", index))
    for index, mapped in enumerate(profile.get("knob_midi", [])):
        if mapped and str(mapped) == key:
            owners.append(("knob", f"Knob {index + 1}", index))
    rows = profile.get("button_actions", {})
    if isinstance(rows, dict):
        for control_id, row in rows.items():
            if isinstance(row, dict) and row.get("midi") and str(row["midi"]) == key:
                owners.append(("button", _button_label(str(control_id)), str(control_id)))
    return owners


def analog_route_owners(profile: dict[str, Any], key: str) -> list[tuple[str, str, int | str]]:
    """Return only fader/knob routes using a MIDI key."""
    return [owner for owner in midi_route_owners(profile, key) if owner[0] in {"fader", "knob"}]


def repair_duplicate_midi_routes(profile: dict[str, Any]) -> list[str]:
    """Clear every route sharing a MIDI key with another route.

    Clearing *all* conflicting routes is intentional: the data cannot tell which
    mapping was incorrect, so retaining one could keep a physical button moving a
    fader. Action choices and channel destinations are preserved; only the ambiguous
    MIDI links are removed so they can be relearned explicitly.
    """
    route_keys: dict[str, list[tuple[str, int | str]]] = defaultdict(list)
    for index, mapped in enumerate(profile.get("fader_midi", [])):
        if mapped:
            route_keys[str(mapped)].append(("fader", index))
    for index, mapped in enumerate(profile.get("knob_midi", [])):
        if mapped:
            route_keys[str(mapped)].append(("knob", index))
    rows = profile.get("button_actions", {})
    if isinstance(rows, dict):
        for control_id, row in rows.items():
            if isinstance(row, dict) and row.get("midi"):
                route_keys[str(row["midi"])].append(("button", str(control_id)))

    conflicts = {key: routes for key, routes in route_keys.items() if len(routes) > 1}
    if not conflicts:
        return []

    warnings: list[str] = []
    faders = profile.get("fader_midi", [])
    knobs = profile.get("knob_midi", [])
    for key, routes in conflicts.items():
        labels: list[str] = []
        for kind, ref in routes:
            if kind == "fader":
                index = int(ref)
                if index < len(faders) and str(faders[index] or "") == key:
                    faders[index] = None
                    labels.append(f"Fader {index + 1}")
            elif kind == "knob":
                index = int(ref)
                if index < len(knobs) and str(knobs[index] or "") == key:
                    knobs[index] = None
                    labels.append(f"Knob {index + 1}")
            else:
                control_id = str(ref)
                row = rows.get(control_id) if isinstance(rows, dict) else None
                if isinstance(row, dict) and str(row.get("midi") or "") == key:
                    row["midi"] = None
                    labels.append(_button_label(control_id))
        channel_text = ""
        try:
            kind, channel, number = key.split(":", 2)
            channel_text = f" ({kind.upper()} {number}, canal {int(channel) + 1})"
        except (ValueError, TypeError):
            channel_text = f" ({key})"
        has_analog = any(kind in {"fader", "knob"} for kind, _ref in routes)
        has_button = any(kind == "button" for kind, _ref in routes)
        if has_analog and has_button:
            explanation = (
                "As associações ambíguas foram removidas. No MidiSuite da M-VAVE, configure o botão físico como Note "
                "com nota exclusiva; mantenha faders/knobs em CC. Não é possível distinguir controles físicos que enviam a mesma mensagem CC."
            )
        else:
            explanation = "As associações físicas ambíguas foram removidas; configure esses controles novamente."
        warnings.append(f"Entrada MIDI repetida{channel_text}: {', '.join(labels)}. {explanation}")
    return warnings
