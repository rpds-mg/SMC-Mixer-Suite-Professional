"""Safe, idempotent integration of the app's EQ file with Equalizer APO."""
from __future__ import annotations

import os
import re
import shutil
from datetime import datetime
from pathlib import Path

from smc_suite.eqapo import include_line


def candidate_config_paths(environ: dict[str, str] | None = None) -> list[Path]:
    env = os.environ if environ is None else environ
    bases = [env.get("ProgramW6432", ""), env.get("ProgramFiles", ""), env.get("ProgramFiles(x86)", "")]
    bases.extend([r"C:\Program Files", r"C:\Program Files (x86)"])
    result: list[Path] = []
    seen: set[str] = set()
    for base in bases:
        if not base:
            continue
        path = Path(base) / "EqualizerAPO" / "config" / "config.txt"
        key = os.path.normcase(str(path))
        if key not in seen:
            seen.add(key)
            result.append(path)
    return result


def find_equalizer_apo_config(environ: dict[str, str] | None = None) -> Path | None:
    for path in candidate_config_paths(environ):
        if path.is_file():
            return path
    return None


def _norm_path_text(value: str, base_dir: str | Path | None = None) -> str:
    """Normalize absolute or config-relative Include paths for comparison."""
    value = os.path.expandvars(value.strip().strip('"').strip("'"))
    try:
        candidate = Path(value).expanduser()
        base = Path(base_dir).expanduser() if base_dir is not None else None
        if base is not None and not candidate.is_absolute():
            candidate = base / candidate
        normalized = os.path.normcase(os.path.abspath(str(candidate)))
        return normalized.replace("\\", "/").casefold()
    except (OSError, ValueError):
        return value.replace("\\", "/").casefold()


def include_exists(config_text: str, filter_path: str | Path, config_dir: str | Path | None = None) -> bool:
    wanted = _norm_path_text(str(filter_path), config_dir)
    for line in config_text.splitlines():
        match = re.match(r"^\s*include\s*:\s*(.*?)\s*$", line, flags=re.IGNORECASE)
        if match and _norm_path_text(match.group(1), config_dir) == wanted:
            return True
    return False


def ensure_include_text(
    config_text: str,
    filter_path: str | Path,
    remove_paths: tuple[str | Path, ...] | list[str | Path] = (),
    config_dir: str | Path | None = None,
) -> tuple[str, bool]:
    """Ensure one live Include at the top-level of config.txt.

    Include placement matters: placing it after a Device:/Channel: section can
    make the EQ inherit a device/channel scope and appear to do nothing on the
    user's playback endpoint. We therefore move this application's Include to
    the top of config.txt (before any scoped commands), remove duplicates and
    obsolete references, and prefer a config-relative filename when possible.
    """
    wanted = _norm_path_text(str(filter_path), config_dir)
    obsolete = {_norm_path_text(str(path), config_dir) for path in remove_paths}
    obsolete.discard(wanted)

    source_lines = config_text.splitlines()
    lines: list[str] = []
    marker = "# SMC Mixer Suite - equalizador global"
    for line in source_lines:
        if line.strip().casefold() == marker.casefold():
            continue
        match = re.match(r"^\s*include\s*:\s*(.*?)\s*$", line, flags=re.IGNORECASE)
        if match:
            existing = _norm_path_text(match.group(1), config_dir)
            if existing in obsolete or existing == wanted:
                continue
        lines.append(line)

    block = [marker, include_line(str(filter_path), config_dir)]
    updated = "\r\n".join(block + lines).rstrip("\r\n") + "\r\n"
    canonical_original = "\r\n".join(source_lines).rstrip("\r\n") + "\r\n" if source_lines else ""
    changed = updated != canonical_original
    if not changed:
        return config_text, False
    return updated, True

def configure_include_file(config_path: str | Path, filter_path: str | Path, remove_paths: tuple[str | Path, ...] | list[str | Path] = ()) -> Path | None:
    """Back up config.txt, then add the EQ Include. Returns backup or None if unchanged."""
    config = Path(config_path).expanduser().resolve()
    filter_file = Path(filter_path).expanduser().resolve()
    if not config.is_file():
        raise FileNotFoundError(f"Arquivo de configuração do Equalizer APO não encontrado: {config}")
    if not filter_file.is_file():
        raise FileNotFoundError(f"Arquivo de filtros do SMC Mixer Suite não encontrado: {filter_file}")
    raw = config.read_bytes()
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("cp1252")
    updated, changed = ensure_include_text(text, filter_file, remove_paths=remove_paths, config_dir=config.parent)
    if not changed:
        return None
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = config.with_name(f"{config.name}.smc-backup-{stamp}")
    shutil.copy2(config, backup)
    temp = config.with_name(config.name + ".smc-tmp")
    try:
        temp.write_text(updated, encoding="utf-8", newline="")
        os.replace(temp, config)
    except Exception:
        try:
            if backup.exists():
                shutil.copy2(backup, config)
        finally:
            try:
                temp.unlink(missing_ok=True)
            except Exception:
                pass
        raise
    return backup


ELEVATED_POWERSHELL_SCRIPT = r'''param(
    [Parameter(Mandatory=$true)][string]$ConfigPath,
    [Parameter(Mandatory=$true)][string]$SourceFilterPath,
    [Parameter(Mandatory=$true)][string]$TargetFilterPath
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
function Normalize-Path([string]$Value, [string]$BaseDir = $null) {
    $v = [Environment]::ExpandEnvironmentVariables($Value.Trim().Trim('"').Trim("'").Replace('/', '\'))
    try {
        if ($BaseDir -and -not [System.IO.Path]::IsPathRooted($v)) { $v = Join-Path $BaseDir $v }
        return [System.IO.Path]::GetFullPath($v).Replace('\','/').ToLowerInvariant()
    } catch { return $v.Replace('\','/').ToLowerInvariant() }
}
try {
    if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) { throw "config.txt não encontrado: $ConfigPath" }
    if (-not (Test-Path -LiteralPath $SourceFilterPath -PathType Leaf)) { throw "Arquivo de filtros de origem não encontrado: $SourceFilterPath" }
    $config = [System.IO.Path]::GetFullPath($ConfigPath)
    $source = [System.IO.Path]::GetFullPath($SourceFilterPath)
    $target = [System.IO.Path]::GetFullPath($TargetFilterPath)
    $targetDir = [System.IO.Path]::GetDirectoryName($target)
    if (-not (Test-Path -LiteralPath $targetDir -PathType Container)) { throw "Pasta do Equalizer APO não encontrada: $targetDir" }

    # The active Include lives beside config.txt so APO can notice filter changes.
    Copy-Item -LiteralPath $source -Destination $target -Force
    $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    $grant = "${identity}:(M)"
    & icacls.exe $target /grant $grant /C | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Não foi possível conceder permissão de atualização ao arquivo de filtros ($LASTEXITCODE)." }

    $text = [System.IO.File]::ReadAllText($config)
    $wanted = Normalize-Path $target $targetDir
    $old = Normalize-Path $source $targetDir
    $lines = New-Object 'System.Collections.Generic.List[string]'
    foreach ($line in ($text -split "`r?`n")) {
        if ($line.Trim() -eq '# SMC Mixer Suite - equalizador global') { continue }
        if ($line -match '^\s*Include\s*:\s*(.*?)\s*$') {
            $included = Normalize-Path $Matches[1] $targetDir
            # Remove old external references and every copy of our current target;
            # a single canonical, relative Include will be inserted at the top.
            if (($included -eq $old -and $old -ne $wanted) -or ($included -eq $wanted)) { continue }
        }
        $lines.Add($line)
    }
    # Keep the Include before any Device:/Channel: scope, using a relative filename.
    $prefix = @('# SMC Mixer Suite - equalizador global', 'Include: SMC_Mixer_Suite_filters.txt')
    $updatedLines = New-Object 'System.Collections.Generic.List[string]'
    foreach ($line in $prefix) { $updatedLines.Add($line) }
    foreach ($line in $lines) { $updatedLines.Add($line) }
    $updated = [string]::Join("`r`n", $updatedLines).TrimEnd([char[]]@(13, 10)) + "`r`n"
    $canonicalCurrent = [string]::Join("`r`n", ($text -split "`r?`n")).TrimEnd([char[]]@(13, 10)) + "`r`n"
    if ($updated -ne $canonicalCurrent) {
        $backup = "$config.smc-backup-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        Copy-Item -LiteralPath $config -Destination $backup
        $encoding = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($config, $updated, $encoding)
        $details = "Include atualizado no início do arquivo. Backup: $backup"
    } else {
        $details = 'O Include já estava configurado corretamente no início do arquivo.'
    }
    [System.Windows.Forms.MessageBox]::Show("Equalizer APO vinculado ao SMC Mixer Suite.`r`n`r`n$details`r`n`r`nO arquivo de filtros está na pasta config do APO e recebe permissão de alteração apenas neste arquivo. Se o som não mudar, confirme o dispositivo habilitado no Configuration Editor.",'SMC Mixer Suite') | Out-Null
    exit 0
} catch {
    [System.Windows.Forms.MessageBox]::Show("Não foi possível configurar o Equalizer APO:`r`n`r`n$($_.Exception.Message)",'SMC Mixer Suite') | Out-Null
    exit 1
}
'''
