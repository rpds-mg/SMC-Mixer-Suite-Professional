"""Theme catalog and stylesheet helpers for SMC Mixer Suite."""
from __future__ import annotations

from copy import deepcopy
import re

THEMES: dict[str, dict[str, str]] = {
    "Graphite Studio (3.2)": {
        # Matched to the graphite / muted-green treatment used by version 3.2.
        # This is deliberately a palette-only change: the 2.4.6 layout and
        # controls remain intact.
        "window": "#181a1d", "panel": "#22272b", "card": "#202428", "tab": "#22262a",
        "selected": "#30393e", "input": "#111417", "border": "#3b4349", "accent": "#39b488",
        "accent_dark": "#176f53", "accent_border": "#32a47b", "text": "#e9ecef", "muted": "#aeb7bf",
        "success": "#83d0aa", "warning": "#ffd68a", "danger": "#ff9e94", "track": "#303945",
    },
    "Midnight Purple": {
        "window": "#17151e", "panel": "#211d2b", "card": "#282235", "tab": "#2b2439",
        "selected": "#403251", "input": "#282235", "border": "#4a3f5e", "accent": "#b89aff",
        "accent_dark": "#7650be", "accent_border": "#9a78e8", "text": "#f0eafa", "muted": "#b4a8c8",
        "success": "#52d6a4", "warning": "#e4bd69", "danger": "#ffaaaa", "track": "#3b324a",
    },
    "Studio Green": {
        "window": "#151b19", "panel": "#1b2521", "card": "#202c27", "tab": "#202b26",
        "selected": "#2d4037", "input": "#202c27", "border": "#3b5147", "accent": "#62d6a4",
        "accent_dark": "#23845d", "accent_border": "#3da97e", "text": "#e7f4ed", "muted": "#9fb9ac",
        "success": "#62d6a4", "warning": "#dfbd69", "danger": "#ffb0a8", "track": "#304139",
    },
    "Amber Studio": {
        "window": "#1d1915", "panel": "#28221c", "card": "#30281f", "tab": "#30271e",
        "selected": "#493827", "input": "#30281f", "border": "#554330", "accent": "#f3b65c",
        "accent_dark": "#a9681b", "accent_border": "#d18d38", "text": "#fbf0e2", "muted": "#c2af98",
        "success": "#67cf9b", "warning": "#f3b65c", "danger": "#ffb0a8", "track": "#403428",
    },
    "Nord Frost": {
        "window": "#20262e", "panel": "#282f39", "card": "#303946", "tab": "#2b333e",
        "selected": "#3b4c5d", "input": "#252d37", "border": "#4b596b", "accent": "#88c0d0",
        "accent_dark": "#477f90", "accent_border": "#75aab9", "text": "#eceff4", "muted": "#b0bac8",
        "success": "#a3be8c", "warning": "#ebcb8b", "danger": "#bf616a", "track": "#394452",
    },
    "Ocean Blue": {
        "window": "#101a2a", "panel": "#15253a", "card": "#1c3048", "tab": "#182a40",
        "selected": "#244866", "input": "#172940", "border": "#34516d", "accent": "#38bdf8",
        "accent_dark": "#0369a1", "accent_border": "#0ea5e9", "text": "#e6f4ff", "muted": "#9eb9d4",
        "success": "#34d399", "warning": "#fbbf24", "danger": "#fb7185", "track": "#263b52",
    },
    "Monochrome": {
        "window": "#161616", "panel": "#202020", "card": "#292929", "tab": "#242424",
        "selected": "#3d3d3d", "input": "#222222", "border": "#4b4b4b", "accent": "#dedede",
        "accent_dark": "#777777", "accent_border": "#c0c0c0", "text": "#f5f5f5", "muted": "#b8b8b8",
        "success": "#8ed1a6", "warning": "#e5c07b", "danger": "#ff9d9d", "track": "#363636",
    },
    "Studio Light": {
        "window": "#f1f4f8", "panel": "#ffffff", "card": "#ffffff", "tab": "#e8edf3",
        "selected": "#dce7f3", "input": "#ffffff", "border": "#c6d0dc", "accent": "#086eb5",
        "accent_dark": "#075a93", "accent_border": "#086eb5", "text": "#172331", "muted": "#526274",
        "success": "#157347", "warning": "#916b00", "danger": "#b42318", "track": "#d7dee7", "mode": "light",
    },
    "High Contrast": {
        "window": "#080a0d", "panel": "#11151a", "card": "#171d24", "tab": "#171d24",
        "selected": "#25394a", "input": "#171d24", "border": "#647383", "accent": "#70c7ff",
        "accent_dark": "#0067a8", "accent_border": "#70c7ff", "text": "#ffffff", "muted": "#cad5df",
        "success": "#5ef0a8", "warning": "#ffe082", "danger": "#ff8c8c", "track": "#3b4651",
    },
}

DEFAULT_THEME = "Graphite Studio (3.2)"
DEFAULT_CUSTOM_ACCENT = ""


def resolve_palette(theme_name: str, custom_accent: str = "") -> dict[str, str]:
    """Return a safe copy of a palette, optionally overriding its accent color."""
    palette = deepcopy(THEMES.get(theme_name, THEMES[DEFAULT_THEME]))
    color = str(custom_accent or "").strip()
    if len(color) == 7 and color.startswith("#"):
        try:
            int(color[1:], 16)
            palette["accent"] = color.lower()
            palette["accent_border"] = color.lower()
        except ValueError:
            pass
    return palette


def build_stylesheet(base: str, palette: dict[str, str], compact: bool = False) -> str:
    """Replace the base stylesheet's semantic color tokens with palette colors."""
    replacements = {
        # Main application stylesheet tokens -> semantic palette roles.
        "#171a20": palette["window"], "#12151a": palette["window"], "#303844": palette["border"],
        "#303946": palette["border"], "#333c49": palette["border"], "#303844": palette["border"],
        "#1d222a": palette["panel"], "#1a1e25": palette["panel"], "#20242b": palette["panel"],
        "#202630": palette["input"], "#222731": palette["tab"], "#252d38": palette["tab"],
        "#252c36": palette["tab"], "#2a323e": palette["selected"], "#354354": palette["selected"],
        "#29313d": palette["selected"], "#303d4d": palette["selected"], "#202733": palette["panel"],
        "#303a48": palette["selected"], "#394453": palette["border"], "#424e5f": palette["border"],
        "#3e4a59": palette["border"], "#3c4858": palette["border"], "#39424f": palette["border"],
        "#323c49": palette["border"], "#3a4655": palette["border"], "#374352": palette["border"],
        "#48a9f8": palette["accent"], "#58a6ff": palette["accent"], "#70c0ff": palette["accent"],
        "#287ec2": palette["accent_dark"], "#147ac0": palette["accent_dark"], "#174d74": palette["accent_dark"],
        "#1b5b8a": palette["accent_dark"], "#268dd1": palette["accent_border"], "#60a5fa": palette["accent_border"],
        "#30bd8a": palette["success"], "#36d399": palette["success"], "#ffabab": palette["danger"],
        "#96a2b2": palette["muted"], "#9eacbd": palette["muted"], "#98a6b8": palette["muted"],
        "#8293a7": palette["muted"], "#aab8c8": palette["muted"], "#becbd9": palette["muted"],
        "#e7edf5": palette["text"], "#d6e4f2": palette["text"], "#f4f7fb": palette["text"],
        "#d8e4ef": palette["accent"], "#d7e0ec": palette["accent"], "#f7fafc": palette["accent_border"],
        "#303945": palette["track"], "#232a34": palette["card"], "#202630": palette["input"],
    }
    result = base
    for source, target in replacements.items():
        result = result.replace(source, target)
    if compact:
        # Apply compact replacements in one pass. Sequential str.replace calls can
        # accidentally shrink a value generated by an earlier replacement.
        compact_padding = {
            "7px 11px": "5px 8px",
            "6px 7px": "4px 5px",
            "5px 8px": "4px 6px",
        }
        result = re.sub(
            r"padding:(7px 11px|6px 7px|5px 8px)",
            lambda match: "padding:" + compact_padding[match.group(1)],
            result,
        )
    if palette.get("mode") == "light":
        # A complete light override is required because some base QSS declarations
        # intentionally use fixed dark colors for the original Graphite theme.
        result += f"""
QWidget, QMainWindow, QDialog {{ background:{palette['window']}; color:{palette['text']}; }}
QLabel, QCheckBox {{ color:{palette['text']}; }}
QLabel#muted, QLabel#subtitle, QLabel#eyebrow {{ color:{palette['muted']}; }}
QFrame#panel, QGroupBox {{ background:{palette['panel']}; color:{palette['text']}; border:1px solid {palette['border']}; }}
QTabWidget::pane {{ background:{palette['panel']}; border:1px solid {palette['border']}; border-top:1px solid {palette['border']}; border-bottom-left-radius:9px; border-bottom-right-radius:9px; top:-1px; }}
QTabWidget::tab-bar {{ left:5px; }}
QTabBar {{ qproperty-drawBase:false; border:0px; background:transparent; }}
QTabBar::tab {{ background:{palette['tab']}; color:{palette['muted']}; padding:6px 9px; margin-right:3px; margin-bottom:0px; min-height:27px; border:1px solid {palette['border']}; border-top-left-radius:7px; border-top-right-radius:7px; }}
QTabBar::tab:selected {{ background:{palette['panel']}; color:{palette['text']}; border:1px solid {palette['border']}; border-top:2px solid {palette['accent']}; border-bottom:1px solid {palette['panel']}; margin-bottom:-1px; }}
QTabBar::tab:hover:!selected {{ background:{palette['selected']}; color:{palette['text']}; }}
QComboBox, QLineEdit, QSpinBox, QDoubleSpinBox, QTableWidget {{ background:{palette['input']}; color:{palette['text']}; border:1px solid {palette['border']}; selection-background-color:{palette['accent_dark']}; }}
QComboBox QAbstractItemView {{ background:{palette['panel']}; color:{palette['text']}; selection-background-color:{palette['accent_dark']}; }}
QPushButton {{ background:{palette['tab']}; color:{palette['text']}; border:1px solid {palette['border']}; padding:7px 10px; min-height:25px; }}
QPushButton:hover, QToolButton:hover {{ background:{palette['selected']}; border-color:{palette['accent']}; }}
QPushButton#primary {{ background:{palette['accent_dark']}; color:white; border-color:{palette['accent']}; }}
QToolButton#hardwareGlobal {{ background:{palette['card']}; color:{palette['text']}; border-color:{palette['border']}; }}
QHeaderView::section {{ background:{palette['tab']}; color:{palette['text']}; border-bottom:1px solid {palette['border']}; }}
QStatusBar {{ background:{palette['panel']}; color:{palette['muted']}; }}
QProgressBar {{ background:{palette['track']}; color:{palette['text']}; border:1px solid {palette['border']}; }}
QSlider::groove:vertical {{ background:{palette['track']}; }}
QSlider::handle:vertical {{ background:{palette['accent']}; border:1px solid {palette['border']}; }}
QToolTip {{ background:{palette['panel']}; color:{palette['text']}; border:1px solid {palette['border']}; padding:5px; }}
QScrollBar:vertical {{ background:{palette['window']}; width:8px; margin:2px 0 2px 0; border:0px; }}
QScrollBar::handle:vertical {{ background:{palette['border']}; min-height:28px; border-radius:4px; }}
QScrollBar::handle:vertical:hover {{ background:{palette['accent']}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height:0px; }}
QScrollBar:horizontal {{ background:{palette['window']}; height:8px; margin:0 2px 0 2px; border:0px; }}
QScrollBar::handle:horizontal {{ background:{palette['border']}; min-width:28px; border-radius:4px; }}
QScrollBar::handle:horizontal:hover {{ background:{palette['accent']}; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width:0px; }}
"""
    return result
