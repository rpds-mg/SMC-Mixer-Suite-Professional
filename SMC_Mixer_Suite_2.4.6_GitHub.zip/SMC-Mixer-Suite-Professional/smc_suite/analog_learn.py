"""Validate continuous MIDI movement before assigning an analog control.

A button tap can emit a CC message just like a fader. Mapping the first CC
packet immediately can therefore bind a physical button to a volume fader.
This sampler only confirms an analog mapping after it observes a movement
pattern, and keeps no dependency on Qt so the behaviour can be unit-tested.
"""
from __future__ import annotations

from collections import deque
import time
from typing import Deque


class AnalogLearnSampler:
    """Require a short analog-motion signature before accepting a CC route."""

    def __init__(self, window_seconds: float = 0.8) -> None:
        self.window_seconds = max(0.25, float(window_seconds))
        self.reset()

    def reset(self) -> None:
        self.candidate_key: str | None = None
        self.samples: Deque[tuple[float, int]] = deque()

    def feed(self, kind: str, key: str, value: int, now: float | None = None) -> tuple[bool, int, str]:
        """Return ``(confirmed, sample_count, user_message)`` for a MIDI CC sample."""
        if kind not in {"fader", "knob"}:
            return False, 0, "Este assistente só aprende faders e knobs."
        current = time.monotonic() if now is None else float(now)
        value = max(0, min(127, int(value)))
        key = str(key)

        if self.candidate_key != key:
            self.candidate_key = key
            self.samples.clear()

        self.samples.append((current, value))
        while self.samples and current - self.samples[0][0] > self.window_seconds:
            self.samples.popleft()

        values = [sample_value for _timestamp, sample_value in self.samples]
        distinct = set(values)
        elapsed = current - self.samples[0][0] if self.samples else 0.0
        # Ordinary button press/release streams commonly consist of only 0/127.
        # Never treat that edge-only pattern as analog motion.
        edge_only = bool(distinct) and distinct.issubset({0, 127})

        if kind == "fader":
            confirmed = (
                len(values) >= 4
                and len(distinct) >= 3
                and max(values) - min(values) >= 5
                and not edge_only
            )
            required = "Mova o fader de forma contínua por alguns centímetros. Um clique de botão não será aceito."
        else:
            # Turn the encoder both ways. This works for absolute and common
            # relative encoders while rejecting a simple 0/127 button tap.
            confirmed = len(values) >= 4 and elapsed >= 0.06 and len(distinct) >= 2 and not edge_only
            required = "Gire o knob em ambos os sentidos algumas vezes. Um clique de botão não será aceito."

        if confirmed:
            return True, len(values), "Movimento confirmado."
        return False, len(values), f"Aprendizado seguro ({len(values)} amostra(s)): {required}"

class AnalogCCMotionGuard:
    """Reject isolated CC 0/127 edges on mapped faders unless recent motion supports them.

    It is a defence-in-depth heuristic for button CC collisions. It cannot identify
    physical origin when a controller emits indistinguishable messages; Note-mode
    buttons remain the reliable hardware configuration.
    """

    def __init__(self, window_seconds: float = 0.45) -> None:
        self.window_seconds = max(0.2, float(window_seconds))
        self._history: dict[str, Deque[tuple[float, int]]] = {}

    def reset(self, key: str | None = None) -> None:
        if key is None:
            self._history.clear()
        else:
            self._history.pop(str(key), None)

    def record(self, key: str, value: int, now: float | None = None) -> None:
        current = time.monotonic() if now is None else float(now)
        route_key = str(key)
        samples = self._history.setdefault(route_key, deque())
        samples.append((current, max(0, min(127, int(value)))))
        while samples and current - samples[0][0] > self.window_seconds:
            samples.popleft()
        while len(samples) > 32:
            samples.popleft()

    def allow_fader_value(self, key: str, value: int, now: float | None = None) -> bool:
        value = max(0, min(127, int(value)))
        if value not in (0, 127):
            return True
        current = time.monotonic() if now is None else float(now)
        samples = self._history.get(str(key), deque())
        values = [v for timestamp, v in samples if current - timestamp <= self.window_seconds and 0 < v < 127]
        distinct = set(values)
        if len(distinct) < 3 or max(values, default=0) - min(values, default=0) < 8:
            return False
        last = values[-1] if values else None
        if last is None:
            return False
        # Must be approaching the chosen endpoint. This is intentionally
        # conservative; a legitimate endpoint command should have intermediate
        # fader movement preceding it, not just a button's 0/127 pulse.
        if value == 127:
            return last >= 100
        return last <= 27
