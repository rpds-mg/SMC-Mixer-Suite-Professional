from __future__ import annotations

import copy
import json
import os
import shutil
import logging
import logging.handlers
import math
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

from smc_suite.hardware import (
    BUTTON_IDS, CHANNEL_DEFAULT_NAMES, CHANNEL_DEFAULT_TARGETS, CHANNEL_DEFAULT_COLORS,
    LEGACY_CHANNEL_DEFAULT_COLORS, default_button_actions,
)
from smc_suite.midi_mapping import repair_duplicate_midi_routes
from smc_suite.eq_model import DEFAULT_FREQUENCIES, FACTORY_PRESETS, normalize_mode, sanitize_frequencies, clamp_gain, gains_by_mode_from_reference
from smc_suite.themes import DEFAULT_THEME

def _select_writable_app_dir() -> Path:
    """Pick the normal per-user config path, falling back if it is not writable."""
    base = Path(os.environ.get("APPDATA", str(Path.home()))) / "SMCMixerSuite"
    candidates = [base, Path.home() / "SMCMixerSuite", Path(tempfile.gettempdir()) / "SMCMixerSuite"]
    for candidate in candidates:
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(prefix=".write-test-", dir=candidate, delete=True):
                pass
            return candidate
        except OSError:
            continue
    # Keep the conventional path as a final fallback; later saves report any error.
    return candidates[-1]


APP_DIR = _select_writable_app_dir()
CONFIG_FILE = APP_DIR / "settings.json"

DEFAULT_MACROS = [
    {"name": f"Macro {i + 1}", "midi": None, "action": "shortcut", "argument": "ctrl+shift+{0}".format(i + 1)}
    for i in range(8)
]
BANK_COUNT = 4
SCHEMA_VERSION = 6
_LOG = logging.getLogger("smc_mixer_suite")


def _bounded_int(value: Any, default: int, minimum: int, maximum: int) -> int:
    try:
        number = int(value)
        return max(minimum, min(maximum, number))
    except (TypeError, ValueError, OverflowError):
        return default


def _bounded_float(value: Any, default: float, minimum: float, maximum: float) -> float:
    try:
        number = float(value)
        if not math.isfinite(number):
            return default
        return max(minimum, min(maximum, number))
    except (TypeError, ValueError):
        return default


def _default_bank(index: int = 0) -> dict[str, Any]:
    if index == 0:
        return {
            "name": "Banco 1",
            "channel_names": list(CHANNEL_DEFAULT_NAMES),
            "fader_targets": list(CHANNEL_DEFAULT_TARGETS),
            "channel_colors": list(CHANNEL_DEFAULT_COLORS),
        }
    return {
        "name": f"Banco {index + 1}",
        "channel_names": [f"Canal {i + 1}" for i in range(8)],
        "fader_targets": [""] * 8,
        "channel_colors": list(CHANNEL_DEFAULT_COLORS),
    }


def default_profile(name: str = "Uso Geral") -> dict[str, Any]:
    return {
        "name": name,
        "channel_names": list(CHANNEL_DEFAULT_NAMES),
        "fader_targets": list(CHANNEL_DEFAULT_TARGETS),
        "channel_colors": list(CHANNEL_DEFAULT_COLORS),
        "banks": [_default_bank(i) for i in range(BANK_COUNT)],
        "active_bank": 0,
        "fader_midi": [None] * 8,
        "knob_midi": [None] * 8,
        "eq_gains": [0.0] * 8,
        "eq_gains_by_mode": {"3": [0.0] * 3, "5": [0.0] * 5, "8": [0.0] * 8},
        "eq_bypass": False,
        "eq_low_cut_enabled": False,
        "eq_low_cut_hz": 40.0,
        "eq_high_cut_enabled": False,
        "eq_high_cut_hz": 18000.0,
        "eq_band7_freq": 8000,  # compatibilidade com versões antigas
        "eq_mode": 8,
        "eq_fixed_frequencies": True,
        "eq_custom_frequencies": {key: values.copy() for key, values in DEFAULT_FREQUENCIES.items()},
        "eq_selected_preset": "Flat / Neutro",
        "eq_user_presets": {},
        "eq_ab_slots": {"A": None, "B": None},
        "led_feedback_enabled": False,
        "led_mode": "equalizer",
        "led_speed": 1.0,
        "led_brightness": 0.8,
        "led_output_port": "AUTO",
        "knob_mode": "auto",
        "knob_target_mode": "eq",
        "knob_step_db": 0.5,
        "knob_invert": False,
        "midi_hysteresis": 1,
        "button_actions": default_button_actions(),
        "macros": copy.deepcopy(DEFAULT_MACROS),
    }


def _normalize_profile(profile: dict[str, Any], name: str) -> dict[str, Any]:
    base = default_profile(name)
    if not isinstance(profile, dict):
        return base
    has_saved_banks = isinstance(profile.get("banks"), list) and bool(profile.get("banks"))
    has_saved_mode_gains = isinstance(profile.get("eq_gains_by_mode"), dict)
    base.update(profile)
    base["name"] = name

    # Normalize legacy arrays first so old settings.json files migrate safely.
    for key, size, default in (
        ("channel_names", 8, "Canal"), ("fader_targets", 8, ""),
        ("fader_midi", 8, None), ("knob_midi", 8, None), ("eq_gains", 8, 0.0),
        ("macros", 8, None),
    ):
        values = base.get(key)
        if not isinstance(values, list):
            values = []
        values = values[:size]
        while len(values) < size:
            i = len(values)
            if key == "macros":
                values.append(copy.deepcopy(DEFAULT_MACROS[i]))
            elif key == "channel_names":
                values.append(f"{default} {i + 1}")
            else:
                values.append(default)
        if key == "macros":
            fixed = []
            for i, item in enumerate(values):
                item = item if isinstance(item, dict) else {}
                row = copy.deepcopy(DEFAULT_MACROS[i])
                row.update(item)
                row["name"] = str(row.get("name") or f"Macro {i + 1}")
                row["action"] = str(row.get("action") or "none")
                row["argument"] = str(row.get("argument") or "")
                if row["action"] == "obs":
                    row["action"] = "none"
                    row["argument"] = ""
                fixed.append(row)
            values = fixed
        elif key == "channel_names":
            values = [str(v or f"Canal {i + 1}")[:48] for i, v in enumerate(values)]
        base[key] = values

    # Create four independently saved banks. Existing profiles become Banco 1.
    banks_in = base.get("banks") if has_saved_banks else None
    normalized_banks: list[dict[str, Any]] = []
    if isinstance(banks_in, list) and banks_in:
        for i in range(BANK_COUNT):
            old = banks_in[i] if i < len(banks_in) and isinstance(banks_in[i], dict) else {}
            fallback = _default_bank(i)
            fallback.update(old)
            names = fallback.get("channel_names", [])
            targets = fallback.get("fader_targets", [])
            colors = fallback.get("channel_colors", [])
            if not isinstance(names, list): names = []
            if not isinstance(targets, list): targets = []
            if not isinstance(colors, list): colors = []
            fallback["channel_names"] = [str(names[j] if j < len(names) and names[j] else f"Canal {j + 1}")[:48] for j in range(8)]
            fallback["fader_targets"] = [str(targets[j]) if j < len(targets) and targets[j] is not None else "" for j in range(8)]
            clean_colors = []
            for j in range(8):
                color = str(colors[j]) if j < len(colors) else CHANNEL_DEFAULT_COLORS[j]
                if not (len(color) == 7 and color.startswith("#") and all(c in "0123456789abcdefABCDEF" for c in color[1:])):
                    color = CHANNEL_DEFAULT_COLORS[j]
                normalized_color = color.lower()
                if j < len(LEGACY_CHANNEL_DEFAULT_COLORS) and normalized_color == LEGACY_CHANNEL_DEFAULT_COLORS[j]:
                    normalized_color = CHANNEL_DEFAULT_COLORS[j]
                clean_colors.append(normalized_color)
            fallback["channel_colors"] = clean_colors
            fallback["name"] = str(fallback.get("name") or f"Banco {i + 1}")[:48]
            normalized_banks.append(fallback)
    else:
        normalized_banks = [_default_bank(i) for i in range(BANK_COUNT)]
        normalized_banks[0]["channel_names"] = list(base["channel_names"])
        normalized_banks[0]["fader_targets"] = list(base["fader_targets"])
        legacy_colors = profile.get("channel_colors", CHANNEL_DEFAULT_COLORS) if isinstance(profile, dict) else CHANNEL_DEFAULT_COLORS
        if not isinstance(legacy_colors, list): legacy_colors = CHANNEL_DEFAULT_COLORS
        migrated_legacy_colors = []
        for j in range(8):
            raw_color = str(legacy_colors[j]).lower() if j < len(legacy_colors) else ""
            valid = len(raw_color) == 7 and raw_color.startswith("#") and all(ch in "0123456789abcdef" for ch in raw_color[1:])
            color = raw_color if valid else CHANNEL_DEFAULT_COLORS[j]
            if j < len(LEGACY_CHANNEL_DEFAULT_COLORS) and color == LEGACY_CHANNEL_DEFAULT_COLORS[j]:
                color = CHANNEL_DEFAULT_COLORS[j]
            migrated_legacy_colors.append(color)
        normalized_banks[0]["channel_colors"] = migrated_legacy_colors
    base["banks"] = normalized_banks
    try:
        base["active_bank"] = max(0, min(BANK_COUNT - 1, int(base.get("active_bank", 0))))
    except (ValueError, TypeError):
        base["active_bank"] = 0
    active = base["banks"][base["active_bank"]]
    # Legacy fields mirror the active bank; fresh reads use get_active_bank().
    base["channel_names"] = list(active["channel_names"])
    base["fader_targets"] = list(active["fader_targets"])

    actions_in = base.get("button_actions")
    defaults = default_button_actions()
    if isinstance(actions_in, dict):
        for control_id in BUTTON_IDS:
            row = actions_in.get(control_id)
            if isinstance(row, dict):
                defaults[control_id].update(row)
                defaults[control_id]["midi"] = (str(row["midi"]) if row.get("midi") else None)
                defaults[control_id]["action"] = str(row.get("action") or defaults[control_id]["action"])
                defaults[control_id]["argument"] = str(row.get("argument") or "")
                trigger_mode = str(row.get("trigger_mode") or "note")
                if trigger_mode not in {"auto", "cc_single_toggle", "cc_push", "note"}:
                    trigger_mode = "note"
                # Unassigned legacy rows were effectively defaults; give them the
                # safer Note-first behaviour. Preserve configured legacy CC routes.
                if not defaults[control_id]["midi"] and trigger_mode == "auto":
                    trigger_mode = "note"
                defaults[control_id]["trigger_mode"] = trigger_mode
                # OBS integration is intentionally removed from this build. Migrate
                # legacy actions safely instead of executing a hidden command.
                if defaults[control_id]["action"] == "obs":
                    defaults[control_id]["action"] = "none"
                    defaults[control_id]["argument"] = ""
    base["button_actions"] = defaults

    base["eq_gains"] = [clamp_gain(v) for v in base["eq_gains"]]
    if base.get("eq_band7_freq") not in (4000, 8000):
        base["eq_band7_freq"] = 8000
    base["eq_mode"] = int(normalize_mode(base.get("eq_mode", 8)))
    base["eq_fixed_frequencies"] = bool(base.get("eq_fixed_frequencies", True))
    frequency_source = base.get("eq_custom_frequencies", {})
    if not isinstance(frequency_source, dict):
        frequency_source = {}
    base["eq_custom_frequencies"] = {
        key: sanitize_frequencies(frequency_source.get(key, defaults), key)
        for key, defaults in DEFAULT_FREQUENCIES.items()
    }
    # Preserve a legacy band-7 choice as the default 8-band frequency when migrating.
    if not isinstance(profile.get("eq_custom_frequencies"), dict):
        base["eq_custom_frequencies"]["8"][6] = float(base["eq_band7_freq"])

    # Keep independent EQ curves for the 3/5/8-band layouts. Old profiles only
    # contain one 8-band curve; derive the simpler layouts once during migration.
    if has_saved_mode_gains:
        source_mode_gains = profile.get("eq_gains_by_mode", {})
    else:
        source_mode_gains = gains_by_mode_from_reference(base["eq_gains"], base["eq_custom_frequencies"])
    normalized_mode_gains: dict[str, list[float]] = {}
    for key, frequencies in base["eq_custom_frequencies"].items():
        raw = source_mode_gains.get(key) if isinstance(source_mode_gains, dict) else None
        if isinstance(raw, list):
            row = [clamp_gain(v) for v in raw[:len(frequencies)]]
            row += [0.0] * (len(frequencies) - len(row))
        else:
            row = gains_by_mode_from_reference(base["eq_gains"], base["eq_custom_frequencies"])[key]
        normalized_mode_gains[key] = row
    base["eq_gains_by_mode"] = normalized_mode_gains
    base["eq_gains"] = [0.0] * 8
    active_mode = str(base["eq_mode"])
    base["eq_gains"][:len(normalized_mode_gains[active_mode])] = normalized_mode_gains[active_mode]
    base["eq_selected_preset"] = str(base.get("eq_selected_preset") or "Flat / Neutro")[:80]
    user_presets = base.get("eq_user_presets", {})
    if not isinstance(user_presets, dict):
        user_presets = {}
    normalized_presets = {}
    for preset_name, preset_data in user_presets.items():
        safe_name = str(preset_name).strip()[:80]
        if not safe_name or safe_name in FACTORY_PRESETS or not isinstance(preset_data, dict):
            continue
        preset_gains = preset_data.get("gains", [])
        if not isinstance(preset_gains, list):
            continue
        preset_gains = [clamp_gain(v) for v in preset_gains[:8]]
        preset_gains += [0.0] * (8 - len(preset_gains))
        # Preserve full snapshots in v2 presets; legacy presets retain the 8-point anchor curve.
        normalized_entry: dict[str, Any] = {
            "gains": preset_gains,
            "description": str(preset_data.get("description", "Personalizado"))[:160],
        }
        mode = str(normalize_mode(preset_data.get("mode", 8)))
        normalized_entry["mode"] = mode
        normalized_entry["eq_fixed_frequencies"] = bool(preset_data.get("eq_fixed_frequencies", True))
        normalized_entry["eq_bypass"] = bool(preset_data.get("eq_bypass", False))
        normalized_entry["eq_low_cut_enabled"] = bool(preset_data.get("eq_low_cut_enabled", False))
        normalized_entry["eq_low_cut_hz"] = _bounded_float(preset_data.get("eq_low_cut_hz", 40.0), 40.0, 20.0, 200.0)
        normalized_entry["eq_high_cut_enabled"] = bool(preset_data.get("eq_high_cut_enabled", False))
        normalized_entry["eq_high_cut_hz"] = _bounded_float(preset_data.get("eq_high_cut_hz", 18000.0), 18000.0, 5000.0, 20000.0)
        saved_freqs = preset_data.get("frequencies_by_mode", {})
        saved_gains = preset_data.get("gains_by_mode", {})
        normalized_entry["frequencies_by_mode"] = {
            m: sanitize_frequencies(saved_freqs.get(m, base["eq_custom_frequencies"][m]), m)
            for m in DEFAULT_FREQUENCIES
        } if isinstance(saved_freqs, dict) else {}
        fixed_gains_by_mode: dict[str, list[float]] = {}
        if isinstance(saved_gains, dict):
            for m, freqs in base["eq_custom_frequencies"].items():
                vals = saved_gains.get(m, [])
                if isinstance(vals, list) and vals:
                    vals = [clamp_gain(v) for v in vals[:len(DEFAULT_FREQUENCIES[m])]]
                    vals += [0.0] * (len(DEFAULT_FREQUENCIES[m]) - len(vals))
                    fixed_gains_by_mode[m] = vals
        normalized_entry["gains_by_mode"] = fixed_gains_by_mode
        normalized_presets[safe_name] = normalized_entry
    base["eq_user_presets"] = normalized_presets

    # Persistent A/B comparison snapshots. Normalize every numeric value so a
    # hand-edited JSON file cannot inject NaN, oversized gains, or invalid modes.
    raw_ab_slots = base.get("eq_ab_slots", {})
    normalized_ab_slots: dict[str, Any] = {"A": None, "B": None}
    if isinstance(raw_ab_slots, dict):
        for slot_name in ("A", "B"):
            snapshot = raw_ab_slots.get(slot_name)
            if not isinstance(snapshot, dict):
                continue
            snapshot_freqs = snapshot.get("frequencies_by_mode", {})
            snapshot_gains = snapshot.get("gains_by_mode", {})
            if not isinstance(snapshot_freqs, dict):
                snapshot_freqs = {}
            if not isinstance(snapshot_gains, dict):
                snapshot_gains = {}
            safe_freqs = {
                mode_key: sanitize_frequencies(snapshot_freqs.get(mode_key, base["eq_custom_frequencies"][mode_key]), mode_key)
                for mode_key in DEFAULT_FREQUENCIES
            }
            safe_gains: dict[str, list[float]] = {}
            for mode_key, frequency_list in DEFAULT_FREQUENCIES.items():
                values = snapshot_gains.get(mode_key, [])
                if not isinstance(values, list):
                    values = []
                values = [clamp_gain(value) for value in values[:len(frequency_list)]]
                values += [0.0] * (len(frequency_list) - len(values))
                safe_gains[mode_key] = values
            anchors = snapshot.get("gains", [])
            if not isinstance(anchors, list):
                anchors = []
            anchors = [clamp_gain(value) for value in anchors[:8]]
            anchors += [0.0] * (8 - len(anchors))
            normalized_ab_slots[slot_name] = {
                "gains": anchors,
                "gains_by_mode": safe_gains,
                "frequencies_by_mode": safe_freqs,
                "mode": int(normalize_mode(snapshot.get("mode", 8))),
                "eq_fixed_frequencies": bool(snapshot.get("eq_fixed_frequencies", True)),
                "eq_bypass": bool(snapshot.get("eq_bypass", False)),
                "eq_low_cut_enabled": bool(snapshot.get("eq_low_cut_enabled", False)),
                "eq_low_cut_hz": _bounded_float(snapshot.get("eq_low_cut_hz", 40.0), 40.0, 20.0, 200.0),
                "eq_high_cut_enabled": bool(snapshot.get("eq_high_cut_enabled", False)),
                "eq_high_cut_hz": _bounded_float(snapshot.get("eq_high_cut_hz", 18000.0), 18000.0, 5000.0, 20000.0),
                "description": str(snapshot.get("description", f"Comparação {slot_name}"))[:160],
            }
    base["eq_ab_slots"] = normalized_ab_slots
    # Normalize the rotary encoding selector. Older generic "relative" settings
    # are migrated to Auto because they are often wrong for the actual CC/CW setup.
    old_knob_mode = str(base.get("knob_mode", "auto"))
    if old_knob_mode in ("relative", "", "automatic"):
        base["knob_mode"] = "auto"
    elif old_knob_mode == "relative_127":
        base["knob_mode"] = "relative_twos"
    elif old_knob_mode == "relative_signed":
        base["knob_mode"] = "relative_centered"
    elif old_knob_mode in ("auto", "absolute", "relative_twos", "relative_centered"):
        base["knob_mode"] = old_knob_mode
    else:
        base["knob_mode"] = "auto"
    base["knob_invert"] = bool(base.get("knob_invert", False))
    if base.get("knob_target_mode") not in ("eq", "app_gain"):
        base["knob_target_mode"] = "eq"
    try:
        base["knob_step_db"] = max(0.1, min(3.0, float(base.get("knob_step_db", 0.5))))
    except (TypeError, ValueError):
        base["knob_step_db"] = 0.5
    try:
        base["midi_hysteresis"] = max(0, min(4, int(base.get("midi_hysteresis", 1))))
    except (TypeError, ValueError):
        base["midi_hysteresis"] = 1
    base["eq_bypass"] = bool(base.get("eq_bypass", False))
    base["eq_low_cut_enabled"] = bool(base.get("eq_low_cut_enabled", False))
    base["eq_low_cut_hz"] = _bounded_float(base.get("eq_low_cut_hz", 40.0), 40.0, 20.0, 200.0)
    base["eq_high_cut_enabled"] = bool(base.get("eq_high_cut_enabled", False))
    base["eq_high_cut_hz"] = _bounded_float(base.get("eq_high_cut_hz", 18000.0), 18000.0, 5000.0, 20000.0)
    valid_led_modes = {"off", "static", "level", "equalizer", "knight_rider", "chase", "wave", "breathe", "pulse", "channel_scan", "meter_fill"}
    if base.get("led_mode") not in valid_led_modes:
        base["led_mode"] = "equalizer"
    base["led_feedback_enabled"] = bool(base.get("led_feedback_enabled", False))
    try:
        base["led_speed"] = max(0.25, min(4.0, float(base.get("led_speed", 1.0))))
    except (TypeError, ValueError):
        base["led_speed"] = 1.0
    try:
        base["led_brightness"] = max(0.05, min(1.0, float(base.get("led_brightness", 0.8))))
    except (TypeError, ValueError):
        base["led_brightness"] = 0.8
    base["led_output_port"] = str(base.get("led_output_port", "AUTO") or "AUTO")[:160]
    return base


class ConfigStore:
    """Versioned JSON settings with atomic writes and automatic last-known-good backup."""

    def __init__(self) -> None:
        APP_DIR.mkdir(parents=True, exist_ok=True)
        self._loaded_corrupt = False
        self.last_error = ""
        self.mapping_repair_warnings: list[str] = []
        self.mapping_repair_persisted = True
        self.data = self._load()
        # One-time safety migration for the reported SELECT 2/3 -> Fader 6/7
        # collision. Clear only the two physical fader MIDI assignments in every
        # profile; preserve destinations, names, EQ, buttons, and all other routes.
        needs_save = False
        # One-time visual migration: move existing installs to the 3.2 graphite/green
        # theme while preserving every control mapping, profile, EQ and action.
        theme_migration_key = "theme_migration_v32_applied"
        if not bool(self.data.get(theme_migration_key, False)):
            self.data["theme"] = DEFAULT_THEME
            self.data["custom_accent"] = ""
            self.data[theme_migration_key] = True
            needs_save = True

        migration_key = "midi_selector_fader_collision_repair_v244"
        if not bool(self.data.get(migration_key, False)):
            for profile_name, profile in self.data.get("profiles", {}).items():
                faders = profile.get("fader_midi", [])
                for index in (5, 6):
                    if index < len(faders) and faders[index]:
                        self.mapping_repair_warnings.append(
                            f"Perfil {profile_name}: vínculo MIDI antigo do Fader {index + 1} removido para corrigir a colisão com SELECT. "
                            "Refaça o aprendizado movendo apenas o fader físico correspondente por uma faixa ampla."
                        )
                        faders[index] = None
                        needs_save = True
            self.data[migration_key] = True
            needs_save = True

        # Prevent a single physical MIDI signal from controlling multiple logical inputs.
        for profile_name, profile in self.data.get("profiles", {}).items():
            for warning in repair_duplicate_midi_routes(profile):
                self.mapping_repair_warnings.append(f"Perfil {profile_name}: {warning}")
                needs_save = True
        self.data.setdefault("schema_version", SCHEMA_VERSION)
        if needs_save:
            if self._loaded_corrupt:
                # Do not overwrite or back up a malformed source as if it were valid.
                self.mapping_repair_persisted = False
                self.mapping_repair_warnings.append(
                    "A configuração original estava inválida e foi preservada. As correções estão em memória; "
                    "revise a recuperação antes de salvar manualmente."
                )
            else:
                self.mapping_repair_persisted = self.save()
                if not self.mapping_repair_persisted:
                    self.mapping_repair_warnings.append(
                        "A correção foi aplicada em memória, mas não foi possível salvar settings.json. "
                        f"Erro: {self.last_error or 'erro de gravação não especificado'}"
                    )

    def _default_root(self) -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "active_profile": "Uso Geral",
            "profiles": {"Uso Geral": default_profile()},
            "midi_port": "AUTO",
            "midi_transport": "auto",
            "eq_file": str(APP_DIR / "equalizerapo_filters.txt"),
            "theme": DEFAULT_THEME,
            "theme_migration_v32_applied": False,
            "custom_accent": "",
            "compact_ui": False,
            "show_action_hud": True,
            "hud_position": "bottom_right",
            "hud_duration_ms": 1180,
            "midi_selector_fader_collision_repair_v244": False,
        }

    def _load(self) -> dict[str, Any]:
        if not CONFIG_FILE.exists():
            return self._default_root()
        try:
            loaded = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            if not isinstance(loaded, dict):
                raise ValueError("A raiz do arquivo de configuração não é um objeto JSON.")
            profiles_in = loaded.get("profiles", {})
            profiles: dict[str, Any] = {}
            if isinstance(profiles_in, dict):
                for profile_name, profile in profiles_in.items():
                    clean_name = str(profile_name).strip()[:80] or "Perfil"
                    profiles[clean_name] = _normalize_profile(profile, clean_name)
            if not profiles:
                profiles = {"Uso Geral": default_profile()}
            active = str(loaded.get("active_profile", next(iter(profiles))))
            if active not in profiles:
                active = next(iter(profiles))
            default = self._default_root()
            theme = str(loaded.get("theme", default["theme"]))
            try:
                from smc_suite.themes import THEMES
                if theme not in THEMES:
                    theme = default["theme"]
            except Exception:
                theme = default["theme"]
            accent = str(loaded.get("custom_accent", ""))[:7]
            if not (len(accent) == 7 and accent.startswith("#")):
                accent = ""
            return {
                "schema_version": SCHEMA_VERSION,
                "active_profile": active,
                "profiles": profiles,
                "midi_port": str(loaded.get("midi_port", "AUTO")),
                "midi_transport": str(loaded.get("midi_transport", "auto")).lower() if str(loaded.get("midi_transport", "auto")).lower() in {"auto", "usb", "bluetooth"} else "auto",
                "eq_file": str(loaded.get("eq_file", default["eq_file"])),
                "theme": theme,
                "theme_migration_v32_applied": bool(loaded.get("theme_migration_v32_applied", False)),
                "custom_accent": accent,
                "compact_ui": bool(loaded.get("compact_ui", False)),
                "show_action_hud": bool(loaded.get("show_action_hud", True)),
                "hud_position": str(loaded.get("hud_position", "bottom_right")) if str(loaded.get("hud_position", "bottom_right")) in {"bottom_right", "bottom_left", "top_right", "top_left"} else "bottom_right",
                "hud_duration_ms": _bounded_int(loaded.get("hud_duration_ms", 1180), 1180, 700, 5000),
                "midi_selector_fader_collision_repair_v244": bool(loaded.get("midi_selector_fader_collision_repair_v244", False)),
            }
        except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
            # Preserve a malformed settings file for manual recovery instead of overwriting it silently.
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            recovery = CONFIG_FILE.with_name(f"settings.corrupt-{timestamp}.json")
            self._loaded_corrupt = True
            try:
                shutil.copy2(CONFIG_FILE, recovery)
                _LOG.error("Configuração inválida copiada para %s: %s", recovery, exc)
            except OSError:
                _LOG.exception("Não foi possível preservar a configuração inválida")
            return self._default_root()

    def save(self) -> bool:
        """Write atomically. Keep the previous valid file as settings.json.bak."""
        APP_DIR.mkdir(parents=True, exist_ok=True)
        self.data["schema_version"] = SCHEMA_VERSION
        tmp = CONFIG_FILE.with_suffix(".tmp")
        try:
            payload = json.dumps(self.data, ensure_ascii=False, indent=2, allow_nan=False)
            # Validate generated JSON before touching the live file.
            json.loads(payload)
            if CONFIG_FILE.exists() and not self._loaded_corrupt:
                backup = CONFIG_FILE.with_suffix(".json.bak")
                try:
                    # Only replace the last-known-good backup with a parseable JSON file.
                    json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
                    shutil.copy2(CONFIG_FILE, backup)
                except (OSError, json.JSONDecodeError, ValueError):
                    _LOG.warning("Configuração anterior não foi usada como backup válido")
            with tmp.open("w", encoding="utf-8", newline="\n") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp, CONFIG_FILE)
            self._loaded_corrupt = False
            self.last_error = ""
            return True
        except Exception as exc:
            self.last_error = str(exc)
            _LOG.exception("Falha ao salvar configurações em %s", CONFIG_FILE)
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass
            return False

    @property
    def profile(self) -> dict[str, Any]:
        return self.data["profiles"][self.data["active_profile"]]

    @staticmethod
    def active_bank(profile: dict[str, Any] | None) -> dict[str, Any]:
        if not profile:
            return _default_bank(0)
        banks = profile.get("banks", [])
        index = int(profile.get("active_bank", 0))
        if isinstance(banks, list) and 0 <= index < len(banks) and isinstance(banks[index], dict):
            return banks[index]
        return _default_bank(0)

    def sync_legacy_bank_fields(self, profile: dict[str, Any] | None = None) -> None:
        profile = profile or self.profile
        active = self.active_bank(profile)
        profile["channel_names"] = list(active.get("channel_names", CHANNEL_DEFAULT_NAMES))
        profile["fader_targets"] = list(active.get("fader_targets", CHANNEL_DEFAULT_TARGETS))
        colors = active.get("channel_colors", CHANNEL_DEFAULT_COLORS)
        profile["channel_colors"] = list(colors) if isinstance(colors, list) else list(CHANNEL_DEFAULT_COLORS)

    def set_active_profile(self, name: str) -> bool:
        if name not in self.data["profiles"]:
            return False
        previous = self.data["active_profile"]
        self.data["active_profile"] = name
        if not self.save():
            self.data["active_profile"] = previous
            return False
        return True

    def create_profile(self, name: str, clone_active: bool = False) -> bool:
        name = name.strip()[:80]
        if not name or name in self.data["profiles"]:
            return False
        if clone_active:
            profile = copy.deepcopy(self.profile)
            profile["name"] = name
        else:
            profile = default_profile(name)
        previous_active = self.data["active_profile"]
        self.data["profiles"][name] = profile
        self.data["active_profile"] = name
        if not self.save():
            self.data["profiles"].pop(name, None)
            self.data["active_profile"] = previous_active
            return False
        return True

    def delete_profile(self, name: str) -> bool:
        if name not in self.data["profiles"] or len(self.data["profiles"]) <= 1:
            return False
        removed = self.data["profiles"].pop(name)
        previous_active = self.data["active_profile"]
        if previous_active == name:
            self.data["active_profile"] = next(iter(self.data["profiles"]))
        if not self.save():
            self.data["profiles"][name] = removed
            self.data["active_profile"] = previous_active
            return False
        return True

    def set_pref(self, key: str, value: Any) -> bool:
        existed = key in self.data
        previous = self.data.get(key)
        self.data[key] = value
        if not self.save():
            if existed:
                self.data[key] = previous
            else:
                self.data.pop(key, None)
            return False
        return True
