"""Logical layout and identifiers for the M-VAVE SMC-Mixer.

The hardware has eight encoder/fader strips and 43 assignable buttons. The 43
button inputs are modeled as 32 strip buttons plus 11 global buttons. Exact MIDI
numbers are intentionally learned from the connected device rather than guessed.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ButtonSpec:
    control_id: str
    label: str
    group: str
    channel: int | None = None
    key: str | None = None
    help_text: str = ""
    default_action: str = "none"
    default_argument: str = ""


BUTTON_SPECS: list[ButtonSpec] = []

for channel in range(8):
    n = channel + 1
    BUTTON_SPECS.extend([
        ButtonSpec(f"ch{n}_mute", "M", f"Canal {n}", channel, "M", "Mute do canal", "channel_mute"),
        ButtonSpec(f"ch{n}_solo", "S", f"Canal {n}", channel, "S", "Solo do canal", "channel_solo"),
        ButtonSpec(f"ch{n}_rec", "R", f"Canal {n}", channel, "R", "Armar gravação / ação configurável", "none"),
        ButtonSpec(f"ch{n}_select", "□", f"Canal {n}", channel, "SELECT", "Selecionar canal", "channel_select"),
    ])

# 11 global buttons: this keeps the 43-button model (32 strip + 11 global).
# PLAY/PAUSE is one assignable transport control; STOP can be assigned as its action.
GLOBAL_BUTTONS: list[ButtonSpec] = [
    ButtonSpec("transport_play_pause", "▶‖", "Transporte", None, "PLAY / PAUSE", "Alternar reprodução", "media", "Play / Pause"),
    ButtonSpec("transport_rec", "●", "Transporte", None, "REC", "Gravação / ação configurável", "none"),
    ButtonSpec("transport_rewind", "◀◀", "Transporte", None, "REW", "Voltar / faixa anterior", "media", "Faixa anterior"),
    ButtonSpec("transport_ff", "▶▶", "Transporte", None, "FF", "Avançar / próxima faixa", "media", "Próxima faixa"),
    ButtonSpec("bank_left", "BANK ◀", "Banco e navegação", None, "BANK LEFT", "Banco anterior", "bank_prev"),
    ButtonSpec("bank_right", "BANK ▶", "Banco e navegação", None, "BANK RIGHT", "Próximo banco", "bank_next"),
    ButtonSpec("nav_up", "↑", "Banco e navegação", None, "UP", "Seta para cima", "none"),
    ButtonSpec("nav_down", "↓", "Banco e navegação", None, "DOWN", "Seta para baixo", "none"),
    ButtonSpec("nav_left", "←", "Banco e navegação", None, "LEFT", "Seta para esquerda", "none"),
    ButtonSpec("nav_right", "→", "Banco e navegação", None, "RIGHT", "Seta para direita", "none"),
    ButtonSpec("shift", "SHIFT", "Banco e navegação", None, "SHIFT", "Alternar modo dos encoders", "shift_toggle"),
]
BUTTON_SPECS.extend(GLOBAL_BUTTONS)
BUTTON_SPEC_BY_ID = {spec.control_id: spec for spec in BUTTON_SPECS}
BUTTON_IDS = [spec.control_id for spec in BUTTON_SPECS]

CHANNEL_DEFAULT_NAMES = ["Master", "Canal 2", "Spotify", "Discord", "Navegador", "Canal 6", "Canal 7", "Canal 8"]
CHANNEL_DEFAULT_TARGETS = ["__master__", "", "spotify.exe", "Discord.exe", "chrome.exe", "", "", ""]
LEGACY_CHANNEL_DEFAULT_COLORS = ["#38bdf8", "#a78bfa", "#34d399", "#fb7185", "#fbbf24", "#60a5fa", "#f97316", "#2dd4bf"]
CHANNEL_DEFAULT_COLORS = ["#39b488"] * 8


def default_button_actions() -> dict[str, dict[str, str | None]]:
    actions: dict[str, dict[str, str | None]] = {}
    for spec in BUTTON_SPECS:
        actions[spec.control_id] = {
            "midi": None,
            "action": spec.default_action,
            "argument": spec.default_argument,
            # "auto" preserves the legacy press-edge handling; users can choose
            # CC Toggle/Single explicitly for firmwares that emit one alternating
            # CC event per tap rather than a press/release pair.
            "trigger_mode": "note",
        }
    return actions
