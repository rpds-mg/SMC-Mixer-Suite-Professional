"""Optional BLE GATT telemetry probe for the M-VAVE SMC-Mixer.

The controller/driver may not expose battery information. This module reads only
standard Bluetooth Battery Service characteristics when the peripheral publishes
those fields; it never fabricates a percentage or charging state.
"""
from __future__ import annotations

import asyncio
from typing import Any

BATTERY_SERVICE_UUID = "0000180f-0000-1000-8000-00805f9b34fb"
BATTERY_LEVEL_UUID = "00002a19-0000-1000-8000-00805f9b34fb"
BATTERY_POWER_STATE_UUID = "00002a1a-0000-1000-8000-00805f9b34fb"


def _charging_from_power_state(raw: bytes) -> bool | None:
    """Decode the standard/deprecated Battery Power State field when available.

    Bits 5-4 encode chargeable state: 0 unknown, 1 not chargeable,
    2 not charging, 3 charging. This field is optional and often absent.
    """
    if not raw:
        return None
    code = (int(raw[0]) >> 4) & 0b11
    if code == 3:
        return True
    if code == 2:
        return False
    return None


async def _probe_async(timeout: float = 8.0) -> dict[str, Any]:
    try:
        from bleak import BleakClient, BleakScanner
    except Exception as exc:
        return {"level": None, "charging": None, "device": None,
                "error": f"Biblioteca BLE indisponível: {exc}"}

    try:
        device = await BleakScanner.find_device_by_filter(
            lambda d, adv: "smc-mixer" in ((getattr(adv, "local_name", None) or getattr(d, "name", None) or "").casefold())
            or "m-vave" in ((getattr(adv, "local_name", None) or getattr(d, "name", None) or "").casefold()),
            timeout=timeout,
        )
        if device is None:
            return {"level": None, "charging": None, "device": None,
                    "error": "SMC-Mixer não encontrado no scan BLE. Confirme que o controlador está ligado e no modo Bluetooth."}

        async with BleakClient(device, timeout=timeout) as client:
            services = client.services
            battery_service = next((s for s in services if str(s.uuid).lower() == BATTERY_SERVICE_UUID), None)
            if battery_service is None:
                return {"level": None, "charging": None, "device": getattr(device, "name", None),
                        "error": "O dispositivo BLE não expôs o serviço padrão de bateria (0x180F). A porcentagem não está disponível via GATT."}
            level_char = next((c for c in battery_service.characteristics if str(c.uuid).lower() == BATTERY_LEVEL_UUID), None)
            power_char = next((c for c in battery_service.characteristics if str(c.uuid).lower() == BATTERY_POWER_STATE_UUID), None)
            level: int | None = None
            charging: bool | None = None
            if level_char is not None and "read" in [p.lower() for p in level_char.properties]:
                raw_level = await client.read_gatt_char(level_char)
                if raw_level:
                    candidate = int(raw_level[0])
                    if 0 <= candidate <= 100:
                        level = candidate
            if power_char is not None and "read" in [p.lower() for p in power_char.properties]:
                raw_power = await client.read_gatt_char(power_char)
                charging = _charging_from_power_state(bytes(raw_power))
            if level is None:
                return {"level": None, "charging": charging, "device": getattr(device, "name", None),
                        "error": "O serviço de bateria existe, mas não ofereceu o nível de carga legível."}
            return {"level": level, "charging": charging, "device": getattr(device, "name", None), "error": ""}
    except Exception as exc:
        return {"level": None, "charging": None, "device": None,
                "error": f"A leitura BLE não foi concluída: {exc}"}


def probe_smc_battery(timeout: float = 8.0) -> dict[str, Any]:
    """Synchronous wrapper intended to be called only from a worker thread."""
    try:
        return asyncio.run(_probe_async(timeout=timeout))
    except Exception as exc:
        return {"level": None, "charging": None, "device": None, "error": str(exc)}
