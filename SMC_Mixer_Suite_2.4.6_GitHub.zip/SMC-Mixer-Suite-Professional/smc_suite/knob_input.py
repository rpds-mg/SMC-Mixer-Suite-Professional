"""MIDI rotary-encoder decoding and auto-detection helpers.

SMC-Mixer encoders may be configured as absolute CC or as CW/relative controls.
The two common CW value pairs are 1/127 and 63/65. Auto mode identifies those
patterns from a short sample window; otherwise it falls back to absolute CC.
"""
from __future__ import annotations
from collections.abc import Iterable

KNOB_MODES = {
    "auto": "Automático · detectar ao girar",
    "absolute": "CC absoluto · posição 0–127",
    "relative_twos": "CW relativo · 1 = + / 127 = −",
    "relative_centered": "CW relativo · 63 = − / 65 = +",
}


def normalize_knob_mode(mode: object) -> str:
    text = str(mode or "")
    # Older versions called every relative mode simply "relative".
    if text in ("", "auto", "automatic"):
        return "auto"
    if text == "relative":
        return "auto"
    if text in ("relative_127", "relative_twos"):
        return "relative_twos"
    if text in ("relative_signed", "relative_centered"):
        return "relative_centered"
    if text in KNOB_MODES:
        return text
    return "auto"


def infer_knob_mode(samples: Iterable[int]) -> str | None:
    """Infer only after a stable sample window, avoiding false relative guesses.

    Absolute CC encoders can emit values around 63/65 when moved slowly near the
    midpoint. A one- or two-message guess can therefore make them behave like a
    relative encoder. Auto mode now waits for a fuller sample window and requires
    a sustained, protocol-specific pattern. If the stream is ambiguous, the UI
    leaves the control unresolved so the user can select its real format manually.
    """
    try:
        values = [int(v) for v in samples][-8:]
    except (TypeError, ValueError):
        return None
    if len(values) < 6 or any(v < 0 or v > 127 for v in values):
        return None

    if all(v in (1, 127) for v in values):
        # Repeated 1/127 values across a full window are characteristic of this CW format.
        return "relative_twos"
    if all(v in (63, 65) for v in values) and 63 in values and 65 in values:
        # A relative encoder normally sends a run of one direction and then a run
        # of the other. Many back-and-forth transitions are ambiguous midpoint CCs.
        transitions = sum(left != right for left, right in zip(values, values[1:]))
        if transitions <= 2:
            return "relative_centered"
        return None

    # Absolute CC changes smoothly across the 7-bit range. Require a broader
    # sample and at least four distinct values to reduce false classifications.
    if len(set(values)) >= 4 and max(values) - min(values) >= 3:
        return "absolute"
    return None


def decode_relative_delta(value: int, mode: object = "relative_twos", *, max_steps: int = 4) -> int:
    """Convert common CW/relative CC encodings into signed steps.

    relative_twos: 1..63 positive, 65..127 negative (127 = -1); 0/64 idle.
    relative_centered: 63 = -1, 65 = +1, with values around 64 interpreted
    as small signed steps. Values are clamped to prevent sudden EQ jumps.
    """
    try:
        raw = int(value)
    except (TypeError, ValueError):
        return 0
    if raw < 0 or raw > 127 or raw in (0, 64):
        return 0
    mode_key = normalize_knob_mode(mode)
    if mode_key == "relative_centered":
        delta = raw - 64
    else:
        delta = raw if raw < 64 else raw - 128
    bound = max(1, abs(int(max_steps)))
    return max(-bound, min(bound, delta))


def absolute_cc_to_gain(value: int, *, invert: bool = False) -> float:
    """Map an absolute 7-bit CC to EQ gain, with an exact neutral center.

    MIDI CC has integer values, so the mathematical midpoint of -12..+12 dB
    (63.5) cannot be represented. Treat 63 and 64 as the one-step center detent,
    then scale each half independently so the endpoints remain exactly -12/+12 dB.
    """
    try:
        raw = int(value)
    except (TypeError, ValueError):
        raw = 64
    raw = max(0, min(127, raw))
    if invert:
        raw = 127 - raw
    if raw in (63, 64):
        return 0.0
    if raw < 63:
        gain = -12.0 + (raw / 63.0) * 12.0
    else:
        gain = ((raw - 64) / 63.0) * 12.0
    rounded = round(gain, 1)
    return 0.0 if rounded == 0 else rounded


def apply_relative_gain_step(current: float, delta: int, step_db: float) -> float:
    """Apply a relative encoder delta and snap through zero to an exact 0.0 dB.

    If one encoder step crosses the neutral point (for example -0.1 to +0.4 dB),
    the first step lands on 0.0 dB. The next step continues in the new direction.
    This avoids requiring the user to use Flat just to neutralize a band.
    """
    try:
        old = max(-12.0, min(12.0, float(current)))
        delta_value = int(delta)
        step = max(0.0, abs(float(step_db)))
    except (TypeError, ValueError):
        return 0.0
    if delta_value == 0 or step == 0.0:
        return 0.0 if round(old, 1) == 0 else round(old, 1)
    raw = max(-12.0, min(12.0, old + delta_value * step))
    # Crossing sign or rounding exactly to zero must result in literal 0.0.
    if old * raw < 0 or round(raw, 1) == 0:
        return 0.0
    rounded = round(raw, 1)
    return 0.0 if rounded == 0 else rounded


def apply_relative_step(current: float, value: int, step_db: float, mode: object = "relative_twos") -> float:
    delta = decode_relative_delta(value, mode)
    return apply_relative_gain_step(current, delta, step_db)
