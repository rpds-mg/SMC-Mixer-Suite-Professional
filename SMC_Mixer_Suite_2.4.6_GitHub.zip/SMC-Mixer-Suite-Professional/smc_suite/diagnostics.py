"""Local-only logging and sanitized diagnostic export."""
from __future__ import annotations

import logging
import logging.handlers
import os
import platform
import sys
import tempfile
import threading
import zipfile
from datetime import datetime
from pathlib import Path

APP_DIR = Path(os.environ.get("APPDATA", str(Path.home()))) / "SMCMixerSuite"
LOG_DIR = APP_DIR / "logs"
LOG_FILE = LOG_DIR / "smc_mixer_suite.log"


def setup_logging() -> logging.Logger:
    """Initialize rotating local logs without making logging a startup dependency."""
    global LOG_DIR, LOG_FILE
    logger = logging.getLogger("smc_mixer_suite")
    logger.setLevel(logging.INFO)
    if not any(getattr(handler, "_smc_suite_handler", False) for handler in logger.handlers):
        candidates = [
            Path(os.environ.get("APPDATA", str(Path.home()))) / "SMCMixerSuite" / "logs",
            Path.home() / "SMCMixerSuite" / "logs",
            Path(tempfile.gettempdir()) / "SMCMixerSuite" / "logs",
        ]
        handler = None
        for candidate in candidates:
            try:
                candidate.mkdir(parents=True, exist_ok=True)
                # Test write permission before constructing the rotating handler.
                with tempfile.NamedTemporaryFile(prefix=".log-write-test-", dir=candidate, delete=True):
                    pass
                file_path = candidate / "smc_mixer_suite.log"
                handler = logging.handlers.RotatingFileHandler(
                    file_path, maxBytes=1_500_000, backupCount=3, encoding="utf-8"
                )
                LOG_DIR = candidate
                LOG_FILE = file_path
                break
            except OSError:
                continue
        if handler is not None:
            handler._smc_suite_handler = True  # type: ignore[attr-defined]
            handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(threadName)s | %(message)s"))
            logger.addHandler(handler)
        else:
            # Last-resort logging must never prevent the app window from opening.
            logger.addHandler(logging.NullHandler())
    logger.info("Diagnostics logger initialized")

    def _handle_exception(exc_type, exc_value, exc_traceback):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        logger.critical("Uncaught exception", exc_info=(exc_type, exc_value, exc_traceback))

    sys.excepthook = _handle_exception
    if hasattr(threading, "excepthook"):
        def _thread_exception(args):
            logger.critical("Uncaught thread exception in %s", getattr(args, "thread", None),
                            exc_info=(args.exc_type, args.exc_value, args.exc_traceback))
        threading.excepthook = _thread_exception
    return logger


def log_exception(context: str, exc: BaseException) -> None:
    logging.getLogger("smc_mixer_suite").exception("%s: %s", context, exc)


def build_diagnostics_archive(destination: str | Path, version: str, midi_ports: list[str] | None = None) -> Path:
    """Create a ZIP containing app/version/environment and logs, never settings or passwords."""
    dest = Path(destination).expanduser()
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        import PyQt6
        qt_version = getattr(PyQt6, "__version__", "installed")
    except Exception:
        qt_version = "not importable"
    try:
        from smc_suite.config_store import APP_DIR as settings_dir
    except Exception:
        settings_dir = APP_DIR
    report = "\n".join([
        "SMC Mixer Suite — relatório de diagnóstico",
        f"Data local: {datetime.now().astimezone().isoformat(timespec='seconds')}",
        f"Versão do aplicativo: {version}",
        f"Sistema: {platform.platform()}",
        f"Python: {sys.version.replace(os.linesep, ' ')}",
        f"Qt: {qt_version}",
        f"Pasta de configurações: {settings_dir}",
        "Portas MIDI encontradas (nomes do driver):",
        *[f"  - {port}" for port in (midi_ports or [])],
        "",
        "Privacidade: este pacote não inclui settings.json, senhas nem perfis. O log pode conter caminhos de arquivos ou mensagens de erro.",
        "Revise o pacote antes de compartilhar.",
    ])
    with zipfile.ZipFile(dest, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("diagnostic_report.txt", report)
        if LOG_FILE.exists():
            archive.write(LOG_FILE, arcname="logs/smc_mixer_suite.log")
            for backup in sorted(LOG_DIR.glob("smc_mixer_suite.log.*")):
                archive.write(backup, arcname=f"logs/{backup.name}")
    return dest

