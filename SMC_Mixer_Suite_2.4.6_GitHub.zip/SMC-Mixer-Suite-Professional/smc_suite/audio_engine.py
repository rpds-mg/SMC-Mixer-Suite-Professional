from __future__ import annotations

import logging
import math
import threading
import time
from typing import Any


class AudioEngine:
    """Thin pycaw adapter for Windows endpoint and per-process session volume."""

    def __init__(self) -> None:
        self.available = False
        self.error = ""
        self._brightness_lock = threading.RLock()
        self._brightness_cache: dict[str, int] = {}
        self._brightness_cache_time: dict[str, float] = {}
        self._brightness_targets_cache: list[tuple[str, str]] = []
        self._brightness_targets_cache_time = 0.0
        try:
            from pycaw.pycaw import AudioUtilities  # noqa: F401
            self.available = True
        except Exception as exc:  # On non-Windows, allow the GUI to open in diagnostic mode.
            self.error = str(exc)

    @staticmethod
    def _audio_utilities():
        from pycaw.pycaw import AudioUtilities
        return AudioUtilities

    @staticmethod
    def _safe_name(process: Any) -> str:
        try:
            return process.name()
        except Exception:
            return ""

    def list_processes(self) -> list[dict[str, Any]]:
        results: dict[str, dict[str, Any]] = {}
        try:
            sessions = self._audio_utilities().GetAllSessions()
        except Exception as exc:
            self.error = str(exc)
            return []
        for session in sessions:
            try:
                process = session.Process
                if process is None:
                    continue
                name = self._safe_name(process)
                if not name:
                    continue
                key = name.casefold()
                volume = float(session.SimpleAudioVolume.GetMasterVolume())
                if key not in results:
                    results[key] = {"key": name, "name": name.removesuffix(".exe"), "volume": volume}
            except Exception:
                continue
        return sorted(results.values(), key=lambda x: x["name"].casefold())

    def _master_endpoint(self):
        return self._audio_utilities().GetSpeakers().EndpointVolume

    @staticmethod
    def is_brightness_target(target: str) -> bool:
        return str(target).startswith("__brightness__:")

    @staticmethod
    def brightness_display_index(target: str) -> int:
        try:
            return max(0, int(str(target).partition(":")[2]))
        except (TypeError, ValueError):
            return 0

    @staticmethod
    def _coerce_brightness_result(value: Any) -> int | None:
        if isinstance(value, (list, tuple)):
            value = value[0] if value else None
        try:
            value = int(round(float(value)))
        except (TypeError, ValueError):
            return None
        return max(0, min(100, value))

    @staticmethod
    def _read_session_peak(session: Any) -> float | None:
        """Best-effort per-session peak meter. Windows may not expose this COM interface on every session."""
        try:
            from pycaw.pycaw import IAudioMeterInformation
            control = getattr(session, "_ctl", None)
            if control is None:
                return None
            meter = control.QueryInterface(IAudioMeterInformation)
            value = meter.GetPeakValue()
            if isinstance(value, (tuple, list)):
                value = value[0] if value else 0.0
            peak = max(0.0, min(1.0, float(value)))
            return peak
        except Exception:
            return None

    def _read_master_peak(self) -> float | None:
        try:
            from pycaw.pycaw import IAudioMeterInformation
            speakers = self._audio_utilities().GetSpeakers()
            if speakers is None:
                return None
            iface = speakers._dev.Activate(IAudioMeterInformation._iid_, 23, None)
            meter = iface.QueryInterface(IAudioMeterInformation)
            value = meter.GetPeakValue()
            if isinstance(value, (tuple, list)):
                value = value[0] if value else 0.0
            return max(0.0, min(1.0, float(value)))
        except Exception:
            return None

    @staticmethod
    def _peak_to_db(peak: float | None) -> float | None:
        if peak is None:
            return None
        if peak <= 1e-6:
            return -60.0
        return max(-60.0, min(0.0, 20.0 * math.log10(peak)))

    def list_brightness_targets(self) -> list[tuple[str, str]]:
        """List brightness-capable displays best-effort, with a safe primary fallback.

        The actual ability to read/write brightness depends on the monitor and driver.
        The screen_brightness_control library may expose internal/USB/DDC displays; a
        target is not advertised as guaranteed until a read/write succeeds.
        """
        now = time.monotonic()
        with self._brightness_lock:
            if self._brightness_targets_cache and now - self._brightness_targets_cache_time < 20.0:
                return list(self._brightness_targets_cache)
        try:
            import screen_brightness_control as sbc
            rows = sbc.list_monitors_info()
            targets: list[tuple[str, str]] = []
            seen: set[str] = set()
            for position, info in enumerate(rows or []):
                if not isinstance(info, dict):
                    continue
                # `display` is the library's enumeration index, not the Windows device ID.
                display_index = position
                manufacturer = str(info.get("manufacturer", "") or "").strip()
                model = str(info.get("model", "") or info.get("name", "") or "").strip()
                serial = str(info.get("serial", "") or "").strip()
                label_parts = [part for part in (manufacturer, model) if part]
                label = " ".join(label_parts) or f"Monitor {position + 1}"
                if serial and serial not in label:
                    label += f" · {serial}"
                key = f"__brightness__:{display_index}"
                if key not in seen:
                    targets.append((f"Brilho da tela · {label}", key))
                    seen.add(key)
            if targets:
                with self._brightness_lock:
                    self._brightness_targets_cache = list(targets)
                    self._brightness_targets_cache_time = now
                return targets
        except Exception as exc:
            logging.getLogger("smc_mixer_suite").debug("Monitor enumeration unavailable: %s", exc)
        fallback = [("Brilho da tela · monitor principal (se compatível)", "__brightness__:0")]
        with self._brightness_lock:
            self._brightness_targets_cache = list(fallback)
            self._brightness_targets_cache_time = now
        return fallback

    def set_brightness(self, target: str, scalar: float) -> bool:
        if not self.is_brightness_target(target):
            return False
        try:
            import screen_brightness_control as sbc
            percent = max(0, min(100, int(round(float(scalar) * 100))))
            with self._brightness_lock:
                sbc.set_brightness(percent, display=self.brightness_display_index(target), no_return=True)
                self._brightness_cache[target] = percent
                self._brightness_cache_time[target] = time.monotonic()
            return True
        except Exception as exc:
            self.error = str(exc)
            logging.getLogger("smc_mixer_suite").warning("Display brightness write failed for %s: %s", target, exc)
            return False

    def get_brightness(self, target: str) -> int | None:
        if not self.is_brightness_target(target):
            return None
        try:
            import screen_brightness_control as sbc
            now = time.monotonic()
            with self._brightness_lock:
                cached = self._brightness_cache.get(target)
                cached_at = self._brightness_cache_time.get(target, 0.0)
                if cached is not None and now - cached_at < 0.8:
                    return cached
                values = sbc.get_brightness(display=self.brightness_display_index(target), verbose_error=False)
                percent = self._coerce_brightness_result(values)
                if percent is not None:
                    self._brightness_cache[target] = percent
                    self._brightness_cache_time[target] = now
                return percent
        except Exception as exc:
            self.error = str(exc)
            return None

    def get_audio_snapshot(self, targets: list[str]) -> dict[str, Any]:
        """Read Windows session volumes and best-effort peak values in one worker-thread snapshot."""
        target_keys = {
            str(target).casefold(): str(target) for target in targets
            if target and target != "__master__" and not self.is_brightness_target(str(target))
        }
        result: dict[str, Any] = {
            "processes": [],
            "volumes": {str(target): None for target in targets},
            "mutes": {str(target): None for target in targets},
            "levels_db": {str(target): None for target in targets},
            "levels_are_peak": {str(target): False for target in targets},
            "microphone_volume": None,
            "microphone_mute": None,
            "error": "",
        }
        # Screen brightness is optional and is read in this worker to avoid blocking Qt.
        for target in targets:
            if self.is_brightness_target(str(target)):
                brightness = self.get_brightness(str(target))
                if brightness is not None:
                    result["volumes"][str(target)] = brightness / 100.0
                    result["mutes"][str(target)] = False
                    result["levels_db"][str(target)] = self._peak_to_db(brightness / 100.0)
                    result["levels_are_peak"][str(target)] = False
        if not self.available:
            result["error"] = self.error or "PyCAW indisponível"
            return result

        process_acc: dict[str, dict[str, Any]] = {}
        volume_totals: dict[str, float] = {}
        volume_counts: dict[str, int] = {}
        mute_states: dict[str, list[bool]] = {}
        session_peaks: dict[str, list[float]] = {}
        try:
            result["microphone_volume"] = self.get_microphone_volume()
            result["microphone_mute"] = self.get_microphone_mute()
            if "__master__" in result["volumes"]:
                try:
                    endpoint = self._master_endpoint()
                    scalar = max(0.0, min(1.0, float(endpoint.GetMasterVolumeLevelScalar())))
                    result["volumes"]["__master__"] = scalar
                    result["mutes"]["__master__"] = bool(endpoint.GetMute())
                    master_peak = self._read_master_peak()
                    result["levels_db"]["__master__"] = self._peak_to_db(master_peak) if master_peak is not None else self._peak_to_db(scalar)
                    result["levels_are_peak"]["__master__"] = master_peak is not None
                except Exception as exc:
                    result["error"] = f"Não foi possível consultar o dispositivo master: {exc}"
            sessions = self._audio_utilities().GetAllSessions()
            for session in sessions:
                try:
                    process = session.Process
                    if process is None:
                        continue
                    exe = self._safe_name(process)
                    if not exe:
                        continue
                    key = exe.casefold()
                    try:
                        pid_value = getattr(process, "pid", 0)
                        pid = int(pid_value() if callable(pid_value) else pid_value)
                    except Exception:
                        pid = 0
                    name = exe.removesuffix(".exe")
                    if key not in process_acc:
                        process_acc[key] = {"key": exe, "name": name, "volume": 0.0, "session_count": 0, "pids": []}
                    row = process_acc[key]
                    try:
                        row["volume"] += float(session.SimpleAudioVolume.GetMasterVolume())
                        row["session_count"] += 1
                    except Exception:
                        pass
                    if pid and pid not in row["pids"]:
                        row["pids"].append(pid)
                    if key in target_keys:
                        target = target_keys[key]
                        try:
                            volume_totals[key] = volume_totals.get(key, 0.0) + float(session.SimpleAudioVolume.GetMasterVolume())
                            volume_counts[key] = volume_counts.get(key, 0) + 1
                            mute_states.setdefault(key, []).append(bool(session.SimpleAudioVolume.GetMute()))
                        except Exception:
                            pass
                        peak = self._read_session_peak(session)
                        if peak is not None:
                            session_peaks.setdefault(key, []).append(peak)
                except Exception:
                    continue
            for row in process_acc.values():
                count = max(1, int(row.pop("session_count", 0)))
                row["volume"] = max(0.0, min(1.0, float(row["volume"]) / count))
                row["sessions"] = count
                row["pids"] = row["pids"][:8]
            result["processes"] = sorted(process_acc.values(), key=lambda row: row["name"].casefold())
            for folded, target in target_keys.items():
                count = volume_counts.get(folded, 0)
                if count:
                    result["volumes"][target] = max(0.0, min(1.0, volume_totals[folded] / count))
                    result["mutes"][target] = any(mute_states.get(folded, []))
                    peaks = session_peaks.get(folded, [])
                    if peaks:
                        result["levels_db"][target] = self._peak_to_db(max(peaks))
                        result["levels_are_peak"][target] = True
                    else:
                        result["levels_db"][target] = self._peak_to_db(result["volumes"][target])
                        result["levels_are_peak"][target] = False
        except Exception as exc:
            self.error = str(exc)
            result["error"] = self.error
            logging.getLogger("smc_mixer_suite").warning("Audio snapshot failed: %s", exc)
        return result

    def get_mutes(self, targets: list[str]) -> dict[str, bool | None]:
        """Query mute states for multiple targets with one COM session enumeration."""
        result: dict[str, bool | None] = {str(target): None for target in targets}
        if not self.available:
            return result
        try:
            if "__master__" in result:
                result["__master__"] = bool(self._master_endpoint().GetMute())
            wanted = {str(target).casefold(): str(target) for target in targets if target and target != "__master__"}
            states: dict[str, list[bool]] = {}
            for session in self._audio_utilities().GetAllSessions():
                try:
                    process = session.Process
                    if process is None:
                        continue
                    key = self._safe_name(process).casefold()
                    if key in wanted:
                        states.setdefault(key, []).append(bool(session.SimpleAudioVolume.GetMute()))
                except Exception:
                    continue
            for key, target in wanted.items():
                if key in states:
                    result[target] = any(states[key])
        except Exception as exc:
            self.error = str(exc)
        return result

    def get_volume(self, target: str) -> float | None:
        if not self.available:
            return None
        try:
            if target == "__master__":
                return max(0.0, min(1.0, float(self._master_endpoint().GetMasterVolumeLevelScalar())))
            target_key = target.casefold()
            values = []
            for session in self._audio_utilities().GetAllSessions():
                try:
                    if session.Process and self._safe_name(session.Process).casefold() == target_key:
                        values.append(float(session.SimpleAudioVolume.GetMasterVolume()))
                except Exception:
                    continue
            return max(0.0, min(1.0, sum(values) / len(values))) if values else None
        except Exception as exc:
            self.error = str(exc)
            return None

    def get_volumes(self, targets: list[str]) -> dict[str, float | None]:
        """Read several targets in one session enumeration to keep the UI responsive."""
        result: dict[str, float | None] = {str(target): None for target in targets}
        if not self.available:
            return result
        try:
            if "__master__" in result:
                result["__master__"] = max(0.0, min(1.0, float(self._master_endpoint().GetMasterVolumeLevelScalar())))
            wanted = {str(target).casefold(): str(target) for target in targets if target and target != "__master__"}
            totals: dict[str, float] = {}
            counts: dict[str, int] = {}
            if wanted:
                for session in self._audio_utilities().GetAllSessions():
                    try:
                        process = session.Process
                        if process is None:
                            continue
                        process_name = self._safe_name(process)
                        key = process_name.casefold()
                        if key not in wanted:
                            continue
                        totals[key] = totals.get(key, 0.0) + float(session.SimpleAudioVolume.GetMasterVolume())
                        counts[key] = counts.get(key, 0) + 1
                    except Exception:
                        continue
            for folded, total in totals.items():
                original = wanted[folded]
                result[original] = max(0.0, min(1.0, total / max(1, counts[folded])))
        except Exception as exc:
            self.error = str(exc)
        return result

    def set_volumes(self, updates: dict[str, float]) -> dict[str, bool]:
        """Apply multiple master/process levels and display-brightness targets."""
        outcomes = {str(target): False for target in updates}
        normalized: dict[str, float] = {}
        for target, scalar in updates.items():
            try:
                normalized[str(target)] = max(0.0, min(1.0, float(scalar)))
            except (TypeError, ValueError):
                continue
        # Brightness is optional and routed separately from the audio-session APIs.
        for target, scalar in list(normalized.items()):
            if self.is_brightness_target(target):
                outcomes[target] = self.set_brightness(target, scalar)
                normalized.pop(target, None)
        if not normalized or not self.available:
            return outcomes
        try:
            master_scalar = normalized.get("__master__")
            if master_scalar is not None:
                self._master_endpoint().SetMasterVolumeLevelScalar(master_scalar, None)
                outcomes["__master__"] = True
            wanted = {target.casefold(): (target, scalar) for target, scalar in normalized.items() if target != "__master__"}
            if wanted:
                changed: set[str] = set()
                for session in self._audio_utilities().GetAllSessions():
                    try:
                        process = session.Process
                        if process is None:
                            continue
                        key = self._safe_name(process).casefold()
                        match = wanted.get(key)
                        if match is None:
                            continue
                        target, scalar = match
                        session.SimpleAudioVolume.SetMasterVolume(scalar, None)
                        changed.add(target)
                    except Exception:
                        continue
                for target in changed:
                    outcomes[target] = True
        except Exception as exc:
            self.error = str(exc)
            logging.getLogger("smc_mixer_suite").warning("Batch volume update failed: %s", exc)
        return outcomes

    def set_volume(self, target: str, scalar: float) -> bool:
        if not self.available:
            return False
        return bool(self.set_volumes({str(target): float(scalar)}).get(str(target), False))

    def get_mute(self, target: str) -> bool | None:
        """Return mute state for master or matching process sessions."""
        if not self.available:
            return None
        try:
            if target == "__master__":
                return bool(self._master_endpoint().GetMute())
            target_key = target.casefold()
            states = []
            for session in self._audio_utilities().GetAllSessions():
                try:
                    if session.Process and self._safe_name(session.Process).casefold() == target_key:
                        states.append(bool(session.SimpleAudioVolume.GetMute()))
                except Exception:
                    continue
            return any(states) if states else None
        except Exception as exc:
            self.error = str(exc)
            return None

    def set_mutes(self, updates: dict[str, bool]) -> dict[str, bool]:
        """Set several mute states with one Windows session enumeration."""
        outcomes = {str(target): False for target in updates}
        if not self.available or not updates:
            return outcomes
        normalized = {str(target): bool(muted) for target, muted in updates.items()}
        try:
            if "__master__" in normalized:
                self._master_endpoint().SetMute(1 if normalized["__master__"] else 0, None)
                outcomes["__master__"] = True
            wanted = {target.casefold(): (target, muted) for target, muted in normalized.items() if target != "__master__"}
            changed: set[str] = set()
            if wanted:
                for session in self._audio_utilities().GetAllSessions():
                    try:
                        process = session.Process
                        if process is None:
                            continue
                        match = wanted.get(self._safe_name(process).casefold())
                        if match is None:
                            continue
                        target, muted = match
                        session.SimpleAudioVolume.SetMute(1 if muted else 0, None)
                        changed.add(target)
                    except Exception:
                        continue
            for target in changed:
                outcomes[target] = True
        except Exception as exc:
            self.error = str(exc)
            logging.getLogger("smc_mixer_suite").warning("Batch mute update failed: %s", exc)
        return outcomes

    def set_mute(self, target: str, muted: bool) -> bool:
        """Set mute state rather than toggling, useful for restoring Solo state."""
        return bool(self.set_mutes({str(target): bool(muted)}).get(str(target), False))

    def toggle_mute(self, target: str = "__master__") -> bool:
        if not self.available:
            return False
        try:
            if target == "__master__":
                endpoint = self._master_endpoint()
                endpoint.SetMute(0 if endpoint.GetMute() else 1, None)
                return True
            target_key = target.casefold()
            changed = False
            for session in self._audio_utilities().GetAllSessions():
                try:
                    if session.Process and self._safe_name(session.Process).casefold() == target_key:
                        vol = session.SimpleAudioVolume
                        vol.SetMute(0 if vol.GetMute() else 1, None)
                        changed = True
                except Exception:
                    continue
            return changed
        except Exception as exc:
            self.error = str(exc)
            return False

    def _microphone_endpoint(self):
        utilities = self._audio_utilities()
        microphone = utilities.GetMicrophone()
        if microphone is None:
            return None
        try:
            microphone = utilities.CreateDevice(microphone)
        except Exception:
            pass
        return getattr(microphone, "EndpointVolume", None)

    def get_microphone_volume(self) -> float | None:
        """Read the default capture endpoint scalar, when exposed by the driver."""
        if not self.available:
            return None
        try:
            endpoint = self._microphone_endpoint()
            if endpoint is None:
                return None
            return max(0.0, min(1.0, float(endpoint.GetMasterVolumeLevelScalar())))
        except Exception as exc:
            self.error = str(exc)
            return None

    def set_microphone_volume(self, scalar: float) -> bool:
        """Set the default capture endpoint level without changing application playback."""
        if not self.available:
            return False
        try:
            value = max(0.0, min(1.0, float(scalar)))
            endpoint = self._microphone_endpoint()
            if endpoint is None:
                return False
            endpoint.SetMasterVolumeLevelScalar(value, None)
            return True
        except Exception as exc:
            self.error = str(exc)
            logging.getLogger("smc_mixer_suite").warning("Microphone volume write failed: %s", exc)
            return False

    def get_microphone_mute(self) -> bool | None:
        if not self.available:
            return None
        try:
            endpoint = self._microphone_endpoint()
            return bool(endpoint.GetMute()) if endpoint is not None else None
        except Exception as exc:
            self.error = str(exc)
            return None

    def toggle_microphone_mute(self) -> bool:
        """Toggles the default/first available capture endpoint using pycaw."""
        if not self.available:
            return False
        try:
            endpoint = self._microphone_endpoint()
            if endpoint is None:
                return False
            endpoint.SetMute(0 if endpoint.GetMute() else 1, None)
            return True
        except Exception as exc:
            self.error = str(exc)
            return False

    @staticmethod
    def percent_db(scalar: float | None) -> str:
        if scalar is None:
            return "—"
        percent = max(0.0, min(1.0, scalar)) * 100
        db = "−∞ dB" if scalar <= 0 else f"{20 * math.log10(scalar):+.1f} dB"
        return f"{percent:.0f}%  ·  {db}"
