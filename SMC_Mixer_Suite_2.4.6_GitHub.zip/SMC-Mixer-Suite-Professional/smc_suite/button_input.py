"""Debounce and normalize physical MIDI button presses.

Some controllers send Note On/Off; others send CC 127/0, alternate between
non-zero values, or only send a fixed positive CC on each tap. A plain
``value != previous_value`` test drops repeated fixed-value presses. This gate
handles those variants while suppressing very fast duplicate packets. The repeat
window is intentionally short enough for ordinary human double taps while still
filtering typical switch bounce.
"""
from __future__ import annotations

import time
from collections.abc import Iterable


class MidiButtonPressGate:
    """Convert MIDI input messages into one logical activation per button press."""

    def __init__(self, min_interval: float = 0.070, repeat_cc_interval: float = 0.110) -> None:
        self.min_interval = max(0.0, float(min_interval))
        self.repeat_cc_interval = max(self.min_interval, float(repeat_cc_interval))
        self._last_activation: dict[str, float] = {}

    def mark_consumed(self, key: str, now: float | None = None) -> None:
        """Mark a message used by MIDI Learn so switch bounce cannot execute it."""
        self._last_activation[str(key)] = time.monotonic() if now is None else float(now)

    def reset(self, key: str) -> None:
        self._last_activation.pop(str(key), None)

    def reset_all(self) -> None:
        """Clear debounce memory after a MIDI disconnect or port replacement."""
        self._last_activation.clear()

    def should_activate(
        self,
        key: str,
        msg_type: str,
        value: int,
        previous_value: int,
        analog_keys: Iterable[str] = (),
        now: float | None = None,
        trigger_mode: str = "auto",
    ) -> bool:
        key = str(key)
        value = int(value)
        previous_value = int(previous_value)
        current_time = time.monotonic() if now is None else float(now)

        # Faders/knobs send continuous CC streams, never interpret them as buttons.
        if key in set(analog_keys):
            return False

        last = self._last_activation.get(key, float("-inf"))
        elapsed = current_time - last
        if elapsed < self.min_interval:
            return False

        mode = str(trigger_mode or "auto").strip().lower()
        if mode not in {"auto", "cc_single_toggle", "cc_push", "note"}:
            mode = "auto"

        if msg_type == "note_on":
            if mode == "cc_single_toggle" or mode == "cc_push" or value <= 0:
                return False
            self._last_activation[key] = current_time
            return True

        if msg_type != "cc" or mode == "note":
            return False

        # CC Single/Toggle on some controllers emits one CC per tap and alternates
        # between 0 and 127. In this explicit mode, either value is a click; debounce
        # suppresses packet bounce while ensuring 0-valued taps still execute.
        if mode == "cc_single_toggle":
            self._last_activation[key] = current_time
            return True

        if value <= 0:
            # Auto/CC Push treat zero as a release edge, not an activation.
            return False

        changed_positive = previous_value <= 0 or value != previous_value
        repeated_fixed_value = value == previous_value and elapsed >= self.repeat_cc_interval
        if not (changed_positive or repeated_fixed_value):
            return False

        self._last_activation[key] = current_time
        return True
