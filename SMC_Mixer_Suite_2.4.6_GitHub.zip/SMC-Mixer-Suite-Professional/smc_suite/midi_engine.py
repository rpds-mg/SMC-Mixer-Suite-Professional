from __future__ import annotations

import threading
import time
from PyQt6.QtCore import QThread, pyqtSignal


class MidiEngine(QThread):
    """Reconnectable MIDI input worker. All MIDI access happens off the GUI thread."""
    message_received = pyqtSignal(str, int, int, int)  # type, channel, number, value
    status_changed = pyqtSignal(str)
    ports_changed = pyqtSignal(list)

    def __init__(self, requested_port: str = "AUTO", parent=None) -> None:
        super().__init__(parent)
        self._requested_port = requested_port or "AUTO"
        self._requested_lock = threading.Lock()
        self._stop_event = threading.Event()
        self._rescan_event = threading.Event()
        self._last_ports: list[str] = []
        self._open_port_name: str | None = None

    def set_requested_port(self, name: str) -> None:
        with self._requested_lock:
            self._requested_port = name or "AUTO"
        self._rescan_event.set()

    def request_rescan(self) -> None:
        self._rescan_event.set()

    def stop(self) -> None:
        self._stop_event.set()
        self._rescan_event.set()
        self.wait(2500)

    @staticmethod
    def _list_ports() -> list[str]:
        try:
            import mido
            return list(mido.get_input_names())
        except Exception:
            return []

    def _choose_port(self, ports: list[str]) -> str | None:
        with self._requested_lock:
            requested = self._requested_port
        if not ports:
            return None
        if requested != "AUTO":
            # Do not silently attach to a different controller if the chosen port disappears.
            return requested if requested in ports else None
        for port in ports:
            low = port.casefold()
            if any(token in low for token in ("m-vave", "mvave", "smc", "midi mix", "sinco")):
                return port
        # A generic BLE-MIDI port is only a safe fallback if it is the only MIDI port.
        if len(ports) == 1 and any(token in ports[0].casefold() for token in ("bluetooth", "ble midi", "ble-midi")):
            return ports[0]
        # Avoid silently binding to a different controller when several MIDI ports exist.
        return ports[0] if len(ports) == 1 else None

    def run(self) -> None:
        try:
            import mido
        except Exception as exc:
            self.status_changed.emit(f"MIDI indisponível: {exc}")
            return

        while not self._stop_event.is_set():
            ports = self._list_ports()
            if ports != self._last_ports:
                self._last_ports = ports
                self.ports_changed.emit(ports)
            target = self._choose_port(ports)
            if target is None:
                self._open_port_name = None
                with self._requested_lock:
                    requested = self._requested_port
                if requested != "AUTO" and ports:
                    self.status_changed.emit(f"A porta MIDI selecionada não está disponível: {requested}. Aguardando reconexão…")
                else:
                    if ports:
                        self.status_changed.emit("Nenhum SMC-Mixer foi identificado automaticamente. Selecione a porta correta em Configurações.")
                    else:
                        self.status_changed.emit("Nenhuma porta MIDI encontrada. Conecte o SMC-Mixer e clique em Reescanear.")
                self._rescan_event.wait(1.0)
                self._rescan_event.clear()
                continue

            try:
                self.status_changed.emit(f"Conectando: {target}")
                with mido.open_input(target) as input_port:
                    self._open_port_name = target
                    self.status_changed.emit(f"MIDI conectado: {target}")
                    last_ports_check = time.monotonic()
                    while not self._stop_event.is_set():
                        if self._rescan_event.is_set():
                            break
                        now = time.monotonic()
                        if now - last_ports_check >= 1.0:
                            current_ports = self._list_ports()
                            if current_ports != self._last_ports:
                                self._last_ports = current_ports
                                self.ports_changed.emit(current_ports)
                            if target not in current_ports:
                                break
                            last_ports_check = now
                        try:
                            msg = input_port.poll()
                            if msg is None:
                                time.sleep(0.004)
                                continue
                            if msg.type == "control_change":
                                self.message_received.emit("cc", int(getattr(msg, "channel", 0)), int(msg.control), int(msg.value))
                            elif msg.type in ("note_on", "note_off"):
                                self.message_received.emit(msg.type, int(getattr(msg, "channel", 0)), int(msg.note), int(msg.velocity))
                        except Exception as exc:
                            self.status_changed.emit(f"Falha na leitura MIDI; tentando reconectar: {exc}")
                            break
            except Exception as exc:
                self._open_port_name = None
                self.status_changed.emit(f"Não foi possível abrir MIDI ({target}): {exc}. Nova tentativa automática…")
            self._open_port_name = None
            if not self._stop_event.is_set():
                self._rescan_event.wait(1.0)
                self._rescan_event.clear()
        self.status_changed.emit("MIDI desconectado")
