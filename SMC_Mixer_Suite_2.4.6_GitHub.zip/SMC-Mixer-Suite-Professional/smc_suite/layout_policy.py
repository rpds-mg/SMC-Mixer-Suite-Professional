"""Pure layout policy helpers so responsive behavior can be tested without Qt."""
from __future__ import annotations


def choose_eq_grid_columns(available_width: int, band_count: int, *, min_card_width: int = 104, spacing: int = 5) -> int:
    """Choose an EQ grid column count that avoids horizontal overflow.

    Keep all bands on a single row whenever the viewport can comfortably fit
    them. If it cannot, use a 4-column (or smaller) grid rather than horizontal
    scrolling. The smallest grid size is two columns when more than one band is
    present.
    """
    try:
        width = max(0, int(available_width))
        count = max(1, min(8, int(band_count)))
        card_width = max(84, int(min_card_width))
        gap = max(0, int(spacing))
    except (TypeError, ValueError):
        return 1

    required = count * card_width + max(0, count - 1) * gap + 16
    if width >= required:
        return count
    if count <= 4:
        return count

    # Prefer a balanced two-row layout over very narrow cards.
    if width >= 4 * card_width + 3 * gap + 16:
        return 4
    if width >= 3 * card_width + 2 * gap + 16:
        return 3
    if width >= 2 * card_width + gap + 16:
        return 2
    return 1


def effective_compact_mode(user_compact: bool, width: int, height: int) -> bool:
    """Enable compact spacing for small work areas without overriding preference."""
    try:
        w = int(width)
        h = int(height)
    except (TypeError, ValueError):
        return bool(user_compact)
    return bool(user_compact) or w < 1380 or h < 790


def should_use_compact_channel_strips(width: int, *, channel_count: int = 8, minimum_width: int = 116) -> bool:
    """Use narrower channel strips when the console has limited horizontal room."""
    try:
        w = int(width)
        count = max(1, int(channel_count))
        minimum = max(90, int(minimum_width))
    except (TypeError, ValueError):
        return True
    # Account for strip gaps, panel margins and the left/right console padding.
    required = count * minimum + (count - 1) * 4 + 34
    return w < required


def recommended_channel_strip_width(available_width: int, *, channel_count: int = 8) -> int:
    """Calculate a minimum strip width that lets eight channels share the viewport.

    Reserve room for panel padding and the seven inter-strip gaps first. The
    function never returns less than 90 px, the usable compact lower bound.
    """
    try:
        width = max(0, int(available_width))
        count = max(1, int(channel_count))
    except (TypeError, ValueError):
        return 90
    allocation = (width - 34 - (count - 1) * 4) // count
    return max(90, min(116, allocation))
