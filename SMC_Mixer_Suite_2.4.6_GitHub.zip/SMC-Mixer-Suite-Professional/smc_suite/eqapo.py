from __future__ import annotations

import math
import os
from pathlib import Path
from typing import Iterable

from smc_suite.eq_model import DEFAULT_FREQUENCIES, clamp_gain, normalize_mode, sanitize_frequencies

FREQUENCIES = [int(v) for v in DEFAULT_FREQUENCIES["8"]]
LABELS = ["63 Hz", "125 Hz", "250 Hz", "500 Hz", "1 kHz", "2 kHz", "8 kHz", "16 kHz"]


def _clamp_number(value: object, minimum: float, maximum: float, default: float) -> float:
    try:
        number = float(value)
        if not math.isfinite(number):
            return default
        return max(minimum, min(maximum, number))
    except (TypeError, ValueError):
        return default


def render_config(
    gains: list[float],
    bypass: bool = False,
    band7_freq: int = 8000,
    *,
    mode: int | str = 8,
    frequencies: Iterable[float] | None = None,
    low_cut_enabled: bool = False,
    low_cut_hz: float = 20.0,
    high_cut_enabled: bool = False,
    high_cut_hz: float = 20000.0,
) -> str:
    """Create a system-wide Equalizer APO configuration.

    Pycaw is a volume/session API, not a DSP engine. This module writes native
    Equalizer APO filters so processing is done in the Windows audio path rather
    than by opening a risky Python loopback stream. HP/LP filters are omitted
    when disabled or when global bypass is enabled.
    """
    mode_key = normalize_mode(mode)
    count = int(mode_key)
    freq_source = list(frequencies) if frequencies is not None else DEFAULT_FREQUENCIES[mode_key].copy()
    if mode_key == "8" and frequencies is None:
        freq_source[6] = float(band7_freq if int(band7_freq) in (4000, 8000) else 8000)
    freqs = sanitize_frequencies(freq_source, mode_key)
    fixed_gains = [clamp_gain(float(gains[i]) if i < len(gains) else 0.0) for i in range(count)]
    low_cut_hz = _clamp_number(low_cut_hz, 20.0, 200.0, 20.0)
    high_cut_hz = _clamp_number(high_cut_hz, 5000.0, 20000.0, 20000.0)
    if high_cut_hz <= low_cut_hz:
        high_cut_hz = min(20000.0, max(5000.0, low_cut_hz + 100.0))

    max_positive_gain = max((gain for gain in fixed_gains if gain > 0.0), default=0.0)
    headroom_db = 0.0 if bypass or max_positive_gain <= 0.0 else -(max_positive_gain + 3.0)
    state = "OFF" if bypass else "ON"
    lines = [
        "# SMC Mixer Suite — gerado automaticamente; ajuste pela interface.",
        "# O processamento é realizado pelo Equalizer APO no caminho de áudio do Windows.",
        f"# Modo: {count} bandas. Bypass global: {'ativado' if bypass else 'desativado'}.",
        f"# Low Cut: {'ativo' if low_cut_enabled and not bypass else 'desativado'} ({low_cut_hz:g} Hz).",
        f"# High Cut: {'ativo' if high_cut_enabled and not bypass else 'desativado'} ({high_cut_hz:g} Hz).",
        f"Preamp: {headroom_db:.2f} dB",
    ]

    filter_number = 1
    if low_cut_enabled:
        lines.append(f"Filter {filter_number}: {state} HP Fc {low_cut_hz:g} Hz")
        filter_number += 1

    for i, (freq, gain) in enumerate(zip(freqs, fixed_gains), start=0):
        band_number = filter_number
        # Shelves at the edges; parametric peaks in the middle.
        if i == 0:
            kind = "LS"
        elif i == count - 1:
            kind = "HS"
        else:
            kind = "PK"
        lines.append(
            f"Filter {band_number}: {state} {kind} Fc {freq:g} Hz "
            f"Gain {0.0 if bypass else gain:+.2f} dB Q 0.707"
        )
        filter_number += 1

    if high_cut_enabled:
        lines.append(f"Filter {filter_number}: {state} LP Fc {high_cut_hz:g} Hz")
    lines.append("")
    return "\n".join(lines)


def write_config(
    path: str,
    gains: list[float],
    bypass: bool = False,
    band7_freq: int = 8000,
    *,
    mode: int | str = 8,
    frequencies: Iterable[float] | None = None,
    low_cut_enabled: bool = False,
    low_cut_hz: float = 20.0,
    high_cut_enabled: bool = False,
    high_cut_hz: float = 20000.0,
) -> Path:
    destination = Path(os.path.expandvars(path)).expanduser()
    destination.parent.mkdir(parents=True, exist_ok=True)
    content = render_config(
        gains, bypass, band7_freq, mode=mode, frequencies=frequencies,
        low_cut_enabled=low_cut_enabled, low_cut_hz=low_cut_hz,
        high_cut_enabled=high_cut_enabled, high_cut_hz=high_cut_hz,
    )
    temp_path = destination.with_suffix(destination.suffix + ".tmp")
    try:
        temp_path.write_text(content, encoding="utf-8")
        os.replace(temp_path, destination)
    except PermissionError:
        # A linked Equalizer APO filter may live under Program Files. The setup
        # helper grants the current user Modify on that one existing file (not
        # on the whole APO folder); this permits updating the file in place but
        # intentionally does not grant permission to create/rename siblings.
        # Keep atomic replacement as the normal path and fall back only for an
        # existing destination whose folder is protected.
        try:
            temp_path.unlink(missing_ok=True)
        except OSError:
            pass
        if not destination.is_file():
            raise
        with destination.open("w", encoding="utf-8", newline="") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
    return destination


def include_line(path: str, config_dir: str | Path | None = None) -> str:
    """Return an APO Include line, preferring a relative path inside config_dir.

    Equalizer APO watches its configured folder more reliably than arbitrary
    external folders. The application normally stores its live filter file next
    to config.txt, so a simple filename avoids quoting/space issues and keeps
    Windows Audio's file access straightforward.
    """
    target = Path(os.path.expandvars(path)).expanduser().resolve()
    if config_dir is not None:
        base = Path(os.path.expandvars(str(config_dir))).expanduser().resolve()
        try:
            relative = target.relative_to(base)
        except ValueError:
            pass
        else:
            return f"Include: {relative.as_posix()}"
    normalized = str(target).replace("\\", "/")
    return f'Include: "{normalized}"'
