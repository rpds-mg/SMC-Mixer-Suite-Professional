"""SMC Mixer Suite: hardware control and system EQ integration."""
__version__ = "2.4.6"
