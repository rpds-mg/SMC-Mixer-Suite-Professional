from __future__ import annotations

import logging
import os
import subprocess
import threading
import time

try:
    import pyautogui  # optional until a keyboard/mouse action is actually used
except Exception:  # headless startup should not fail because PyAutoGUI cannot inspect a display
    pyautogui = None  # type: ignore[assignment]
try:
    import pyperclip
except Exception:
    pyperclip = None  # type: ignore[assignment]

MEDIA_VKS = {
    "Play / Pause": 0xB3,
    "Próxima faixa": 0xB0,
    "Faixa anterior": 0xB1,
    "Parar mídia": 0xB2,
    "Volume +": 0xAF,
    "Volume −": 0xAE,
    "Mute do sistema": 0xAD,
}

SYSTEM_ACTIONS = {
    "show_desktop", "explorer", "task_manager", "open_settings",
    "open_sound_settings", "open_display_settings", "open_network_settings",
    "lock_workstation", "volume_up", "volume_down", "volume_mute",
    "open_search", "open_clipboard", "open_notifications", "minimize_active",
    "maximize_active", "snap_left", "snap_right", "restore_active",
}

MACRO_SEQUENCE_ACTIONS = {
    "shortcut", "key_sequence", "text", "launch", "media", "system",
    "mute_master", "mute_microphone", "mute_app",
}


def parse_macro_sequence(raw: str, *, max_steps: int = 20) -> list[tuple[str, str]]:
    """Parse a user-configured macro sequence without executing arbitrary code.

    Syntax: ``launch|notepad.exe;wait|1.5;shortcut|ctrl+s``. The only delay
    primitive is ``wait`` and its value is capped at ten seconds per step.
    """
    text = str(raw or "").replace("\r", "").replace("\n", ";").strip()
    if not text:
        raise ValueError("Informe as etapas da macro separadas por ponto e vírgula.")
    raw_steps = [part.strip() for part in text.split(";") if part.strip()]
    if not raw_steps:
        raise ValueError("A macro não contém etapas válidas.")
    if len(raw_steps) > max_steps:
        raise ValueError(f"A macro aceita no máximo {max_steps} etapas.")
    parsed: list[tuple[str, str]] = []
    for number, part in enumerate(raw_steps, start=1):
        if "|" not in part:
            raise ValueError(f"Etapa {number}: use ação|argumento, por exemplo wait|1.5.")
        action, argument = part.split("|", 1)
        action = action.strip().lower()
        argument = argument.strip()
        if action == "wait":
            try:
                delay = float(argument)
            except (TypeError, ValueError):
                raise ValueError(f"Etapa {number}: wait exige segundos, de 0 a 10.") from None
            if not 0 <= delay <= 10:
                raise ValueError(f"Etapa {number}: o intervalo wait deve estar entre 0 e 10 segundos.")
            argument = str(delay)
        elif action not in MACRO_SEQUENCE_ACTIONS:
            raise ValueError(f"Etapa {number}: ação não permitida: {action or '(vazia)' }.")
        elif action in {"shortcut", "key_sequence", "text", "launch", "media", "system", "mute_app"} and not argument:
            raise ValueError(f"Etapa {number}: a ação {action} exige um argumento.")
        parsed.append((action, argument))
    return parsed


def execute_system_action(command: str) -> tuple[bool, str]:
    """Execute a small allow-list of useful Windows commands; never eval user text."""
    import platform
    command = str(command or "").strip().lower()
    if command not in SYSTEM_ACTIONS:
        return False, f"Ação do Windows inválida: {command or '(vazia)'}."
    if os.name != "nt":
        return False, "As ações rápidas do Windows só estão disponíveis no Windows."
    keyboard_commands = {"show_desktop", "open_search", "open_clipboard", "open_notifications", "minimize_active", "maximize_active", "snap_left", "snap_right", "restore_active"}
    if command in keyboard_commands and pyautogui is None:
        return False, "Atalhos do Windows indisponíveis: pyautogui não conseguiu inicializar o teclado/mouse."
    try:
        if command == "show_desktop":
            pyautogui.hotkey("win", "d")
        elif command == "explorer":
            subprocess.Popen(["explorer.exe"], close_fds=True)
        elif command == "task_manager":
            subprocess.Popen(["taskmgr.exe"], close_fds=True)
        elif command == "open_settings":
            os.startfile("ms-settings:")
        elif command == "open_sound_settings":
            os.startfile("ms-settings:sound")
        elif command == "open_display_settings":
            os.startfile("ms-settings:display")
        elif command == "open_network_settings":
            os.startfile("ms-settings:network-status")
        elif command == "lock_workstation":
            import ctypes
            if not ctypes.windll.user32.LockWorkStation():
                return False, "O Windows não confirmou o bloqueio da sessão."
        elif command == "volume_up":
            _send_media_key(MEDIA_VKS["Volume +"])
        elif command == "volume_down":
            _send_media_key(MEDIA_VKS["Volume −"])
        elif command == "volume_mute":
            _send_media_key(MEDIA_VKS["Mute do sistema"])
        elif command == "open_search":
            pyautogui.hotkey("win", "s")
        elif command == "open_clipboard":
            pyautogui.hotkey("win", "v")
        elif command == "open_notifications":
            pyautogui.hotkey("win", "n")
        elif command == "minimize_active":
            pyautogui.hotkey("win", "down")
        elif command == "maximize_active":
            pyautogui.hotkey("win", "up")
        elif command == "snap_left":
            pyautogui.hotkey("win", "left")
        elif command == "snap_right":
            pyautogui.hotkey("win", "right")
        elif command == "restore_active":
            pyautogui.hotkey("win", "down")
        labels = {
            "show_desktop": "Área de trabalho exibida", "explorer": "Explorador de Arquivos aberto",
            "task_manager": "Gerenciador de Tarefas aberto", "open_settings": "Configurações do Windows abertas",
            "open_sound_settings": "Configurações de som abertas", "open_display_settings": "Configurações de tela abertas",
            "open_network_settings": "Configurações de rede abertas", "lock_workstation": "Bloqueio de sessão solicitado",
            "volume_up": "Volume do sistema aumentado", "volume_down": "Volume do sistema reduzido",
            "volume_mute": "Mute do sistema alternado", "open_search": "Pesquisa do Windows aberta",
            "open_clipboard": "Histórico da área de transferência aberto", "open_notifications": "Central de notificações aberta",
            "minimize_active": "Minimização solicitada para a janela ativa",
            "maximize_active": "Janela ativa maximizada",
            "snap_left": "Janela ativa encaixada à esquerda",
            "snap_right": "Janela ativa encaixada à direita",
            "restore_active": "Restauração da janela ativa solicitada",
        }
        return True, labels[command]
    except Exception as exc:
        logging.getLogger("smc_mixer_suite").exception("Windows action failed (%s)", command)
        return False, f"Falha na ação do Windows: {exc}"


def _send_media_key(vk: int) -> None:
    import ctypes
    KEYEVENTF_KEYUP = 0x0002
    user32 = ctypes.windll.user32
    user32.keybd_event(vk, 0, 0, 0)
    user32.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)


def _type_text(text: str) -> None:
    """Paste Unicode text and restore the prior clipboard content shortly afterward."""
    if pyautogui is None or pyperclip is None:
        raise RuntimeError("Digitação assistida indisponível: instale/valide pyautogui e pyperclip.")
    try:
        previous = pyperclip.paste()
    except Exception:
        previous = ""
    pyperclip.copy(text)
    pyautogui.hotkey("ctrl", "v")
    def restore() -> None:
        try:
            pyperclip.copy(previous)
        except Exception:
            pass
    threading.Timer(0.8, restore).start()


def execute_action(action: str, argument: str, audio_engine) -> tuple[bool, str]:
    """Execute only the explicitly configured action; launch arguments are user-controlled."""
    action = (action or "").strip().lower()
    argument = (argument or "").strip()
    try:
        if action == "shortcut":
            if pyautogui is None:
                return False, "Atalhos indisponíveis: pyautogui não está inicializado no sistema."
            if not argument:
                return False, "Informe o atalho, por exemplo ctrl+shift+f."
            keys = [part.strip().lower() for part in argument.replace(" ", "").split("+") if part.strip()]
            if not keys:
                return False, "Atalho vazio."
            pyautogui.hotkey(*keys)
            return True, f"Atalho enviado: {argument}"
        if action == "key_sequence":
            if pyautogui is None:
                return False, "Sequência de teclas indisponível: pyautogui não está inicializado no sistema."
            if not argument:
                return False, "Informe uma sequência como ctrl+s, enter, tab."
            steps = [step.strip().lower() for step in argument.split(",") if step.strip()]
            for step in steps:
                keys = [part.strip() for part in step.replace(" ", "").split("+") if part.strip()]
                if "+" in step:
                    pyautogui.hotkey(*keys)
                elif keys:
                    pyautogui.press(keys[0])
            return True, f"Sequência de teclas enviada ({len(steps)} etapas)."
        if action == "text":
            _type_text(argument)
            return True, "Texto enviado."
        if action == "launch":
            if not argument:
                return False, "Informe o caminho de um aplicativo, arquivo ou URL."
            if os.path.exists(argument):
                os.startfile(argument)  # Windows shell association
            else:
                # ShellExecute handles PATH-resolved apps and URLs; use only trusted local mappings.
                os.startfile(argument)
            return True, f"Abrindo: {argument}"
        if action == "media":
            if argument not in MEDIA_VKS:
                return False, "Selecione uma ação de mídia válida."
            _send_media_key(MEDIA_VKS[argument])
            return True, f"Mídia: {argument}"
        if action == "system":
            return execute_system_action(argument)
        if action == "mouse_click":
            if pyautogui is None:
                return False, "Clique do mouse indisponível: pyautogui não está inicializado no sistema."
            parts = [part.strip() for part in argument.split(",")]
            if len(parts) < 2:
                return False, "Informe coordenadas como x,y ou x,y,right/double."
            x, y = int(parts[0]), int(parts[1])
            button = parts[2].lower() if len(parts) > 2 else "left"
            if button not in ("left", "right", "middle", "double"):
                return False, "Botão inválido: use left, right, middle ou double."
            pyautogui.click(x=x, y=y, button="left" if button == "double" else button, clicks=2 if button == "double" else 1)
            return True, f"Clique enviado em ({x}, {y})."
        if action == "mute_master":
            return (audio_engine.toggle_mute("__master__"), "Mute do master alternado.")
        if action == "mute_microphone":
            ok = audio_engine.toggle_microphone_mute()
            return ok, "Mute do microfone alternado." if ok else "Não foi possível alternar o microfone padrão."
        if action == "mute_app":
            if not argument:
                return False, "Informe o executável, por exemplo chrome.exe ou spotify.exe."
            ok = audio_engine.toggle_mute(argument)
            return ok, f"Mute de {argument} alternado." if ok else f"Não achei sessão de áudio ativa para {argument}."
        if action == "none":
            return True, "Nenhuma ação configurada."
        return False, f"Tipo de ação desconhecido: {action}"
    except Exception as exc:
        logging.getLogger("smc_mixer_suite").exception("Action execution failed (type=%s)", action)
        return False, f"Falha ao executar ação ({action}): {exc}"
