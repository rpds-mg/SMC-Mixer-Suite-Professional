"""Background MIDI LED feedback/animation engine for the M-VAVE SMC-Mixer.

The MIDI IDs below follow the public device definition in
`degtev/smc_mixer_control/static/devices/smc_mixer.yaml`. Hardware output is
opt-in because MIDI feedback can depend on controller firmware/mode. Animations
are calculated on a dedicated QThread and MIDI writes never block the Qt UI.
"""
from __future__ import annotations

import math
import threading
import time
from typing import Any

from PyQt6.QtCore import QThread, pyqtSignal

from smc_suite.led_mapping import SMC_MIXER_LED_MAP, LED_MODES
from smc_suite.led_frame import build_led_frame

class LedAnimationEngine(QThread):
    """MIDI output thread with throttled, change-only LED writes and hot-plug retry."""
    status_changed = pyqtSignal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._enabled = False
        self._mode = "equalizer"
        self._speed = 1.0
        self._brightness = 0.8
        self._output_preference = "AUTO"
        self._input_port_name = "AUTO"
        self._levels = [0.0] * 8
        self._knobs = [0.5] * 8
        self._muted = [False] * 8
        self._selected = [False] * 8
        self._record_armed = [False] * 8
        self._transport: dict[str, bool] = {k: False for k in SMC_MIXER_LED_MAP["transport_notes"]}
        self._test_until = 0.0
        self._last_sent: dict[tuple[str, int, int], int] = {}
        self._last_status = ""

    @staticmethod
    def list_output_ports() -> list[str]:
        try:
            import mido
            return list(mido.get_output_names())
        except Exception:
            return []

    def configure(self, *, enabled: bool, mode: str, speed: float, brightness: float,
                  output_port: str = "AUTO", input_port: str = "AUTO") -> None:
        with self._lock:
            self._enabled = bool(enabled)
            self._mode = mode if mode in LED_MODES else "equalizer"
            self._speed = max(0.25, min(4.0, float(speed)))
            self._brightness = max(0.05, min(1.0, float(brightness)))
            self._output_preference = str(output_port or "AUTO")
            self._input_port_name = str(input_port or "AUTO")

    def set_state(self, *, levels: list[float] | None = None, knobs: list[float] | None = None,
                  muted: list[bool] | None = None, selected: list[bool] | None = None,
                  record_armed: list[bool] | None = None, transport: dict[str, bool] | None = None) -> None:
        with self._lock:
            if levels is not None:
                self._levels = [max(0.0, min(1.0, float(v))) for v in (levels[:8] + [0.0] * max(0, 8 - len(levels)))[:8]]
            if knobs is not None:
                self._knobs = [max(0.0, min(1.0, float(v))) for v in (knobs[:8] + [0.5] * max(0, 8 - len(knobs)))[:8]]
            if muted is not None:
                self._muted = [bool(v) for v in (muted[:8] + [False] * max(0, 8 - len(muted)))[:8]]
            if selected is not None:
                self._selected = [bool(v) for v in (selected[:8] + [False] * max(0, 8 - len(selected)))[:8]]
            if record_armed is not None:
                self._record_armed = [bool(v) for v in (record_armed[:8] + [False] * max(0, 8 - len(record_armed)))[:8]]
            if transport is not None:
                self._transport.update({k: bool(v) for k, v in transport.items() if k in self._transport})

    def request_test(self) -> None:
        """Run an explicit sequential sweep of all 32 button LEDs (~4.8 s)."""
        with self._lock:
            self._test_until = time.monotonic() + 4.8

    def stop(self) -> None:
        self._stop.set()
        self.wait(2500)

    def _choose_output(self, names: list[str]) -> str | None:
        with self._lock:
            requested = self._output_preference
            input_name = self._input_port_name
        if not names:
            return None
        if requested != "AUTO":
            return requested if requested in names else None
        if input_name != "AUTO":
            exact = [n for n in names if n.casefold() == input_name.casefold()]
            if exact:
                return exact[0]
        for name in names:
            low = name.casefold()
            if "m-vave" in low or "mvave" in low or "smc-mixer" in low or "smc mixer" in low:
                return name
        return names[0] if len(names) == 1 else None

    def _emit_status(self, message: str) -> None:
        if message != self._last_status:
            self._last_status = message
            self.status_changed.emit(message)

    def _send_cc(self, port: Any, control: int, value: int) -> None:
        import mido
        v = max(0, min(127, int(value)))
        key = ("cc", 0, control)
        if self._last_sent.get(key) == v:
            return
        port.send(mido.Message("control_change", channel=0, control=control, value=v))
        self._last_sent[key] = v

    def _send_note(self, port: Any, note: int, value: int) -> None:
        import mido
        v = max(0, min(127, int(value)))
        key = ("note", 0, note)
        if self._last_sent.get(key) == v:
            return
        # The SMC-Mixer feedback uses Note messages. Send native Note Off on
        # transitions to zero; some firmwares respond more reliably to Note Off
        # than to Note On with velocity zero.
        if v <= 0:
            # Send both common LED-off encodings. CC-mode firmware revisions do
            # not all treat Note Off and Note On/velocity-0 identically.
            port.send(mido.Message("note_off", channel=0, note=note, velocity=0))
            port.send(mido.Message("note_on", channel=0, note=note, velocity=0))
        else:
            port.send(mido.Message("note_on", channel=0, note=note, velocity=v))
        self._last_sent[key] = v

    @staticmethod
    def _clear_output(port: Any, mido_module: Any) -> None:
        """Clear controller LEDs before feedback is disabled or the app exits."""
        for control in SMC_MIXER_LED_MAP["fader_cc"] + SMC_MIXER_LED_MAP["knob_cc"]:
            try:
                port.send(mido_module.Message("control_change", channel=0, control=control, value=0))
            except Exception:
                pass
        notes = []
        for group in ("select_notes", "meter_notes", "mute_notes", "status_notes"):
            notes.extend(SMC_MIXER_LED_MAP[group])
        notes.extend(SMC_MIXER_LED_MAP["transport_notes"].values())
        for note in notes:
            try:
                port.send(mido_module.Message("note_off", channel=0, note=note, velocity=0))
                port.send(mido_module.Message("note_on", channel=0, note=note, velocity=0))
            except Exception:
                pass

    def _frame(self, t: float, snapshot: dict[str, Any]) -> dict[tuple[str, int], int]:
        """Build a full hardware frame; all four physical button LED rows are driven."""
        return build_led_frame(t, snapshot)

    def run(self) -> None:
        try:
            import mido
        except Exception as exc:
            self._emit_status(f"Feedback LED indisponível: biblioteca MIDI não carregou ({exc})")
            return
        output = None
        opened_name = None
        next_scan = 0.0
        last_frame_at = 0.0
        while not self._stop.is_set():
            with self._lock:
                snapshot = {
                    "enabled": self._enabled, "mode": self._mode, "speed": self._speed,
                    "brightness": self._brightness, "output_port": self._output_preference,
                    "input_port": self._input_port_name, "levels": self._levels.copy(),
                    "knobs": self._knobs.copy(), "muted": self._muted.copy(),
                    "selected": self._selected.copy(), "record_armed": self._record_armed.copy(),
                    "transport": dict(self._transport), "test_until": self._test_until,
                }
            now = time.monotonic()
            if not snapshot["enabled"]:
                if output is not None:
                    self._clear_output(output, mido)
                    try: output.close()
                    except Exception: pass
                    output = None; opened_name = None; self._last_sent.clear()
                time.sleep(0.08)
                continue
            if now >= next_scan:
                names = self.list_output_ports()
                chosen = self._choose_output(names)
                if chosen != opened_name:
                    if output is not None:
                        try: output.close()
                        except Exception: pass
                        output = None; opened_name = None; self._last_sent.clear()
                    if chosen:
                        try:
                            output = mido.open_output(chosen)
                            opened_name = chosen
                            self._last_sent.clear()
                            self._emit_status(f"LED MIDI conectado: {chosen}")
                        except Exception as exc:
                            self._emit_status(f"Não foi possível abrir a saída MIDI {chosen}: {exc}")
                elif output is None and chosen is None:
                    if now >= next_scan:
                        self._emit_status("Saída MIDI para LEDs não encontrada; verifique se o SMC-Mixer oferece uma porta de saída.")
                next_scan = now + 2.0
            if output is None:
                time.sleep(0.25)
                continue
            try:
                frame = self._frame(now, snapshot)
                # Cap traffic at ~25 FPS, plus send only values which changed.
                if now - last_frame_at >= 0.04:
                    for (kind, number), value in frame.items():
                        if kind == "cc": self._send_cc(output, number, value)
                        else: self._send_note(output, number, value)
                    last_frame_at = now
            except Exception as exc:
                self._emit_status(f"Falha ao enviar feedback LED; tentando reconectar: {exc}")
                try: output.close()
                except Exception: pass
                output = None; opened_name = None; self._last_sent.clear(); next_scan = 0.0
            time.sleep(0.015)
        if output is not None:
            try:
                self._clear_output(output, mido)
                output.close()
            except Exception:
                pass
        self._emit_status("Feedback LED encerrado")
