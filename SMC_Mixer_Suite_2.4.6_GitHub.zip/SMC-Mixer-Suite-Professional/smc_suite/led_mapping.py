"""M-VAVE SMC-Mixer MIDI feedback map and animation catalogue."""
SMC_MIXER_LED_MAP = {
    "fader_cc": list(range(40, 48)),
    "knob_cc": list(range(30, 38)),
    "status_notes": list(range(0, 8)),  # third physical button row (REC/action row)
    "meter_notes": list(range(8, 16)),  # second physical button row
    "mute_notes": list(range(16, 24)),  # first physical button row (MUTE)
    "select_notes": list(range(24, 32)),  # fourth physical button row (SELECT/status)
    "transport_notes": {"rewind": 91, "next": 92, "pause": 93, "play": 94, "record": 95},
}

LED_MODES = {
    "off": "Desligado / Stealth",
    "static": "Estático / Minimalista",
    "level": "Nível de volume",
    "equalizer": "Equalizer / barras de nível",
    "knight_rider": "Knight Rider",
    "chase": "Chase / perseguição",
    "wave": "Wave / onda",
    "breathe": "Breath / respiração",
    "pulse": "Pulse / pulso",
    "channel_scan": "Varredura por canal",
    "meter_fill": "Meter Fill / barra em 4 níveis",
}
