from __future__ import annotations

import multiprocessing
import os
import sys

from smc_suite import diagnostics, __version__

_LOG = diagnostics.setup_logging()


def _show_startup_error(message: str) -> None:
    """Show a visible error even when Qt fails before its main window opens."""
    try:
        from PyQt6.QtWidgets import QApplication, QMessageBox
        if QApplication.instance() is not None:
            QMessageBox.critical(None, "SMC Mixer Suite — erro ao iniciar", message)
            return
    except Exception:
        pass
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                None, message, "SMC Mixer Suite — erro ao iniciar", 0x10 | 0x1000
            )
            return
        except Exception:
            pass
    print(message, file=sys.stderr)


def main() -> int:
    multiprocessing.freeze_support()
    app = None
    try:
        from PyQt6.QtWidgets import QApplication
        from smc_suite.ui.main_window import MainWindow

        app = QApplication(sys.argv)
        app.setApplicationName("SMC Mixer Suite Professional")
        app.setApplicationDisplayName(f"SMC Mixer Suite Professional {__version__} · Rafael Souza")
        app.setApplicationVersion(__version__)
        app.setOrganizationName("Rafael Souza · SMC Mixer Suite")
        app.setQuitOnLastWindowClosed(False)
        window = MainWindow()
        if "--minimized" in sys.argv:
            window.hide()
        else:
            window.showMaximized()
        _LOG.info("Application started: version=%s", __version__)
        code = app.exec()
        _LOG.info("Application exited with code %s", code)
        return int(code)
    except Exception as exc:
        _LOG.exception("Application startup or main loop failed")
        message = (
            f"A SMC Mixer Suite {__version__} não conseguiu iniciar.\n\n"
            f"Erro: {type(exc).__name__}: {exc}\n\n"
            f"O diagnóstico completo foi gravado em:\n{diagnostics.LOG_FILE}\n\n"
            "Envie as últimas linhas desse arquivo para identificar a causa. "
            "O aviso de DPI do Qt, isoladamente, normalmente não identifica a falha fatal."
        )
        _show_startup_error(message)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
