# Como contribuir

Obrigado pelo interesse na SMC Mixer Suite Professional. O projeto é experimental e foi desenvolvido com auxílio de IA por uma pessoa iniciante em programação. Relatos objetivos são especialmente úteis.

## Como relatar um problema

Inclua:
- Windows e versão do Python;
- conexão MIDI utilizada (USB ou Bluetooth);
- passos numerados para reproduzir o problema;
- comportamento esperado e o que aconteceu;
- mensagem de erro relevante, sem dados pessoais.

Não anexe perfis privados, credenciais, logs completos sem revisá-los ou informações sensíveis.

## Propostas de alteração

Antes de mudanças grandes, abra uma discussão ou issue descrevendo o motivo. Alterações em MIDI, áudio, persistência e inicialização devem vir acompanhadas de testes quando possível. Não marque funcionalidades como validadas em hardware real sem ter realizado esse teste.

## Testes locais

```bat
.venv\Scripts\python.exe -m unittest discover -s tests -v
.venv\Scripts\python.exe verify_syntax.py
```

A aprovação desses testes não substitui a validação no Windows com o M‑VAVE SMC‑Mixer físico.
