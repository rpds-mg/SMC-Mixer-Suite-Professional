import tempfile
import unittest
from pathlib import Path

from smc_suite.eqapo import render_config, write_config


class EqualizerApoConfigTests(unittest.TestCase):
    def test_generates_eight_bands_and_neutral_preamp_at_zero_gain(self):
        text = render_config([0.0] * 8)
        self.assertIn("Preamp: 0.00 dB", text)
        self.assertEqual(sum(line.startswith("Filter ") for line in text.splitlines()), 8)
        self.assertIn("Fc 63 Hz", text)
        self.assertIn("Fc 16000 Hz", text)

    def test_boost_adds_headroom_and_selects_band_seven_frequency(self):
        text = render_config([0, 0, 0, 0, 0, 0, 6, 0], band7_freq=4000)
        self.assertIn("Preamp: -9.00 dB", text)
        self.assertIn("Fc 4000 Hz", text)

    def test_bypass_turns_filters_off_and_removes_generated_preamp(self):
        text = render_config([8.0] * 8, bypass=True)
        self.assertIn("Preamp: 0.00 dB", text)
        self.assertEqual(sum("Filter " in line and ": OFF " in line for line in text.splitlines()), 8)

    def test_three_and_five_band_modes_generate_the_expected_number_of_filters(self):
        three = render_config([1.0, 0.0, -1.0], mode=3)
        five = render_config([1.0, 0.5, 0.0, -0.5, -1.0], mode=5)
        self.assertEqual(sum(line.startswith("Filter ") for line in three.splitlines()), 3)
        self.assertEqual(sum(line.startswith("Filter ") for line in five.splitlines()), 5)
        self.assertIn("Fc 100 Hz", three)
        self.assertIn("Fc 10000 Hz", three)
        self.assertIn("Fc 12000 Hz", five)

    def test_low_and_high_cut_filters_are_added_when_enabled(self):
        text = render_config(
            [0.0] * 8,
            mode=8,
            low_cut_enabled=True,
            low_cut_hz=80,
            high_cut_enabled=True,
            high_cut_hz=12000,
        )
        self.assertIn("Filter 1: ON HP Fc 80 Hz", text)
        self.assertIn("ON LP Fc 12000 Hz", text)
        self.assertEqual(sum(line.startswith("Filter ") for line in text.splitlines()), 10)

    def test_global_bypass_disables_low_and_high_cut_filters(self):
        text = render_config(
            [3.0] * 8,
            bypass=True,
            low_cut_enabled=True,
            low_cut_hz=60,
            high_cut_enabled=True,
            high_cut_hz=15000,
        )
        self.assertIn("Filter 1: OFF HP Fc 60 Hz", text)
        self.assertIn("OFF LP Fc 15000 Hz", text)
        self.assertIn("# Low Cut: desativado", text)
        self.assertIn("# High Cut: desativado", text)

    def test_write_config_creates_file(self):
        with tempfile.TemporaryDirectory() as directory:
            dest = Path(directory) / "eq.txt"
            result = write_config(str(dest), [0.0] * 8)
            self.assertEqual(result, dest)
            self.assertTrue(dest.exists())
            self.assertIn("Filter 8:", dest.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
