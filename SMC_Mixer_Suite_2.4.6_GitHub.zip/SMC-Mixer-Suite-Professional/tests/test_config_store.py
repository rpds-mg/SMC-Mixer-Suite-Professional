import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from smc_suite.config_store import ConfigStore, _normalize_profile, default_profile
from smc_suite.eq_model import DEFAULT_FREQUENCIES


class ConfigStoreProfessionalTests(unittest.TestCase):
    def test_exact_user_eq_preset_snapshot_survives_normalization(self):
        profile = default_profile("Studio")
        profile["eq_user_presets"] = {
            "Custom studio": {
                "gains": [0, 1, 2, 3, 2, 1, 0, -1],
                "mode": 5,
                "eq_fixed_frequencies": False,
                "eq_bypass": True,
                "eq_low_cut_enabled": True,
                "eq_low_cut_hz": 85,
                "eq_high_cut_enabled": True,
                "eq_high_cut_hz": 16000,
                "gains_by_mode": {"3": [1, 2, 3], "5": [4, 3, 2, 1, 0], "8": [0, 1, 2, 3, 4, 3, 2, 1]},
                "frequencies_by_mode": {mode: list(freqs) for mode, freqs in DEFAULT_FREQUENCIES.items()},
                "description": "snapshot test",
            }
        }
        fixed = _normalize_profile(profile, "Studio")
        entry = fixed["eq_user_presets"]["Custom studio"]
        self.assertEqual(entry["mode"], "5")
        self.assertFalse(entry["eq_fixed_frequencies"])
        self.assertTrue(entry["eq_bypass"])
        self.assertTrue(entry["eq_low_cut_enabled"])
        self.assertEqual(entry["eq_low_cut_hz"], 85.0)
        self.assertTrue(entry["eq_high_cut_enabled"])
        self.assertEqual(entry["eq_high_cut_hz"], 16000.0)
        self.assertEqual(entry["gains_by_mode"]["5"], [4.0, 3.0, 2.0, 1.0, 0.0])
        self.assertEqual(entry["frequencies_by_mode"]["8"], DEFAULT_FREQUENCIES["8"])

    def test_ab_slots_are_persisted_and_numeric_values_are_sanitized(self):
        profile = default_profile("A-B")
        profile["eq_ab_slots"] = {
            "A": {
                "mode": 3,
                "gains": [20, -20, 0],
                "gains_by_mode": {"3": [20, -20, 0]},
                "frequencies_by_mode": {"3": [100, 1000, 10000]},
                "eq_fixed_frequencies": False,
                "eq_bypass": False,
                "description": "A",
            },
            "B": None,
        }
        normalized = _normalize_profile(profile, "A-B")
        slot_a = normalized["eq_ab_slots"]["A"]
        self.assertIsNone(normalized["eq_ab_slots"]["B"])
        self.assertEqual(slot_a["mode"], 3)
        self.assertEqual(slot_a["gains_by_mode"]["3"], [12.0, -12.0, 0.0])
        self.assertEqual(len(slot_a["gains_by_mode"]["8"]), 8)

    def test_cutoff_parameters_are_clamped_and_persisted(self):
        profile = default_profile("Cutoffs")
        profile["eq_low_cut_enabled"] = True
        profile["eq_low_cut_hz"] = 999
        profile["eq_high_cut_enabled"] = True
        profile["eq_high_cut_hz"] = 1
        normalized = _normalize_profile(profile, "Cutoffs")
        self.assertTrue(normalized["eq_low_cut_enabled"])
        self.assertEqual(normalized["eq_low_cut_hz"], 200.0)
        self.assertTrue(normalized["eq_high_cut_enabled"])
        self.assertEqual(normalized["eq_high_cut_hz"], 5000.0)

    def test_settings_save_is_atomic_and_keeps_previous_backup(self):
        with tempfile.TemporaryDirectory() as tmp:
            app_dir = Path(tmp) / "settings"
            config_file = app_dir / "settings.json"
            with patch("smc_suite.config_store.APP_DIR", app_dir), patch("smc_suite.config_store.CONFIG_FILE", config_file):
                store = ConfigStore()
                self.assertTrue(store.save())
                store.data["theme"] = "Studio Green"
                self.assertTrue(store.save())
                backup = app_dir / "settings.json.bak"
                self.assertTrue(backup.exists())
                last_good = json.loads(backup.read_text(encoding="utf-8"))
                self.assertNotEqual(last_good["theme"], "Studio Green")
                live = json.loads(config_file.read_text(encoding="utf-8"))
                self.assertEqual(live["theme"], "Studio Green")

    def test_startup_clears_duplicate_midi_routes_and_keeps_backup(self):
        with tempfile.TemporaryDirectory() as tmp:
            app_dir = Path(tmp) / "settings"
            config_file = app_dir / "settings.json"
            app_dir.mkdir(parents=True)
            profile = default_profile("Use Case")
            profile["fader_midi"][0] = "cc:0:21"
            profile["button_actions"]["ch1_select"]["midi"] = "cc:0:21"
            original = {
                "schema_version": 5,
                "active_profile": "Use Case",
                "profiles": {"Use Case": profile},
                "midi_port": "AUTO",
                "theme": "Graphite Cyan",
            }
            config_file.write_text(json.dumps(original), encoding="utf-8")
            with patch("smc_suite.config_store.APP_DIR", app_dir), patch("smc_suite.config_store.CONFIG_FILE", config_file):
                store = ConfigStore()
                repaired = store.data["profiles"]["Use Case"]
                self.assertIsNone(repaired["fader_midi"][0])
                self.assertIsNone(repaired["button_actions"]["ch1_select"]["midi"])
                self.assertEqual(len(store.mapping_repair_warnings), 1)
                self.assertTrue((app_dir / "settings.json.bak").exists())
                backed_up = json.loads((app_dir / "settings.json.bak").read_text(encoding="utf-8"))
                self.assertEqual(backed_up["profiles"]["Use Case"]["fader_midi"][0], "cc:0:21")
                saved = json.loads(config_file.read_text(encoding="utf-8"))
                self.assertIsNone(saved["profiles"]["Use Case"]["fader_midi"][0])

    def test_startup_migration_clears_old_fader_6_and_7_links_only_once(self):
        with tempfile.TemporaryDirectory() as tmp:
            app_dir = Path(tmp) / "settings"
            config_file = app_dir / "settings.json"
            app_dir.mkdir(parents=True)
            profile = default_profile("Use Case")
            profile["fader_midi"][0] = "cc:0:10"
            profile["fader_midi"][5] = "cc:0:45"
            profile["fader_midi"][6] = "cc:0:46"
            profile["fader_midi"][7] = "cc:0:47"
            profile["banks"][0]["fader_targets"][5] = "spotify.exe"
            original = {
                "schema_version": 5,
                "active_profile": "Use Case",
                "profiles": {"Use Case": profile},
                "midi_port": "AUTO",
                "theme": "Graphite Cyan",
            }
            config_file.write_text(json.dumps(original), encoding="utf-8")
            with patch("smc_suite.config_store.APP_DIR", app_dir), patch("smc_suite.config_store.CONFIG_FILE", config_file):
                store = ConfigStore()
                repaired = store.data["profiles"]["Use Case"]
                self.assertEqual(repaired["fader_midi"][0], "cc:0:10")
                self.assertIsNone(repaired["fader_midi"][5])
                self.assertIsNone(repaired["fader_midi"][6])
                self.assertEqual(repaired["fader_midi"][7], "cc:0:47")
                self.assertEqual(repaired["fader_targets"][5], "spotify.exe")
                self.assertTrue(store.data["midi_selector_fader_collision_repair_v244"])
                self.assertTrue(store.mapping_repair_persisted)
                self.assertTrue((app_dir / "settings.json.bak").exists())
                reloaded = ConfigStore()
                self.assertIsNone(reloaded.profile["fader_midi"][5])
                self.assertEqual(reloaded.profile["fader_midi"][7], "cc:0:47")
                self.assertEqual(reloaded.mapping_repair_warnings, [])

    def test_channel_colors_are_normalized_and_persisted_per_bank(self):
        profile = default_profile("Colors")
        profile["banks"][0]["channel_colors"][0] = "#ABCDEF"
        profile["banks"][1]["channel_colors"][1] = "invalid"
        normalized = _normalize_profile(profile, "Colors")
        self.assertEqual(normalized["banks"][0]["channel_colors"][0], "#abcdef")
        self.assertEqual(normalized["banks"][1]["channel_colors"][1], "#39b488")

    def test_root_transport_preference_defaults_to_auto_and_is_persisted(self):
        with tempfile.TemporaryDirectory() as tmp:
            app_dir = Path(tmp) / "settings"
            config_file = app_dir / "settings.json"
            with patch("smc_suite.config_store.APP_DIR", app_dir), patch("smc_suite.config_store.CONFIG_FILE", config_file):
                store = ConfigStore()
                self.assertEqual(store.data["midi_transport"], "auto")
                store.data["midi_transport"] = "bluetooth"
                self.assertTrue(store.save())
                reloaded = ConfigStore()
                self.assertEqual(reloaded.data["midi_transport"], "bluetooth")

    def test_factory_channel_colors_migrate_but_custom_colors_are_preserved(self):
        from smc_suite.hardware import LEGACY_CHANNEL_DEFAULT_COLORS
        profile = default_profile("Color migration")
        profile["banks"][0]["channel_colors"] = list(LEGACY_CHANNEL_DEFAULT_COLORS)
        profile["banks"][0]["channel_colors"][3] = "#123456"
        normalized = _normalize_profile(profile, "Color migration")
        colors = normalized["banks"][0]["channel_colors"]
        self.assertEqual(colors[0], "#39b488")
        self.assertEqual(colors[1], "#39b488")
        self.assertEqual(colors[3], "#123456")

    def test_existing_install_migrates_to_graphite_studio_theme_once(self):
        with tempfile.TemporaryDirectory() as tmp:
            app_dir = Path(tmp) / "settings"
            config_file = app_dir / "settings.json"
            app_dir.mkdir(parents=True)
            profile = default_profile("Existing")
            original = {
                "schema_version": 6,
                "active_profile": "Existing",
                "profiles": {"Existing": profile},
                "midi_port": "AUTO",
                "theme": "Studio Light",
                "custom_accent": "#ff00aa",
            }
            config_file.write_text(json.dumps(original), encoding="utf-8")
            with patch("smc_suite.config_store.APP_DIR", app_dir), patch("smc_suite.config_store.CONFIG_FILE", config_file):
                store = ConfigStore()
                self.assertEqual(store.data["theme"], "Graphite Studio (3.2)")
                self.assertEqual(store.data["custom_accent"], "")
                self.assertTrue(store.data["theme_migration_v32_applied"])
                self.assertTrue(store.save())
                store.data["theme"] = "Ocean Blue"
                self.assertTrue(store.save())
                reloaded = ConfigStore()
                self.assertEqual(reloaded.data["theme"], "Ocean Blue")

    def test_malformed_settings_are_preserved_for_recovery(self):
        with tempfile.TemporaryDirectory() as tmp:
            app_dir = Path(tmp) / "settings"
            app_dir.mkdir()
            config_file = app_dir / "settings.json"
            config_file.write_text("{ not json", encoding="utf-8")
            with patch("smc_suite.config_store.APP_DIR", app_dir), patch("smc_suite.config_store.CONFIG_FILE", config_file):
                store = ConfigStore()
                self.assertEqual(store.data["active_profile"], "Uso Geral")
                recovery_files = list(app_dir.glob("settings.corrupt-*.json"))
                self.assertEqual(len(recovery_files), 1)
                self.assertEqual(recovery_files[0].read_text(encoding="utf-8"), "{ not json")
                self.assertTrue(store.save())
                self.assertEqual(json.loads(config_file.read_text(encoding="utf-8"))["active_profile"], "Uso Geral")
                self.assertFalse((app_dir / "settings.json.bak").exists())

    def test_action_hud_settings_are_defaulted_persisted_and_sanitized(self):
        with tempfile.TemporaryDirectory() as tmp:
            app_dir = Path(tmp) / "settings"
            config_file = app_dir / "settings.json"
            with patch("smc_suite.config_store.APP_DIR", app_dir), patch("smc_suite.config_store.CONFIG_FILE", config_file):
                store = ConfigStore()
                self.assertTrue(store.data["show_action_hud"])
                self.assertEqual(store.data["hud_position"], "bottom_right")
                self.assertTrue(store.save())
                raw = json.loads(config_file.read_text(encoding="utf-8"))
                raw["show_action_hud"] = False
                raw["hud_position"] = "top_left"
                raw["hud_duration_ms"] = 9000
                config_file.write_text(json.dumps(raw), encoding="utf-8")
                reloaded = ConfigStore()
                self.assertFalse(reloaded.data["show_action_hud"])
                self.assertEqual(reloaded.data["hud_position"], "top_left")
                self.assertEqual(reloaded.data["hud_duration_ms"], 5000)


if __name__ == "__main__":
    unittest.main()
