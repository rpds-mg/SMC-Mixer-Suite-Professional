import unittest

from smc_suite.knob_input import (
    absolute_cc_to_gain,
    apply_relative_gain_step,
    apply_relative_step,
    decode_relative_delta,
    infer_knob_mode,
    normalize_knob_mode,
)


class KnobInputTests(unittest.TestCase):
    def test_legacy_mode_migrates_to_auto(self):
        self.assertEqual(normalize_knob_mode("relative"), "auto")

    def test_twos_complement_pair(self):
        self.assertEqual(decode_relative_delta(1, "relative_twos"), 1)
        self.assertEqual(decode_relative_delta(127, "relative_twos"), -1)
        self.assertEqual(decode_relative_delta(64, "relative_twos"), 0)

    def test_centered_pair(self):
        self.assertEqual(decode_relative_delta(63, "relative_centered"), -1)
        self.assertEqual(decode_relative_delta(65, "relative_centered"), 1)
        self.assertEqual(decode_relative_delta(64, "relative_centered"), 0)

    def test_relative_steps_are_bounded(self):
        self.assertEqual(decode_relative_delta(1, "relative_twos", max_steps=4), 1)
        self.assertEqual(decode_relative_delta(10, "relative_twos", max_steps=4), 4)
        self.assertEqual(decode_relative_delta(118, "relative_twos", max_steps=4), -4)

    def test_auto_detection_requires_a_stable_window(self):
        self.assertIsNone(infer_knob_mode([65]))
        self.assertIsNone(infer_knob_mode([127, 127]))
        self.assertEqual(infer_knob_mode([127, 127, 127, 127, 127, 127]), "relative_twos")
        self.assertIsNone(infer_knob_mode([65, 65, 65, 65, 65, 65]))
        self.assertEqual(infer_knob_mode([65, 65, 65, 63, 63, 63]), "relative_centered")
        self.assertIsNone(infer_knob_mode([63, 65, 63, 65, 63, 65]))
        self.assertIsNone(infer_knob_mode([45, 46, 47]))
        self.assertEqual(infer_knob_mode([44, 45, 46, 47, 48, 49]), "absolute")

    def test_ambiguous_midpoint_values_do_not_false_detect_relative(self):
        self.assertIsNone(infer_knob_mode([63, 65, 63, 65, 63, 65]))

    def test_apply_relative_step_clamps_gain(self):
        self.assertEqual(apply_relative_step(11.8, 1, 0.5), 12.0)
        self.assertEqual(apply_relative_step(-11.8, 127, 0.5), -12.0)

    def test_absolute_cc_has_exact_center_and_full_range(self):
        self.assertEqual(absolute_cc_to_gain(0), -12.0)
        self.assertEqual(absolute_cc_to_gain(63), 0.0)
        self.assertEqual(absolute_cc_to_gain(64), 0.0)
        self.assertEqual(absolute_cc_to_gain(127), 12.0)
        self.assertEqual(absolute_cc_to_gain(63, invert=True), 0.0)
        self.assertEqual(absolute_cc_to_gain(64, invert=True), 0.0)

    def test_absolute_cc_adjacent_to_center_moves_smoothly(self):
        self.assertLess(absolute_cc_to_gain(62), 0.0)
        self.assertGreater(absolute_cc_to_gain(65), 0.0)
        self.assertEqual(absolute_cc_to_gain(62), -0.2)
        self.assertEqual(absolute_cc_to_gain(65), 0.2)

    def test_relative_step_snaps_when_crossing_neutral(self):
        self.assertEqual(apply_relative_gain_step(-0.1, 1, 0.5), 0.0)
        self.assertEqual(apply_relative_gain_step(0.1, -1, 0.5), 0.0)
        self.assertEqual(apply_relative_gain_step(0.0, 1, 0.5), 0.5)
        self.assertEqual(apply_relative_gain_step(0.0, -1, 0.5), -0.5)


if __name__ == "__main__":
    unittest.main()
