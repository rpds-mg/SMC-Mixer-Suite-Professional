import unittest
from types import SimpleNamespace
from unittest.mock import patch
import sys

from smc_suite.audio_engine import AudioEngine


class BrightnessTargetTests(unittest.TestCase):
    def test_brightness_target_identification_and_index(self):
        self.assertTrue(AudioEngine.is_brightness_target("__brightness__:0"))
        self.assertTrue(AudioEngine.is_brightness_target("__brightness__:2"))
        self.assertFalse(AudioEngine.is_brightness_target("spotify.exe"))
        self.assertEqual(AudioEngine.brightness_display_index("__brightness__:2"), 2)
        self.assertEqual(AudioEngine.brightness_display_index("__brightness__:bad"), 0)

    def test_brightness_values_are_clamped(self):
        self.assertEqual(AudioEngine._coerce_brightness_result([41]), 41)
        self.assertEqual(AudioEngine._coerce_brightness_result(123), 100)
        self.assertEqual(AudioEngine._coerce_brightness_result(-5), 0)
        self.assertIsNone(AudioEngine._coerce_brightness_result("n/a"))

    def test_brightness_writes_are_routed_without_pycaw(self):
        calls = []
        fake = SimpleNamespace(set_brightness=lambda value, display, no_return: calls.append((value, display)) or True)
        engine = AudioEngine()
        with patch.dict(sys.modules, {"screen_brightness_control": fake}):
            result = engine.set_volumes({"__brightness__:1": 0.43})
        self.assertTrue(result["__brightness__:1"])
        self.assertEqual(calls, [(43, 1)])


if __name__ == "__main__":
    unittest.main()
