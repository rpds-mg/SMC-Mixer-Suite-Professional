import tempfile
import unittest
from pathlib import Path

from smc_suite.eqapo_setup import ensure_include_text, include_exists, configure_include_file


class EqualizerApoSetupTests(unittest.TestCase):
    def test_include_is_added_once(self):
        with tempfile.TemporaryDirectory() as directory:
            filters = Path(directory) / "filters.txt"
            original = "Device: Default\nPreamp: 0 dB\n"
            updated, changed = ensure_include_text(original, filters)
            self.assertTrue(changed)
            self.assertIn('Include: "', updated)
            self.assertTrue(include_exists(updated, filters))
            again, changed_again = ensure_include_text(updated, filters)
            self.assertFalse(changed_again)
            self.assertEqual(again, updated)

    def test_replaces_obsolete_external_include_with_local_filter_include(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            old_filter = root / "user_profile" / "filters.txt"
            new_filter = root / "apo_config" / "SMC_Mixer_Suite_filters.txt"
            original = f"Preamp: 0 dB\nInclude: \"{old_filter}\"\n"
            updated, changed = ensure_include_text(original, new_filter, remove_paths=[old_filter])
            self.assertTrue(changed)
            self.assertFalse(include_exists(updated, old_filter))
            self.assertTrue(include_exists(updated, new_filter))
            again, changed_again = ensure_include_text(updated, new_filter, remove_paths=[old_filter])
            self.assertFalse(changed_again)
            self.assertEqual(again, updated)

    def test_configure_file_creates_backup_and_is_idempotent(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = root / "config.txt"
            filters = root / "equalizerapo_filters.txt"
            config.write_text("Preamp: 0 dB\n", encoding="utf-8")
            filters.write_text("Filter 1: ON PK Fc 1000 Hz Gain +2 dB Q 0.707\n", encoding="utf-8")
            backup = configure_include_file(config, filters)
            self.assertIsNotNone(backup)
            self.assertTrue(backup.exists())
            text = config.read_text(encoding="utf-8")
            self.assertTrue(include_exists(text, filters, config.parent))
            self.assertIsNone(configure_include_file(config, filters))

    def test_include_is_relative_and_precedes_device_scope(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = root / "config.txt"
            filters = root / "SMC_Mixer_Suite_filters.txt"
            config.write_text("# Existing configuration\nDevice: Some other output\nPreamp: 0 dB\n", encoding="utf-8")
            filters.write_text("Preamp: -7 dB\nFilter 1: ON PK Fc 1000 Hz Gain +4 dB Q 0.707\n", encoding="utf-8")
            configure_include_file(config, filters)
            updated = config.read_text(encoding="utf-8")
            self.assertLess(updated.index("Include: SMC_Mixer_Suite_filters.txt"), updated.index("Device: Some other output"))
            self.assertTrue(include_exists(updated, filters, config.parent))
            # Re-link should be idempotent and not duplicate the include/comment.
            backup = configure_include_file(config, filters)
            self.assertIsNone(backup)
            self.assertEqual(updated, config.read_text(encoding="utf-8"))

    def test_missing_filters_is_a_clear_error(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = root / "config.txt"
            config.write_text("Preamp: 0 dB\n", encoding="utf-8")
            with self.assertRaises(FileNotFoundError):
                configure_include_file(config, root / "missing.txt")


if __name__ == "__main__":
    unittest.main()
