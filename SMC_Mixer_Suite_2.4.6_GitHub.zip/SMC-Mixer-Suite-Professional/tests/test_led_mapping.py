import unittest
from smc_suite.led_mapping import SMC_MIXER_LED_MAP, LED_MODES


class LedMapTests(unittest.TestCase):
    def test_feedback_mappings_have_eight_faders_and_knobs(self):
        self.assertEqual(SMC_MIXER_LED_MAP["fader_cc"], list(range(40, 48)))
        self.assertEqual(SMC_MIXER_LED_MAP["knob_cc"], list(range(30, 38)))

    def test_physical_button_rows_match_reference_layout(self):
        self.assertEqual(SMC_MIXER_LED_MAP["mute_notes"], list(range(16, 24)))
        self.assertEqual(SMC_MIXER_LED_MAP["meter_notes"], list(range(8, 16)))
        self.assertEqual(SMC_MIXER_LED_MAP["status_notes"], list(range(0, 8)))
        self.assertEqual(SMC_MIXER_LED_MAP["select_notes"], list(range(24, 32)))

    def test_button_led_rows_do_not_overlap(self):
        rows = [SMC_MIXER_LED_MAP[key] for key in ("select_notes", "meter_notes", "mute_notes", "status_notes")]
        flattened = [note for row in rows for note in row]
        self.assertEqual(len(flattened), 32)
        self.assertEqual(len(set(flattened)), 32)

    def test_eleven_animation_modes_are_available(self):
        self.assertEqual(len(LED_MODES), 11)
        self.assertIn("off", LED_MODES)
        self.assertIn("equalizer", LED_MODES)


if __name__ == "__main__":
    unittest.main()
