import unittest

from smc_suite.themes import DEFAULT_THEME, THEMES, build_stylesheet, resolve_palette


class ThemeTests(unittest.TestCase):
    def test_all_professional_themes_have_required_colors(self):
        required = {"window", "panel", "card", "border", "accent", "accent_dark", "text", "muted"}
        self.assertIn(DEFAULT_THEME, THEMES)
        for theme_name, palette in THEMES.items():
            self.assertTrue(required.issubset(palette), theme_name)
            for color in (palette["window"], palette["accent"], palette["text"]):
                self.assertRegex(color, r"^#[0-9a-fA-F]{6}$")

    def test_graphite_studio_32_palette_matches_requested_reference(self):
        self.assertEqual(DEFAULT_THEME, "Graphite Studio (3.2)")
        palette = resolve_palette(DEFAULT_THEME)
        self.assertEqual(palette["window"], "#181a1d")
        self.assertEqual(palette["panel"], "#22272b")
        self.assertEqual(palette["accent"], "#39b488")
        self.assertEqual(palette["accent_dark"], "#176f53")
        self.assertEqual(palette["text"], "#e9ecef")

    def test_light_and_extra_themes_are_available(self):
        for name in ("Studio Light", "Nord Frost", "Ocean Blue", "Monochrome"):
            self.assertIn(name, THEMES)
            palette = resolve_palette(name)
            self.assertIn(palette["window"], build_stylesheet("QWidget { background:#171a20; }", palette))
        self.assertEqual(resolve_palette("Studio Light").get("mode"), "light")

    def test_custom_accent_overrides_only_the_accent(self):
        base = resolve_palette("Studio Green")
        custom = resolve_palette("Studio Green", "#aa33cc")
        self.assertEqual(custom["accent"], "#aa33cc")
        self.assertEqual(custom["window"], base["window"])

    def test_stylesheet_applies_palette_and_compact_spacing(self):
        stylesheet = "QWidget { background:#171a20; } QTab { padding:7px 11px; }"
        palette = resolve_palette("Amber Studio")
        rendered = build_stylesheet(stylesheet, palette, compact=True)
        self.assertIn(palette["window"], rendered)
        self.assertIn("padding:5px 8px", rendered)


if __name__ == "__main__":
    unittest.main()
