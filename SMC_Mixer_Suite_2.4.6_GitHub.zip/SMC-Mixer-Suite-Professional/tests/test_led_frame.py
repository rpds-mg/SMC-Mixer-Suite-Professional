import unittest

from smc_suite.led_frame import LED_TEST_DURATION, LED_TEST_STEP_SECONDS, ROW_KEYS, build_led_frame
from smc_suite.led_mapping import SMC_MIXER_LED_MAP


class LedFrameTests(unittest.TestCase):
    def test_every_frame_contains_all_32_button_leds(self):
        frame = build_led_frame(1.0, {"mode": "wave", "levels": [0.5] * 8, "brightness": 1.0})
        note_ids = {number for (kind, number) in frame if kind == "note" and 0 <= number <= 31}
        self.assertEqual(note_ids, set(range(32)))

    def test_wave_activates_all_four_rows(self):
        frame = build_led_frame(0.83, {"mode": "wave", "levels": [0.5] * 8, "brightness": 1.0, "speed": 1.0})
        row_note_groups = [SMC_MIXER_LED_MAP[key] for key in ROW_KEYS]
        self.assertTrue(all(any(frame[("note", note)] > 0 for note in row) for row in row_note_groups))

    def test_equalizer_mode_activates_all_rows_at_low_volume(self):
        frame = build_led_frame(0.83, {"mode": "equalizer", "levels": [0.08] * 8, "brightness": 1.0})
        row_note_groups = [SMC_MIXER_LED_MAP[key] for key in ROW_KEYS]
        self.assertTrue(all(any(frame[("note", note)] > 0 for note in row) for row in row_note_groups))

    def test_test_sequence_visits_all_32_leds_at_full_velocity(self):
        # Simulated monotonic clock: request_test stores a deadline 4.8 seconds ahead.
        deadline = 100.0
        lit_notes = set()
        for index in range(32):
            t = deadline - LED_TEST_DURATION + (index + 0.5) * LED_TEST_STEP_SECONDS
            frame = build_led_frame(t, {"mode": "static", "test_until": deadline, "brightness": 0.2})
            on = [number for (kind, number), value in frame.items() if kind == "note" and 0 <= number <= 31 and value > 0]
            self.assertEqual(len(on), 1)
            self.assertEqual(frame[("note", on[0])], 127)
            lit_notes.update(on)
        self.assertEqual(lit_notes, set(range(32)))

    def test_stealth_clears_all_led_rows(self):
        frame = build_led_frame(1.0, {"mode": "off", "levels": [1.0] * 8, "muted": [True] * 8})
        self.assertTrue(all(frame[("note", i)] == 0 for i in range(32)))


if __name__ == "__main__":
    unittest.main()
