import unittest

from smc_suite.eq_model import (
    DEFAULT_FREQUENCIES, FACTORY_PRESETS, clamp_gain,
    interpolate_curve, preset_gains_for_frequencies, sanitize_frequencies,
)


class EqualizerModelTests(unittest.TestCase):
    def test_band_modes_have_expected_complexity_and_frequencies(self):
        self.assertEqual(DEFAULT_FREQUENCIES["3"], [100.0, 1000.0, 10000.0])
        self.assertEqual(DEFAULT_FREQUENCIES["5"], [60.0, 250.0, 1000.0, 4000.0, 12000.0])
        self.assertEqual(len(DEFAULT_FREQUENCIES["8"]), 8)

    def test_ten_factory_presets_exist(self):
        self.assertEqual(len(FACTORY_PRESETS), 10)
        self.assertTrue(all(len(values) == 8 for values in FACTORY_PRESETS.values()))

    def test_flat_preset_stays_flat_for_all_modes(self):
        for mode, frequencies in DEFAULT_FREQUENCIES.items():
            self.assertEqual(preset_gains_for_frequencies(FACTORY_PRESETS["Flat / Neutro"], frequencies), [0.0] * len(frequencies))

    def test_custom_frequencies_are_repaired_to_increasing_unique_centers(self):
        values = sanitize_frequencies([1000, 500, 500, 30000, 10], "5")
        self.assertEqual(len(values), 5)
        self.assertTrue(all(20 <= value <= 20000 for value in values))
        self.assertTrue(all(a < b for a, b in zip(values, values[1:])))

    def test_interpolation_uses_log_frequency_and_clamps_gain(self):
        result = interpolate_curve([100, 1000], [-20, 20], [100, 1000])
        self.assertEqual(result, [-12.0, 12.0])
        self.assertEqual(clamp_gain(12.4), 12.0)
        self.assertEqual(clamp_gain(-12.4), -12.0)


if __name__ == "__main__":
    unittest.main()
