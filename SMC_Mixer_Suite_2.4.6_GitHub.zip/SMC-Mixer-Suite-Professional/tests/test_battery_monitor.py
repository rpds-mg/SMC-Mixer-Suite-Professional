import unittest

from smc_suite.battery_monitor import _charging_from_power_state


class BatteryMonitorTests(unittest.TestCase):
    def test_decodes_charging_state(self):
        self.assertIs(_charging_from_power_state(bytes([0b00110000])), True)

    def test_decodes_not_charging_state(self):
        self.assertIs(_charging_from_power_state(bytes([0b00100000])), False)

    def test_missing_or_unknown_state_is_not_invented(self):
        self.assertIsNone(_charging_from_power_state(b""))
        self.assertIsNone(_charging_from_power_state(bytes([0b00010000])))


if __name__ == "__main__":
    unittest.main()
