import unittest

from smc_suite.button_input import MidiButtonPressGate


class MidiButtonPressGateTests(unittest.TestCase):
    def test_first_positive_cc_triggers(self):
        gate = MidiButtonPressGate()
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 127, 0, now=1.0))

    def test_fixed_cc_press_is_accepted_after_short_human_tap_interval(self):
        gate = MidiButtonPressGate()
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 127, 0, now=2.0))
        self.assertFalse(gate.should_activate("cc:0:16", "cc", 127, 127, now=2.04))
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 127, 127, now=2.12))

    def test_reset_all_forgets_previous_connection_debounce(self):
        gate = MidiButtonPressGate()
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 127, 0, now=2.0))
        gate.reset_all()
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 127, 127, now=2.01))

    def test_zero_release_does_not_trigger(self):
        gate = MidiButtonPressGate()
        self.assertFalse(gate.should_activate("cc:0:16", "cc", 0, 127, now=1.0))

    def test_same_value_cc_is_accepted_as_next_tap_after_repeat_window(self):
        gate = MidiButtonPressGate()
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 127, 0, now=1.0))
        self.assertFalse(gate.should_activate("cc:0:16", "cc", 127, 127, now=1.1))
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 127, 127, now=1.19))

    def test_alternating_nonzero_cc_values_trigger(self):
        gate = MidiButtonPressGate()
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 127, 0, now=1.0))
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 1, 127, now=1.1))

    def test_analog_keys_never_trigger_as_buttons(self):
        gate = MidiButtonPressGate()
        self.assertFalse(gate.should_activate("cc:0:1", "cc", 127, 0, {"cc:0:1"}, now=1.0))

    def test_note_on_triggers_and_switch_bounce_is_debounced(self):
        gate = MidiButtonPressGate()
        self.assertTrue(gate.should_activate("note_on:0:16", "note_on", 100, 0, now=1.0))
        self.assertFalse(gate.should_activate("note_on:0:16", "note_on", 100, 0, now=1.02))
        self.assertTrue(gate.should_activate("note_on:0:16", "note_on", 100, 0, now=1.1))

    def test_learn_press_is_consumed_then_next_press_works(self):
        gate = MidiButtonPressGate()
        gate.mark_consumed("cc:0:16", now=1.0)
        # The app resets its remembered value to neutral after MIDI Learn.
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 127, 0, now=1.1))

    def test_fast_duplicate_transition_is_suppressed(self):
        gate = MidiButtonPressGate()
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 127, 0, now=1.0))
        self.assertFalse(gate.should_activate("cc:0:16", "cc", 1, 127, now=1.03))


    def test_cc_toggle_mode_activates_on_alternating_zero_and_positive_click_events(self):
        gate = MidiButtonPressGate()
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 127, 0, now=1.0, trigger_mode="cc_single_toggle"))
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 0, 127, now=1.12, trigger_mode="cc_single_toggle"))
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 127, 0, now=1.24, trigger_mode="cc_single_toggle"))

    def test_cc_toggle_mode_debounces_duplicate_packets(self):
        gate = MidiButtonPressGate()
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 127, 0, now=1.0, trigger_mode="cc_single_toggle"))
        self.assertFalse(gate.should_activate("cc:0:16", "cc", 127, 127, now=1.03, trigger_mode="cc_single_toggle"))

    def test_cc_push_mode_ignores_release_zero(self):
        gate = MidiButtonPressGate()
        self.assertTrue(gate.should_activate("cc:0:16", "cc", 127, 0, now=1.0, trigger_mode="cc_push"))
        self.assertFalse(gate.should_activate("cc:0:16", "cc", 0, 127, now=1.12, trigger_mode="cc_push"))

    def test_note_mode_ignores_cc_and_accepts_note_on(self):
        gate = MidiButtonPressGate()
        self.assertFalse(gate.should_activate("cc:0:16", "cc", 127, 0, now=1.0, trigger_mode="note"))
        self.assertTrue(gate.should_activate("note:0:16", "note_on", 100, 0, now=1.0, trigger_mode="note"))


if __name__ == "__main__":
    unittest.main()
