import unittest

from smc_suite.analog_learn import AnalogLearnSampler, AnalogCCMotionGuard


class AnalogLearnSamplerTests(unittest.TestCase):
    def test_single_button_press_release_is_not_accepted_as_fader(self):
        sampler = AnalogLearnSampler()
        self.assertFalse(sampler.feed("fader", "cc:0:21", 127, now=1.00)[0])
        self.assertFalse(sampler.feed("fader", "cc:0:21", 0, now=1.08)[0])

    def test_fader_requires_continuous_values_not_just_button_edges(self):
        sampler = AnalogLearnSampler()
        values = [20, 35, 51, 68]
        results = [sampler.feed("fader", "cc:0:21", value, now=1.0 + i * .03)[0] for i, value in enumerate(values)]
        self.assertTrue(results[-1])
        self.assertFalse(any(results[:-1]))

    def test_knob_requires_multiple_samples_and_both_value_directions(self):
        sampler = AnalogLearnSampler()
        values = [0, 0, 127, 127]
        results = [sampler.feed("knob", "cc:0:8", value, now=1.0 + i * .04)[0] for i, value in enumerate(values)]
        self.assertFalse(any(results))  # edge-only button-like pattern is rejected
        sampler.reset()
        values = [1, 1, 127, 1, 127]
        results = [sampler.feed("knob", "cc:0:8", value, now=2.0 + i * .04)[0] for i, value in enumerate(values)]
        self.assertTrue(results[-1])

    def test_new_cc_candidate_replaces_previous_candidate(self):
        sampler = AnalogLearnSampler()
        sampler.feed("fader", "cc:0:20", 30, now=1.0)
        accepted, count, _ = sampler.feed("fader", "cc:0:21", 35, now=1.05)
        self.assertFalse(accepted)
        self.assertEqual(count, 1)
        self.assertEqual(sampler.candidate_key, "cc:0:21")

    def test_fader_guard_rejects_isolated_button_edge(self):
        guard = AnalogCCMotionGuard()
        guard.record("cc:0:21", 60, now=1.0)
        guard.record("cc:0:21", 127, now=1.04)
        self.assertFalse(guard.allow_fader_value("cc:0:21", 127, now=1.04))
        guard.record("cc:0:21", 0, now=1.08)
        self.assertFalse(guard.allow_fader_value("cc:0:21", 0, now=1.08))

    def test_fader_guard_accepts_endpoint_after_continuous_motion(self):
        guard = AnalogCCMotionGuard()
        values = [48, 67, 88, 104, 118, 127]
        for i, value in enumerate(values):
            guard.record("cc:0:21", value, now=2.0 + i * .04)
        self.assertTrue(guard.allow_fader_value("cc:0:21", 127, now=2.2))



if __name__ == "__main__":
    unittest.main()
