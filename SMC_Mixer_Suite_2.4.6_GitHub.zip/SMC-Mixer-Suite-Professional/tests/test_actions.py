import unittest

from smc_suite.actions import parse_macro_sequence, execute_system_action, execute_action


class MacroSequenceParserTests(unittest.TestCase):
    def test_parses_launch_wait_shortcut_sequence(self):
        self.assertEqual(
            parse_macro_sequence("launch|notepad.exe;wait|1.5;shortcut|ctrl+s"),
            [("launch", "notepad.exe"), ("wait", "1.5"), ("shortcut", "ctrl+s")],
        )

    def test_accepts_newlines_as_separators(self):
        self.assertEqual(parse_macro_sequence("wait|0.2\nmedia|Play / Pause"), [("wait", "0.2"), ("media", "Play / Pause")])

    def test_rejects_arbitrary_actions(self):
        with self.assertRaises(ValueError):
            parse_macro_sequence("python|print(1)")

    def test_rejects_wait_outside_bounds(self):
        with self.assertRaises(ValueError):
            parse_macro_sequence("wait|11")

    def test_rejects_too_many_steps(self):
        with self.assertRaises(ValueError):
            parse_macro_sequence(";".join(["wait|0"] * 21))

    def test_invalid_windows_action_is_rejected_without_execution(self):
        ok, message = execute_system_action("format_disk")
        self.assertFalse(ok)
        self.assertIn("inválida", message)



class RemovedObsActionTests(unittest.TestCase):
    def test_obs_action_is_not_available_in_this_build(self):
        ok, message = execute_action("obs", "toggle_recording", None)
        self.assertFalse(ok)
        self.assertIn("desconhecido", message)

    def test_obs_is_not_allowed_in_macro_sequences(self):
        with self.assertRaises(ValueError):
            parse_macro_sequence("obs|toggle_recording")


if __name__ == "__main__":
    unittest.main()
