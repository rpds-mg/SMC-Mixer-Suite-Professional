import unittest
from pathlib import Path


class WindowsInstallerTests(unittest.TestCase):
    def test_setup_supports_python_311_and_does_not_require_only_launcher_312(self):
        script = (Path(__file__).resolve().parents[1] / "setup_windows.bat").read_text(encoding="utf-8")
        self.assertIn("py -3.11 --version", script)
        self.assertIn("py -3.12 --version", script)
        self.assertIn("python -c", script)
        self.assertIn("Python 3.11.9 x64", script)

    def test_setup_uses_venv_interpreter_for_packages(self):
        script = (Path(__file__).resolve().parents[1] / "setup_windows.bat").read_text(encoding="utf-8")
        self.assertIn("-m pip install -r requirements.txt", script)


if __name__ == "__main__":
    unittest.main()
