import ast
import unittest
from pathlib import Path


class UiCallbackRegressionTests(unittest.TestCase):
    def test_diagnose_equalizer_apo_callback_is_implemented(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        tree = ast.parse(source_path.read_text(encoding="utf-8"))
        main_window = next(
            node for node in tree.body
            if isinstance(node, ast.ClassDef) and node.name == "MainWindow"
        )
        method_names = {node.name for node in main_window.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
        self.assertIn("_diagnose_equalizer_apo", method_names)


    def test_equalizer_bands_use_round_rotary_knobs(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        self.assertIn("knob = RotaryKnob(-120, 120", source)
        self.assertIn("knob.doubleClicked.connect(lambda n=index: self._reset_eq_band(n))", source)
        self.assertNotIn("slider = FlatResetSlider(", source)
        self.assertNotIn("eq_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)", source)
        self.assertNotIn("self.eq_bands_widget.setMinimumWidth(max(520, count * 128", source)

    def test_volume_faders_remain_vertical_and_expand_in_height(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "hardware_widgets.py"
        source = source_path.read_text(encoding="utf-8")
        self.assertIn("self.fader = QSlider(Qt.Orientation.Vertical)", source)
        self.assertIn("self.fader.setMinimumHeight(160)", source)
        self.assertIn("self.fader.setFixedWidth(32)", source)

    def test_all_direct_main_window_connect_callbacks_are_implemented(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        tree = ast.parse(source_path.read_text(encoding="utf-8"))
        main_window = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "MainWindow")
        methods = {node.name for node in main_window.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
        missing = set()
        for node in ast.walk(main_window):
            if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute) or node.func.attr != "connect":
                continue
            for arg in node.args:
                if isinstance(arg, ast.Attribute) and isinstance(arg.value, ast.Name) and arg.value.id == "self" and arg.attr not in methods:
                    missing.add(arg.attr)
        self.assertEqual(missing, set(), f"Callbacks conectados mas não implementados: {sorted(missing)}")

    def test_microphone_write_callbacks_are_implemented_and_connected(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        for name in ("_dispatch_microphone_write", "_on_microphone_panel_volume_changed", "_on_microphone_write_finished"):
            self.assertIn(f"def {name}(", source)
        self.assertIn("self._microphone_write_timer.timeout.connect(self._dispatch_microphone_write)", source)
        self.assertIn("worker.signals.finished.connect(self._on_microphone_write_finished)", source)

    def test_callback_wiring_does_not_reference_missing_diagnostic_method(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        tree = ast.parse(source_path.read_text(encoding="utf-8"))
        main_window = next(
            node for node in tree.body
            if isinstance(node, ast.ClassDef) and node.name == "MainWindow"
        )
        method_names = {node.name for node in main_window.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
        references = [
            node.attr for node in ast.walk(main_window)
            if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name)
            and node.value.id == "self" and node.attr == "_diagnose_equalizer_apo"
        ]
        self.assertTrue(references, "Esperava referência ao callback na interface")
        self.assertTrue(all(name in method_names for name in references))


    def test_eq_band_uses_fit_to_width_cards_without_horizontal_scrollbar(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        self.assertIn('page_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)', source)
        self.assertIn('self.eq_bands_widget.setMinimumWidth(0)', source)
        self.assertIn('self.eq_bands_layout.addWidget(card, row, column)', source)
        self.assertIn('choose_eq_grid_columns(width, count, min_card_width=104, spacing=5)', source)
        self.assertIn('QTimer.singleShot(0, self._fit_eq_knobs_to_cards)', source)

    def test_tab_pane_no_longer_overlaps_tab_text(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        self.assertIn('border-top:1px solid #303844; border-bottom-left-radius:9px; border-bottom-right-radius:9px; top:-1px;', source)
        self.assertIn('border-bottom:1px solid #1a1e25; margin-bottom:-1px;', source)

    def test_equalizer_page_has_no_slider_widgets_and_uses_named_rotary_knobs(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        start = source.index("    def _build_eq_tab(self) -> QWidget:")
        end = source.index("    def _build_led_tab(self) -> QWidget:", start)
        eq_tab = source[start:end]
        self.assertNotIn("QSlider(", eq_tab)
        self.assertIn('knob = RotaryKnob(-120, 120', source)
        self.assertIn('knob.setObjectName("eqGainKnob")', source)
        self.assertIn('page_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)', eq_tab)

    def test_top_tab_bar_has_no_shared_baseline_and_does_not_elide_labels(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        self.assertIn('self.tabs.tabBar().setElideMode(Qt.TextElideMode.ElideNone)', source)
        self.assertIn('QTabBar { qproperty-drawBase:false; border:0px; background:transparent; }', source)
        self.assertIn('border-top:2px solid #48a9f8; border-bottom:1px solid #1a1e25; margin-bottom:-1px;', source)
        self.assertIn('self.tabs.setUsesScrollButtons(False)', source)
        self.assertIn('self.tabs.tabBar().setElideMode(Qt.TextElideMode.ElideNone)', source)

    def test_resize_reflow_is_debounced_instead_of_queued_for_every_event(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        self.assertIn('self._responsive_layout_timer.setSingleShot(True)', source)
        self.assertIn('self._responsive_layout_timer.setInterval(45)', source)
        resize_start = source.index('    def resizeEvent(self, event) -> None:')
        resize_end = source.index('    def _apply_responsive_layout(self)', resize_start)
        resize_body = source[resize_start:resize_end]
        self.assertIn('timer.start()', resize_body)
        self.assertNotIn('QTimer.singleShot(0, self._apply_responsive_layout)', resize_body)

    def test_long_pages_hide_horizontal_scroll_and_allow_vertical_when_needed(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        start = source.index('    def _build_windows_tab(self) -> QWidget:')
        end = source.index('    def _build_settings_tab(self) -> QWidget:', start)
        body = source[start:end]
        self.assertIn('setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)', body)
        self.assertIn('setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)', body)
        self.assertNotIn('def _build_obs_tab', source)

    def test_version_identity_is_consistent(self):
        root = Path(__file__).resolve().parents[1]
        version = (root / 'smc_suite' / '__init__.py').read_text(encoding='utf-8')
        build_script = (root / 'build_windows.bat').read_text(encoding='utf-8')
        run_script = (root / 'run_windows.bat').read_text(encoding='utf-8')
        readme = (root / 'README.md').read_text(encoding='utf-8')
        self.assertIn('__version__ = "2.4.6"', version)
        self.assertIn('SMC_Mixer_Suite_Professional_2_4_6.exe', build_script)
        self.assertIn('2.4.6', run_script)
        self.assertIn('Rafael Souza', readme)


    def test_quick_button_mapper_is_the_primary_workflow(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        start = source.index("    def _build_buttons_tab(self) -> QWidget:")
        end = source.index("    def _build_eq_tab(self) -> QWidget:", start)
        body = source[start:end]
        self.assertIn("Assistente rápido · 3 passos", body)
        self.assertIn("Salvar e associar botão físico", body)
        self.assertIn("Testar ação", body)
        self.assertIn("insertSeparator", body)
        self.assertIn("_button_choice_label", source)
        self.assertIn("Mostrar tabela avançada (opcional)", body)
        self.assertIn("self.button_advanced_panel.setVisible(False)", body)

    def test_midi_learn_navigates_to_buttons_page_not_windows_tab(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        self.assertIn("def _navigate_to_buttons_tab(self)", source)
        self.assertIn("index = tabs.indexOf(page)", source)
        self.assertIn("self._navigate_to_buttons_tab()", source)
        self.assertNotIn("self.tabs.setCurrentIndex(1)", source)

    def test_quick_mapping_uses_human_readable_targets_and_groups(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        start = source.index("    def _button_choice_label(self, spec) -> str:")
        end = source.index("    def _refresh_button_target_combos(self)", start)
        body = source[start:end]
        self.assertIn("Human-readable button names; never expose internal control IDs.", body)
        self.assertIn("Canal {spec.channel + 1} ({channel_name})", body)
        self.assertIn("combo.insertSeparator(combo.count())", body)
        self.assertNotIn("spec.control_id})", body)

    def test_windows_tab_has_a_direct_route_to_simple_button_mapping(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        start = source.index("    def _build_windows_tab(self) -> QWidget:")
        end = source.index("    def _build_settings_tab(self) -> QWidget:", start)
        body = source[start:end]
        self.assertIn("BOTÕES FÍSICOS DO M-VAVE", body)
        self.assertIn("Configurar este botão…", body)
        self.assertIn("não fazem o mapeamento físico", body)
        self.assertIn("AÇÕES DIRETAS DO WINDOWS · CLIQUE PARA EXECUTAR", body)
        self.assertIn("Macros avançadas (opcional)", body)

    def test_button_learn_rejects_midi_keys_already_owned_by_analog_controls(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        start = source.index("    def _on_midi_message(self, msg_type: str, channel: int, number: int, value: int) -> None:")
        end = source.index("    def _control_display_name(self, control_id: str) -> str:", start)
        body = source[start:end]
        self.assertIn("analog_route_owners(self.profile, key)", body)
        self.assertIn("mude esse botão físico de CC para Note", body)
        self.assertIn("mapped_button_rows = []", body)
        guard_pos = body.index("analog_owners = analog_route_owners(self.profile, key)")
        learn_branch_pos = body.index("if acceptable:")
        self.assertLess(guard_pos, learn_branch_pos)
        self.assertIn("return", body[guard_pos:learn_branch_pos])


    def test_obs_integration_is_removed_from_runtime_and_dependencies(self):
        project = Path(__file__).resolve().parents[1]
        source = (project / "smc_suite" / "ui" / "main_window.py").read_text(encoding="utf-8")
        requirements = (project / "requirements.txt").read_text(encoding="utf-8").lower()
        self.assertNotIn("def _build_obs_tab", source)
        self.assertNotIn("_ObsActionWorker", source)
        self.assertNotIn("_obs_config", source)
        self.assertNotIn("obsws-python", requirements)
        self.assertNotIn("obsws_python", source)

    def test_quick_actions_include_windows_media_and_exclude_obs(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        self.assertIn('("Windows: mute do microfone", "mute_microphone")', source)
        self.assertIn('("Mídia: Play / Pause", "media_play_pause")', source)
        self.assertNotIn('("OBS: iniciar / parar gravação", "obs_toggle_recording")', source)
        self.assertNotIn('(self._obs_page, "OBS Studio"', source)
        self.assertIn('"custom_shortcut": ("shortcut", None)', source)
        self.assertIn("Um evento por clique (CC Single / Toggle)", source)
        self.assertIn('row.get("trigger_mode", "note")', source)
        self.assertIn('trigger_mode=trigger_mode', source)


if __name__ == "__main__":
    unittest.main()


class AnalogLearnIntegrationRegressionTests(unittest.TestCase):
    def test_main_window_uses_motion_confirmed_analog_learning(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        self.assertIn("self._analog_learn_sampler.feed(kind, key, value)", source)
        self.assertIn("while MIDI Learn is active, never let another", source)

    def test_action_hud_can_be_disabled_and_positioned(self):
        source_path = Path(__file__).resolve().parents[1] / "smc_suite" / "ui" / "main_window.py"
        source = source_path.read_text(encoding="utf-8")
        self.assertIn("self.hud_enabled_checkbox", source)
        self.assertIn("self.store.data[\"show_action_hud\"]", source)
        self.assertIn("self.hud.set_options", source)
