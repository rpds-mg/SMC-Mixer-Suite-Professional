import unittest

from smc_suite.config_store import _normalize_profile, default_profile
from smc_suite.hardware import BUTTON_IDS, BUTTON_SPECS, default_button_actions


class HardwareConfigTests(unittest.TestCase):
    def test_exactly_43_learnable_buttons_are_defined(self):
        self.assertEqual(len(BUTTON_SPECS), 43)
        self.assertEqual(len(BUTTON_IDS), 43)
        self.assertEqual(len(set(BUTTON_IDS)), 43)

    def test_default_profile_has_eight_channels_and_four_banks(self):
        profile = default_profile()
        self.assertEqual(len(profile["fader_midi"]), 8)
        self.assertEqual(len(profile["knob_midi"]), 8)
        self.assertEqual(len(profile["banks"]), 4)
        self.assertEqual(len(profile["button_actions"]), 43)

    def test_legacy_profile_migrates_channel_names_and_targets(self):
        old = {
            "channel_names": ["Master", "OBS", "Spotify", "Discord", "Browser", "Six", "Seven", "Eight"],
            "fader_targets": ["__master__", "obs64.exe", "spotify.exe", "Discord.exe", "chrome.exe", "", "", ""],
            "fader_midi": [None] * 8,
            "knob_midi": [None] * 8,
            "eq_gains": [0] * 8,
        }
        upgraded = _normalize_profile(old, "Migração")
        self.assertEqual(upgraded["banks"][0]["channel_names"][1], "OBS")
        self.assertEqual(upgraded["banks"][0]["fader_targets"][2], "spotify.exe")
        self.assertEqual(len(upgraded["button_actions"]), 43)

    def test_per_mode_equalizer_curves_are_preserved(self):
        profile = default_profile("EQ")
        profile["eq_mode"] = 3
        profile["eq_gains"] = [1.0, 2.0, 3.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        profile["eq_gains_by_mode"] = {
            "3": [1.0, 2.0, 3.0],
            "5": [4.0, 3.0, 2.0, 1.0, 0.0],
            "8": [0.0, 1.0, 2.0, 3.0, 4.0, 3.0, 2.0, 1.0],
        }
        normalized = _normalize_profile(profile, "EQ")
        self.assertEqual(normalized["eq_gains"][:3], [1.0, 2.0, 3.0])
        self.assertEqual(normalized["eq_gains_by_mode"]["5"], [4.0, 3.0, 2.0, 1.0, 0.0])
        self.assertEqual(normalized["eq_gains_by_mode"]["8"][3], 3.0)

    def test_default_button_actions_include_channel_controls(self):
        actions = default_button_actions()
        self.assertEqual(actions["ch1_mute"]["action"], "channel_mute")
        self.assertEqual(actions["ch1_solo"]["action"], "channel_solo")
        self.assertEqual(actions["ch8_select"]["action"], "channel_select")
        self.assertEqual(actions["transport_play_pause"]["action"], "media")
        self.assertEqual(actions["transport_play_pause"]["trigger_mode"], "note")


if __name__ == "__main__":
    unittest.main()
