import unittest

from smc_suite.layout_policy import (
    choose_eq_grid_columns,
    effective_compact_mode,
    recommended_channel_strip_width,
)


class ResponsiveLayoutPolicyTests(unittest.TestCase):
    def test_eq_keeps_all_eight_bands_in_one_row_when_width_is_sufficient(self):
        self.assertEqual(choose_eq_grid_columns(1200, 8), 8)

    def test_eq_reflows_instead_of_horizontal_overflow(self):
        self.assertEqual(choose_eq_grid_columns(800, 8), 4)
        self.assertEqual(choose_eq_grid_columns(500, 8), 4)
        self.assertEqual(choose_eq_grid_columns(250, 8), 2)
        self.assertEqual(choose_eq_grid_columns(180, 8), 1)

    def test_eq_column_count_never_exceeds_band_count(self):
        for count in (1, 3, 5, 8):
            columns = choose_eq_grid_columns(2000, count)
            self.assertEqual(columns, count)
            self.assertGreaterEqual(columns, 1)

    def test_adaptive_compact_mode_honors_user_choice_and_small_window(self):
        self.assertTrue(effective_compact_mode(True, 1920, 1080))
        self.assertTrue(effective_compact_mode(False, 1200, 800))
        self.assertTrue(effective_compact_mode(False, 1920, 700))
        self.assertFalse(effective_compact_mode(False, 1440, 900))

    def test_channel_strip_width_budget_fits_eight_strips(self):
        self.assertEqual(recommended_channel_strip_width(1000), 116)
        self.assertLess(recommended_channel_strip_width(900), 116)
        self.assertGreaterEqual(recommended_channel_strip_width(650), 90)
        self.assertEqual(recommended_channel_strip_width(300), 90)


if __name__ == "__main__":
    unittest.main()
