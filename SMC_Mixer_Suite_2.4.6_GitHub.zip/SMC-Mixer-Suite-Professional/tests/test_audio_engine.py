import unittest
from types import SimpleNamespace
from unittest.mock import Mock

from smc_suite.audio_engine import AudioEngine


class _FakeProcess:
    def __init__(self, name):
        self._name = name

    def name(self):
        return self._name


class _FakeVolume:
    def __init__(self, mute=False):
        self.mute = mute
        self.calls = []

    def SetMute(self, value, _context):
        self.mute = bool(value)
        self.calls.append(self.mute)

    def GetMute(self):
        return self.mute


class AudioEngineBatchMuteTests(unittest.TestCase):
    def test_set_mutes_updates_multiple_sessions_in_one_enumeration(self):
        first = _FakeVolume(False)
        second = _FakeVolume(False)
        sessions = [
            SimpleNamespace(Process=_FakeProcess("spotify.exe"), SimpleAudioVolume=first),
            SimpleNamespace(Process=_FakeProcess("spotify.exe"), SimpleAudioVolume=second),
            SimpleNamespace(Process=_FakeProcess("chrome.exe"), SimpleAudioVolume=_FakeVolume(False)),
        ]
        utilities = SimpleNamespace(GetAllSessions=Mock(return_value=sessions))
        engine = AudioEngine()
        engine.available = True
        engine._audio_utilities = lambda: utilities

        result = engine.set_mutes({"spotify.exe": True})

        self.assertTrue(result["spotify.exe"])
        self.assertEqual(first.calls, [True])
        self.assertEqual(second.calls, [True])
        utilities.GetAllSessions.assert_called_once_with()

    def test_set_mutes_handles_master_and_process_together(self):
        app_volume = _FakeVolume(False)
        sessions = [SimpleNamespace(Process=_FakeProcess("obs64.exe"), SimpleAudioVolume=app_volume)]
        utilities = SimpleNamespace(GetAllSessions=Mock(return_value=sessions))
        master = SimpleNamespace(SetMute=Mock(), GetMute=Mock(return_value=False))
        engine = AudioEngine()
        engine.available = True
        engine._audio_utilities = lambda: utilities
        engine._master_endpoint = lambda: master

        result = engine.set_mutes({"__master__": True, "obs64.exe": True})

        self.assertTrue(result["__master__"])
        self.assertTrue(result["obs64.exe"])
        master.SetMute.assert_called_once_with(1, None)
        self.assertTrue(app_volume.mute)
        utilities.GetAllSessions.assert_called_once_with()

    def test_unknown_process_is_reported_as_not_updated(self):
        utilities = SimpleNamespace(GetAllSessions=Mock(return_value=[]))
        engine = AudioEngine()
        engine.available = True
        engine._audio_utilities = lambda: utilities

        result = engine.set_mutes({"missing.exe": True})

        self.assertFalse(result["missing.exe"])


if __name__ == "__main__":
    unittest.main()
