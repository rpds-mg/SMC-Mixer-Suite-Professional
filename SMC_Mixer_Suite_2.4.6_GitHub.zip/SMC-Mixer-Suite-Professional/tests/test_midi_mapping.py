import unittest

from smc_suite.config_store import default_profile
from smc_suite.midi_mapping import analog_route_owners, midi_route_owners, repair_duplicate_midi_routes


class MidiMappingIntegrityTests(unittest.TestCase):
    def test_duplicate_fader_and_select_button_routes_are_both_cleared(self):
        profile = default_profile()
        profile["fader_midi"][0] = "cc:0:20"
        profile["button_actions"]["ch1_select"]["midi"] = "cc:0:20"
        profile["button_actions"]["ch1_select"]["action"] = "channel_select"
        profile["fader_targets"][0] = "__master__"

        warnings = repair_duplicate_midi_routes(profile)

        self.assertEqual(profile["fader_midi"][0], None)
        self.assertIsNone(profile["button_actions"]["ch1_select"]["midi"])
        self.assertEqual(profile["button_actions"]["ch1_select"]["action"], "channel_select")
        self.assertEqual(profile["fader_targets"][0], "__master__")
        self.assertEqual(len(warnings), 1)
        self.assertIn("Fader 1", warnings[0])
        self.assertIn("Canal 1 · SELECT", warnings[0])

    def test_duplicate_routes_are_removed_without_touching_unrelated_routes(self):
        profile = default_profile()
        profile["fader_midi"][0] = "cc:0:10"
        profile["fader_midi"][1] = "cc:0:11"
        profile["knob_midi"][0] = "cc:0:10"
        profile["button_actions"]["transport_play_pause"]["midi"] = "note:0:30"

        warnings = repair_duplicate_midi_routes(profile)

        self.assertIsNone(profile["fader_midi"][0])
        self.assertIsNone(profile["knob_midi"][0])
        self.assertEqual(profile["fader_midi"][1], "cc:0:11")
        self.assertEqual(profile["button_actions"]["transport_play_pause"]["midi"], "note:0:30")
        self.assertEqual(len(warnings), 1)

    def test_duplicate_button_routes_are_both_cleared(self):
        profile = default_profile()
        profile["button_actions"]["ch1_select"]["midi"] = "cc:0:24"
        profile["button_actions"]["ch2_select"]["midi"] = "cc:0:24"

        warnings = repair_duplicate_midi_routes(profile)

        self.assertIsNone(profile["button_actions"]["ch1_select"]["midi"])
        self.assertIsNone(profile["button_actions"]["ch2_select"]["midi"])
        self.assertEqual(len(warnings), 1)


    def test_smc_select_cc_collision_is_flagged_when_same_key_is_learned(self):
        profile = default_profile()
        # Example reported by the user: SELECT 2 emits CC 45, same key as fader 6.
        profile["fader_midi"][5] = "cc:0:45"
        profile["button_actions"]["ch2_select"]["midi"] = "cc:0:45"
        warnings = repair_duplicate_midi_routes(profile)
        self.assertEqual(len(warnings), 1)
        self.assertIsNone(profile["fader_midi"][5])
        self.assertIsNone(profile["button_actions"]["ch2_select"]["midi"])
        self.assertIn("CC", warnings[0])

    def test_select_note_and_fader_cc_can_coexist(self):
        profile = default_profile()
        profile["fader_midi"][5] = "cc:0:45"
        profile["button_actions"]["ch2_select"]["midi"] = "note:0:25"
        self.assertEqual(repair_duplicate_midi_routes(profile), [])
        self.assertEqual(profile["fader_midi"][5], "cc:0:45")
        self.assertEqual(profile["button_actions"]["ch2_select"]["midi"], "note:0:25")

    def test_clean_profile_is_unchanged(self):
        profile = default_profile()
        profile["fader_midi"][0] = "cc:0:10"
        profile["knob_midi"][0] = "cc:0:11"
        profile["button_actions"]["ch1_select"]["midi"] = "cc:0:12"

        self.assertEqual(repair_duplicate_midi_routes(profile), [])
        self.assertEqual(profile["fader_midi"][0], "cc:0:10")
        self.assertEqual(profile["knob_midi"][0], "cc:0:11")
        self.assertEqual(profile["button_actions"]["ch1_select"]["midi"], "cc:0:12")

    def test_analog_owner_lookup_catches_both_fader_and_knob(self):
        profile = default_profile()
        profile["fader_midi"][2] = "cc:0:40"
        profile["knob_midi"][5] = "cc:0:40"
        owners = analog_route_owners(profile, "cc:0:40")
        self.assertEqual([owner[0] for owner in owners], ["fader", "knob"])
        self.assertEqual(len(midi_route_owners(profile, "cc:0:40")), 2)


if __name__ == "__main__":
    unittest.main()
