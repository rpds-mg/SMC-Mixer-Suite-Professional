"""Compile application and test Python files, excluding virtualenv/build artifacts."""
from __future__ import annotations

import py_compile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCES = [ROOT / "main.py", ROOT / "smc_suite", ROOT / "tests"]
EXCLUDED = {"__pycache__", ".venv", "build", "dist"}


def source_files():
    for source in SOURCES:
        if source.is_file():
            yield source
        elif source.is_dir():
            for candidate in source.rglob("*.py"):
                if not any(part in EXCLUDED for part in candidate.parts):
                    yield candidate


def main() -> int:
    files = sorted(set(source_files()))
    for path in files:
        py_compile.compile(str(path), doraise=True)
    print(f"Sintaxe Python aprovada: {len(files)} arquivos verificados.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
