---
name: Relatar um problema
about: Descrever um erro reproduzível na SMC Mixer Suite
labels: bug
---

## Ambiente
- Windows (versão):
- Python (versão):
- Versão da SMC Mixer Suite: 2.4.6
- Conexão SMC-Mixer: USB / Bluetooth / não conectado

## Passos para reproduzir
1.
2.
3.

## O que eu esperava que acontecesse?

## O que aconteceu de fato?

## Mensagem de erro
Cole apenas o trecho relevante e remova dados pessoais antes de publicar.

## Testou com o hardware físico?
- [ ] Sim
- [ ] Não
