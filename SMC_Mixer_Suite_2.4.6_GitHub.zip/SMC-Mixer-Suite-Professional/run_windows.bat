@echo off
setlocal
cd /d "%~dp0"
echo Iniciando o codigo-fonte SMC Mixer Suite Professional 2.4.6 - Rafael Souza
if not exist ".venv\Scripts\python.exe" (
  echo Ambiente Python nao encontrado. Execute setup_windows.bat primeiro.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -X faulthandler -u main.py
if errorlevel 1 (
  echo.
  echo O aplicativo terminou com erro. Confira %%APPDATA%%\SMCMixerSuite\logs\smc_mixer_suite.log
  pause
)
